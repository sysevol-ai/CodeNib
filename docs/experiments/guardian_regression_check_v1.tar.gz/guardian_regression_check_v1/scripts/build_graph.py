"""Check out an instance's base commit and save a compact CodeNib symbol graph.

Usage: python build_graph.py INSTANCE_ID [REPO BASE_COMMIT]
Run with PYTHONPATH and cwd at the v4 candidate tree, CODENIB_HOME set.
Writes graphs/<id>.json.gz: nodes (name, type, file, start, end, has_def) and
reference/contain edges as (source, target, type).
"""

import gzip
import json
import re
import subprocess
import sys
import time
from pathlib import Path

G = Path(__file__).resolve().parent


def worktree(iid, repo, commit):
    path = G / "wt" / iid
    if not path.exists():
        bare = G / "repos" / (repo.split("/")[1] + ".git")
        subprocess.run(["git", "--git-dir", str(bare), "worktree", "add", "-q", "--detach",
                        str(path), commit], check=True)
    head = subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()
    assert head == commit, (iid, head, commit)
    return path


def main():
    iid = sys.argv[1]
    if len(sys.argv) > 2:
        repo, commit = sys.argv[2], sys.argv[3]
    else:
        info = json.loads((G / "instances.json").read_text())[iid]
        repo, commit = info["repo"], info["base_commit"]
    out = G / "graphs" / f"{iid}.json.gz"
    if out.exists():
        return
    root = worktree(iid, repo, commit)
    start = time.monotonic()
    proc = subprocess.run([sys.executable, "-m", "codenib", "index", str(root), "--language",
                           "python", "--view", "symbol_graph"], capture_output=True, text=True)
    if proc.returncode:
        raise SystemExit(f"{iid}: index failed\n{proc.stdout[-2000:]}\n{proc.stderr[-4000:]}")
    manifest = re.search(r"^Manifest:\s+(\S+)", proc.stdout, re.M)[1]
    from codenib.mcp.context import ServerContext

    g = ServerContext.load(manifest, views=["symbol_graph"]).symbol_graph.get_graph()
    nodes = [[v["name"], v["type"], v["file"], v["start_line"], v["end_line"],
              bool(v["has_definition"])] for v in g.vs]
    edges = [[e.source, e.target, e["type"]] for e in g.es]
    out.parent.mkdir(exist_ok=True)
    with gzip.open(out, "wt") as f:
        json.dump({"instance_id": iid, "repo": repo, "commit": commit,
                   "seconds": time.monotonic() - start, "nodes": nodes, "edges": edges}, f)
    print(iid, "nodes", len(nodes), "edges", len(edges), "%.0fs" % (time.monotonic() - start),
          flush=True)


if __name__ == "__main__":
    main()
