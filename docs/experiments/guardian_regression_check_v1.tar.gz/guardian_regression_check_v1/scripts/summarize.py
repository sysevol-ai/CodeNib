"""Apply PROTOCOL.md's measures and decision rule to guardian-results.json."""

import json
import statistics
import sys
from collections import Counter
from pathlib import Path

G = Path(__file__).resolve().parent
DEPTHS = ["1", "2", "3", "4", "None"]


def pct(values, q):
    values = sorted(values)
    return values[min(len(values) - 1, int(round(q * (len(values) - 1))))]


def main():
    rows = json.loads((G / "guardian-results.json").read_text())
    cases = [r for r in rows if r["kind"] == "regression"]
    controls = [r for r in rows if r["kind"] == "clean"]
    assert len(cases) == 68, len(cases)
    out = {"cases": len(cases), "controls": len(controls), "methods": {}}

    def hit(r, k):
        return any(d is not None and (k == "None" or d <= int(k)) for d in r["broken_depth"])

    def tests_hit(r, k):
        return sum(d is not None and (k == "None" or d <= int(k)) for d in r["broken_depth"])

    methods = {f"graph k={k}": (lambda r, k=k: hit(r, k), lambda r, k=k: tests_hit(r, k),
                                lambda r, k=k: r["flag_size"][k]) for k in DEPTHS}
    methods["import baseline"] = (lambda r: any(r["broken_in_baseline"]),
                                  lambda r: sum(r["broken_in_baseline"]),
                                  lambda r: r["baseline_size"])
    broken_total = sum(r["broken"] for r in cases)
    for name, (case_hit, test_hits, size) in methods.items():
        out["methods"][name] = {
            "case_recall": sum(map(case_hit, cases)) / len(cases),
            "cases_hit": sum(map(case_hit, cases)),
            "test_recall": sum(map(test_hits, cases)) / broken_total,
            "control_cost_median": statistics.median(map(size, controls)),
            "control_cost_p90": pct(list(map(size, controls)), 0.9),
            "control_share_median": statistics.median(size(r) / r["repo_tests"] for r in controls),
            "case_cost_median": statistics.median(map(size, cases)),
            "case_share_median": statistics.median(size(r) / r["repo_tests"] for r in cases),
        }
    g, b = out["methods"]["graph k=3"], out["methods"]["import baseline"]

    def useful(m):
        return m["case_recall"] >= 0.70 and m["control_share_median"] <= 0.01

    better = ((g["case_recall"] >= b["case_recall"] + 0.15
               and g["control_cost_median"] <= b["control_cost_median"])
              or (g["control_cost_median"] <= b["control_cost_median"] / 2
                  and g["case_recall"] >= b["case_recall"] - 0.05))
    if useful(g) and better:
        verdict = "a graph guardian is worth building"
    elif useful(b):
        verdict = "a file-level guardian is enough"
    elif any(m["case_recall"] >= 0.70 for m in out["methods"].values()):
        verdict = "static impact is too noisy"
    else:
        verdict = "static impact misses these regressions"
    out.update({"graph_useful": useful(g), "graph_better": better, "baseline_useful": useful(b),
                "verdict": verdict})
    out["match"] = Counter(m for r in cases for m in r["broken_match"])
    out["units"] = Counter()
    for r in rows:
        out["units"].update(r["units"])
    out["no_seeds"] = sum(1 for r in rows if r["seeds"] == 0)
    out["by_repo"] = {}
    for repo in sorted({r["instance_id"].split("__")[0] for r in cases}):
        sel = [r for r in cases if r["instance_id"].startswith(repo + "__")]
        out["by_repo"][repo] = {"cases": len(sel), "graph k=3": sum(hit(r, "3") for r in sel),
                                "graph unbounded": sum(hit(r, "None") for r in sel),
                                "import": sum(any(r["broken_in_baseline"]) for r in sel)}
    (G / "summary.json").write_text(json.dumps(out, indent=1) + "\n")
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
