"""Guardian check on real agent regressions (see PROTOCOL.md).

For each patch: map hunks to changed code in the base graph, flag the tests
that reach it within k reference edges, and the import baseline's tests.

Usage: python guardian.py [items.json] [out.json]
"""

import ast
import gzip
import json
import re
import sys
from collections import defaultdict, deque
from pathlib import Path


G = Path(__file__).resolve().parent
DEPTHS = [1, 2, 3, 4, None]
DEFS = {"function", "method"}


def is_test_file(path):
    parts = path.split("/")
    name = parts[-1]
    return (any(p in ("tests", "test", "testing") for p in parts[:-1])
            or name.startswith("test_") or name.endswith("_test.py") or name == "tests.py")


def module_name(path):
    mod = path[:-3].replace("/", ".")
    if mod.endswith(".__init__"):
        mod = mod[: -len(".__init__")]
    for prefix in ("src.", "lib."):
        if mod.startswith(prefix):
            mod = mod[len(prefix):]
    return mod


class Graph:
    def __init__(self, iid):
        data = json.load(gzip.open(G / "graphs" / f"{iid}.json.gz", "rt"))
        self.root = G / "wt" / iid
        self.nodes = data["nodes"]
        self.callers = defaultdict(set)
        self.children = defaultdict(set)
        for s, t, kind in data["edges"]:
            if kind == "reference":
                self.callers[t].add(s)
            elif kind == "contain":
                self.children[s].add(t)
        self.by_file = defaultdict(list)
        self.by_name = {}
        for i, (name, kind, file, start, end, has_def) in enumerate(self.nodes):
            self.by_name.setdefault(name, i)
            if has_def and file is not None and start is not None:
                self.by_file[file].append(i)
        self.tests = {i for i, n in enumerate(self.nodes)
                      if n[1] in DEFS and n[5] and n[2] and is_test_file(n[2])
                      and short(n[0]).startswith("test")}

    def innermost(self, path, line, kinds):
        """Innermost node of ``kinds`` containing 1-based ``line``."""
        best = None
        for i in self.by_file.get(path, []):
            name, kind, file, start, end, _ = self.nodes[i]
            if kind in kinds and start + 1 <= line <= end + 1:
                if best is None or end - start < self.nodes[best][4] - self.nodes[best][3]:
                    best = i
        return best

    def seeds(self, path, line):
        node = self.innermost(path, line, DEFS)
        if node is not None:
            return {node}, "def"
        node = self.innermost(path, line, {"class"})
        if node is not None:
            return {node} | {c for c in self.children[node] if self.nodes[c][1] in DEFS}, "class"
        return set(self.by_file.get(path, [])), "file"

    def reach(self, seeds):
        """Minimum number of reference edges from each node to a seed."""
        depth = {s: 0 for s in seeds}
        queue = deque(seeds)
        while queue:
            node = queue.popleft()
            for caller in self.callers[node]:
                if caller not in depth:
                    depth[caller] = depth[node] + 1
                    queue.append(caller)
        return depth


def short(name):
    return name.split(":", 1)[-1].split(".")[-1].split("(")[0]


def changed_lines(patch_text):
    """{path: [1-based base lines]} for modified non-test .py files.

    A removed line maps to itself, an added line to the last base line before
    it. Hunk line counts end a hunk, but a short hunk (agents' patches often
    drop trailing context) ends at the next file header instead of failing.
    """
    out, skipped = {}, []
    path, old, src, last, left_old, left_new = None, None, None, None, 0, 0
    for raw in patch_text.splitlines():
        in_hunk = src is not None and (left_old > 0 or left_new > 0)
        if raw.startswith("diff --git "):
            path, src, left_old, left_new = None, None, 0, 0
            continue
        if not in_hunk and raw.startswith("--- "):
            old = raw[4:].split("\t")[0].strip()
            continue
        if not in_hunk and raw.startswith("+++ "):
            new = raw[4:].split("\t")[0].strip()
            name = old if new == "/dev/null" else new
            name = name[2:] if name[:2] in ("a/", "b/") else name
            path = name if name.endswith(".py") and not is_test_file(name) else None
            if path and old == "/dev/null":
                skipped.append(path)
                path = None
            elif path:
                out.setdefault(path, [])
            src = None
            continue
        match = re.match(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", raw)
        if match and not in_hunk:
            src = last = int(match[1])
            left_old = int(match[2]) if match[2] is not None else 1
            left_new = int(match[4]) if match[4] is not None else 1
            continue
        if not in_hunk:
            continue
        if raw.startswith("-"):
            if path:
                out[path].append(src)
            last, src, left_old = src, src + 1, left_old - 1
        elif raw.startswith("+"):
            if path:
                out[path].append(max(last, 1))
            left_new -= 1
        elif raw.startswith("\\"):
            continue
        else:
            last, src, left_old, left_new = src, src + 1, left_old - 1, left_new - 1
    out = {path: sorted(set(lines)) for path, lines in out.items()}
    return out, skipped


def test_node(graph, test_id):
    """Graph node for a SWE-bench test id, or None."""
    test_id = re.sub(r"\[.*\]$", "", test_id.strip())
    match = re.match(r"^(\S+\.py)::(\w+) \(([\w.]+)\)$", test_id)
    if match:
        path, method, dotted = match.groups()
        cls = dotted.split(".")[-1]
        name = f"{path}:{cls}.{method}()"
    else:
        parts = test_id.split("::")
        path = parts[0]
        method = re.sub(r"\[.*$", "", parts[-1])
        dotted = ".".join(re.sub(r"\[.*$", "", p) for p in parts[1:])
        name = f"{path}:{dotted}()"
    if name in graph.by_name:
        return graph.by_name[name], "exact"
    same = [i for i in graph.tests if graph.nodes[i][2] == path and short(graph.nodes[i][0]) == method]
    if len(same) >= 1:
        return same[0], "same file and name"
    # Django names a test with a docstring by the docstring's first line.
    text = test_id.split("::", 1)[-1].strip()
    try:
        tree = ast.parse((graph.root / path).read_bytes())
    except (SyntaxError, ValueError, OSError):
        return None, "unmatched"
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test"):
            doc = ast.get_docstring(node)
            if doc and doc.strip().splitlines()[0].strip() == text:
                hits = [i for i in graph.tests if graph.nodes[i][2] == path
                        and short(graph.nodes[i][0]) == node.name
                        and graph.nodes[i][3] + 1 <= node.lineno <= graph.nodes[i][4] + 1]
                if hits:
                    return hits[0], "docstring"
    return None, "unmatched"


def imports_module(tree, changed):
    """Whether a parsed test file imports any of ``changed`` modules directly."""
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            if any(a.name in changed for a in node.names):
                return True
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            if node.module in changed:
                return True
            if any(f"{node.module}.{a.name}" in changed for a in node.names):
                return True
    return False


def import_baseline(graph, paths, cache):
    changed = {module_name(p) for p in paths}
    files = set()
    for test_file in {graph.nodes[i][2] for i in graph.tests}:
        if test_file not in cache:
            try:
                cache[test_file] = ast.parse((graph.root / test_file).read_bytes())
            except (SyntaxError, ValueError, OSError):
                cache[test_file] = None
        if cache[test_file] is not None and imports_module(cache[test_file], changed):
            files.add(test_file)
    return {i for i in graph.tests if graph.nodes[i][2] in files}


def main():
    items = json.loads(Path(sys.argv[1] if len(sys.argv) > 1 else G / "items.json").read_text())
    items.sort(key=lambda item: (item["instance_id"], item["tool"]))
    out_path = Path(sys.argv[2] if len(sys.argv) > 2 else G / "guardian-results.json")
    graphs, caches, rows = {}, defaultdict(dict), []
    for item in items:
        iid = item["instance_id"]
        if iid not in graphs:
            graphs = {iid: Graph(iid)}
        graph = graphs[iid]
        lines, skipped = changed_lines(item["patch"])
        seeds, units = set(), defaultdict(int)
        for path, numbers in lines.items():
            for line in numbers:
                found, unit = graph.seeds(path, line)
                seeds |= found
                units[unit] += 1
        depth = graph.reach(seeds)
        flagged = {str(k): sorted(i for i in graph.tests if i in depth and (k is None or depth[i] <= k))
                   for k in DEPTHS}
        baseline = import_baseline(graph, lines, caches[iid])
        broken = [test_node(graph, t) for t in item["broken"]]
        row = {k: item[k] for k in ("tool", "instance_id", "kind")}
        row.update({
            "changed_files": sorted(lines), "new_files_skipped": skipped, "units": dict(units),
            "seeds": len(seeds), "repo_tests": len(graph.tests),
            "flag_size": {k: len(v) for k, v in flagged.items()},
            "baseline_size": len(baseline),
            "broken": len(item["broken"]),
            "broken_match": [m for _, m in broken],
            "broken_depth": [depth.get(i) if i is not None and i in depth else None for i, _ in broken],
            "broken_in_baseline": [i in baseline if i is not None else False for i, _ in broken],
        })
        rows.append(row)
        print(iid, item["tool"], item["kind"], "seeds", len(seeds), "flags k3", row["flag_size"]["3"],
              "baseline", len(baseline), flush=True)
    out_path.write_text(json.dumps(rows, indent=1) + "\n")


if __name__ == "__main__":
    main()
