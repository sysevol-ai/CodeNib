# Guardian check on real agent regressions: protocol

Written 2026-11-03, before any impact set was computed for a regressing patch.

## Question

Some agent patches pass SWE-bench's own tests but break other tests in the
project's full suite. Would a guardian that reads the patch, finds the changed
functions in CodeNib's code graph, and flags the tests that reach them have
pointed at the broken tests? And would it flag few enough tests to act on?

## Data

- **Cases.** PatchDiff's RQ1 results (Wang, Pradel and Liu, ICSE 2026; Zenodo
  record 17074796). These are plausible SWE-bench Verified patches from three
  agents (CodeStory, LearnByInteract and OpenHands) that fail at least one
  full-suite test which passes with the developer's patch. Only the cases
  PatchDiff labels "functionality" count: 68 cases on 47 instances.
- **Broken tests.** The tests listed in `oracle_pass_model_fail`.
- **Controls.** The same three agents' other plausible patches on the same 47
  instances, which PatchDiff found no failing test for. They measure what the
  guardian flags on a patch that broke nothing.

## Guardian

- **Changed code.** For every hunk in a non-test `.py` file, the innermost
  function or method in the base code that contains a removed line or the
  insertion point. A hunk outside any function maps to its innermost class.
  A hunk outside any class maps to the file.
- **Flagged tests at depth k.** Every test function or method, meaning a
  definition in a test file, that reaches changed code through at most k
  reference edges of the symbol graph. For a class, a reference to it or to any
  of its methods counts. For a file, a reference to any definition in it
  counts.
- **Depths.** k = 1 to 4, plus unbounded. The primary depth is k = 3.
- **Graph.** CodeNib's symbol graph with the pyrefly provider, from the v4
  candidate tree, built at the instance's base commit.

## Baseline

Import-based selection flags every test in each test file that imports a
changed module directly, by name or through `from package import module`. This
is the usual file-level static selection.

## Measures

- **Case recall.** The share of the 68 cases in which at least one broken test
  is flagged.
- **Test recall.** The share of broken tests that are flagged, pooled over all
  cases.
- **Cost.** The number of flagged test functions for each patch: median and
  90th percentile over the controls, and over the cases. Each is also given as
  a share of the repository's test functions.

## Decision rule

1. **Useful.** At k = 3 the guardian is useful when its case recall is at least
   70% and its median cost on controls is at most 1% of the repository's test
   functions.
2. **Better than files.** The graph beats the baseline when either:
   - its case recall is at least 15 points higher at no larger median control
     cost; or
   - its median control cost is at most half the baseline's and its case
     recall is no more than 5 points lower.

| Outcome | Condition |
|---|---|
| A graph guardian is worth building. | Both 1 and 2 hold. |
| A file-level guardian is enough. | The baseline meets 1, and 2 fails. |
| Static impact is too noisy. | Some method reaches 70% case recall, but none meets 1. |
| Static impact misses these regressions. | No method reaches 70% case recall. |

## Limits

- The static graph misses dynamic dispatch, such as Django's test client and
  URL routing, signals and string-named lookups. Recall is a lower bound for
  any guardian that can also run tests.
- The cases come from 2024 agents on SWE-bench Verified. Django and sympy make
  up 55 of the 68.
