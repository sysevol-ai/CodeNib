# Change guard in the loop, A/B protocol v1, round 1

Status: sealed before any model call on these cases. Hash and time are in PROTOCOL.sha256.
Part of sysevol-ai/CodeNib#975, phase 5.

## Question

Does `codenib guard` lead the same agent to fewer hidden regressions than (a) no hook, and
(b) a Stop hook that names the project's full test suite? A hidden regression is a patch that passes
SWE-bench's own check and breaks a test elsewhere in the project's full suite.

Earlier checks measured only whether a list contains a broken test. This one measures what the agent does.

## Arms

All three use the same model, prompt, tools and limits, and differ only in what happens at Stop.

- **native**: no hook.
- **guard**: `codenib guard install --agent claude` at CodeNib main 10904dac91f83ec930f0915b81f72bca1e96ebcf, with its
  real SessionStart and Stop hooks and the message the product sends, including its 20-test command.
  The graph is built before the session. The wheel is built with a placeholder Wiki frontend, which the guard does not use.
- **suite**: a Stop hook with the guard's event, output shape and once-per-change rule. Its text names the number of
  changed Python files and `./tests/runtests.py --settings=test_sqlite --parallel 16`, and ends with the guard's own
  sentence: "A failure that the change caused needs a fix before the work is done."

## Cases

The 25 Django instances of SWE-bench Verified on which one of three 2024-25 agents passed SWE-bench and broke
another test (Wang, Pradel and Liu, ICSE 2026), minus django__django-11149, used for plumbing: 24 instances.
They are enriched for hidden regressions and do not represent ordinary patches.

Each instance runs once per arm: 72 sessions. A fixed seed (guard-ab-v1-round1) sets the order.

## Agent and environment

- Claude Code 2.1.319, claude-opus-5-5, medium effort, no MCP, WebFetch and WebSearch disabled.
- $3 and 1,800 s per session. The whole round is hard-limited to $40, counting each running session at its maximum.
- The instance's SWE-bench image, 16 CPUs, 48 GB, 8,192 processes, at most 4 sessions at once.
- A one-commit snapshot of the base commit, with no history. Network is open for the API; transcripts are checked for
  fetching the upstream fix.
- Prompt: the issue text, then "Fix this issue in the repository in the current directory. Run tests with
  `./tests/runtests.py`."

## Grading

Deterministic, with no model and no human judgement.

1. **Resolved**: the patch through SWE-bench's own eval script and its grading code.
2. **Full suite**: a fresh container, the patch without its changes under `tests/`, so an edit to an existing test cannot
   hide a failure, plus the benchmark's test patch, then the whole suite at 16 processes.
3. **Regression**: a test failing in two full runs of the patch and in neither of two full runs of the gold patch. A suite
   that does not finish counts as a regression. Isolated reruns are recorded, not used to decide.

Before any model call, the grader was checked with these results:

- Gold patch resolved on 25 of 25 instances, with identical test counts in both full runs.
- Of 27 older patches labelled as regressions that resolve here, 26 are reported as regressions.
- Of 24 older patches labelled clean, 23 report none. django-16661 OpenHands fails test_disallowed_filtering repeatably.
- 7 older patches labelled plausible do not resolve here. Three have no source fix in the published data.

## Measures

Primary, per arm out of 24:

- **Clean success**: resolved with no regression.
- **Hidden regressions**: resolved with a regression.

Secondary:

- resolved; regressions among all patches;
- hook fired; tools and edits after the hook; test commands before and after it;
- how many flagged tests the final patch has, and whether its regressions are on the guard's list, in every arm;
- session time, turns, tokens and cost.

## Decision rule for round 1

One repetition cannot establish a small effect, so this round decides what happens next.

1. **Nothing to catch.** native has at most 1 hidden regression of 24. Report that this agent rarely causes what the
   guard catches on these cases, and spend no more on this cohort.
2. **Worth confirming.** native has at least 2 and guard has fewer than native. Propose more repetitions under a newly
   sealed protocol, with the budget agreed first.
3. **No sign of benefit.** native has at least 2 and guard has at least as many as native. Report no demonstrated
   benefit, and run no more until the product changes.

Separately, if suite has at least as many clean successes as guard, report that a one-line hook did at least as well
in this round, along with the time each arm took.

No case, measure or denominator changes after outcomes are seen. A session that fails for a harness reason is reported
and rerun once, marked as a rerun.
