import json, sys
from concurrent.futures import ThreadPoolExecutor
import session as S
iid = 'django__django-11149'
with ThreadPoolExecutor(2) as pool:
    for f in [pool.submit(S.run_session, iid, arm, 0, 'plumbing') for arm in ('guard', 'suite')]:
        m = f.result()
        print(json.dumps({k: m.get(k) for k in ('sid','exit','timed_out','cost','turns','session_seconds','diff_bytes','subtype','is_error','tools_total','tools_after_hook','edits_after_hook','bash_after_hook','stderr')})[:1500])
        print('hook context:', (m.get('hook_context') or ['<none>'])[0][:700])
