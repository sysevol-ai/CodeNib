#!/bin/bash
E=/mnt/data/zhongming/guard-ab-v1; cd "$E/harness"
for i in django__django-13121 django__django-12858 django__django-11265 django__django-13112 django__django-13279 django__django-14771 django__django-17084 django__django-12273 django__django-15161 django__django-11880 django__django-11292 django__django-13028 django__django-7530 django__django-16661 django__django-11749 django__django-12304 django__django-12708 django__django-15268; do echo $i; done | xargs -P 6 -n 1 python3 graphs.py > "$E/logs/graphs2.log" 2>&1
avail=$(df --output=avail -BG /mnt/data | tail -1 | tr -dc 0-9); echo "disk after graphs ${avail}G"
ls "$E/graphs" | wc -l
python3 validate_all.py /mnt/data/zhongming/tmp/claude-1003/-home-zhongming-SysEvol-agent-infra-cookbook/3a3a8981-bd1d-4b46-a5b3-fcdbfa9b3f50/scratchpad/guard-evidence/a/guardian_regression_check_v1/items.json 2>&1 | grep -vE 'numexpr|Generating|Warning' > "$E/logs/validate.log"
echo "disk after validation $(df --output=avail -BG /mnt/data | tail -1)"; tail -2 "$E/logs/validate.log" | cut -c1-300
