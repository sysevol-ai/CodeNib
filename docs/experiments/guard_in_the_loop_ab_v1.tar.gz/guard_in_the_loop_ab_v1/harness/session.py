"""Run one Claude Code session in the instance's own container and keep what it did."""
import json, os, re, subprocess, time
from common import *

INSTANCES = json.load(open(E / 'instances.json'))
MODEL, EFFORT, MAX_USD, MAX_SECONDS = 'claude-opus-5-5', 'medium', 3, 1800
SUITE_COMMAND = './tests/runtests.py --settings=test_sqlite --parallel 16'
TAIL = 'Fix this issue in the repository in the current directory. Run tests with `./tests/runtests.py`.'

def settings_for_suite():
    command = f"GUARDAB_SUITE_COMMAND='{SUITE_COMMAND}' {E}/venv/bin/python /opt/guardab/suite_hook.py"
    return json.dumps({'hooks': {'Stop': [{'hooks': [{'type': 'command', 'command': command, 'timeout': 300}]}]}}, indent=2)

def restore_graph(name, iid):
    p = ex(name, f'cd /root && tar -xf /graphs/{iid}.tar')
    if p.returncode:
        raise RuntimeError(f'graph restore failed: {p.stderr[-300:]}')

def summarize(path):
    out = {'cost': None, 'turns': None, 'is_error': None, 'subtype': None, 'duration_ms': None, 'usage': None,
           'hook_context': [], 'tools_total': 0, 'tools_after_hook': 0, 'edits_after_hook': 0,
           'bash_commands': [], 'bash_after_hook': []}
    hooked = False
    for line in open(path, errors='replace'):
        try:
            d = json.loads(line)
        except ValueError:
            continue
        kind = d.get('type')
        if kind == 'result':
            out.update(cost=d.get('total_cost_usd'), turns=d.get('num_turns'), is_error=d.get('is_error'),
                       subtype=d.get('subtype'), duration_ms=d.get('duration_ms'), usage=d.get('usage'))
        elif kind == 'system' and str(d.get('subtype', '')).startswith('hook'):
            text = json.dumps(d)
            if 'additionalContext' in text and d.get('hook_event') == 'Stop':
                out['hook_context'].append(str(d.get('output') or d.get('stdout') or '')[:6000])
                hooked = True
        elif kind == 'assistant':
            for block in d.get('message', {}).get('content', []):
                if block.get('type') != 'tool_use':
                    continue
                out['tools_total'] += 1
                name, inp = block.get('name'), block.get('input', {})
                if name == 'Bash':
                    out['bash_commands'].append(str(inp.get('command'))[:400])
                if hooked:
                    out['tools_after_hook'] += 1
                    if name in ('Edit', 'Write', 'MultiEdit', 'NotebookEdit'):
                        out['edits_after_hook'] += 1
                    if name == 'Bash':
                        out['bash_after_hook'].append(str(inp.get('command'))[:400])
    return out

def run_session(iid, arm, rep, root='sessions'):
    sid = f'{iid}__{arm}__r{rep}'
    folder = E / root / sid
    meta_path = folder / 'meta.json'
    if meta_path.exists():
        return json.load(open(meta_path))
    folder.mkdir(parents=True, exist_ok=True)
    name = 'guardab-s-' + re.sub(r'[^a-z0-9]+', '', f'{root}{iid}{arm}{rep}'.lower())[-40:]
    started = time.time()
    start(name, iid, MOUNTS + [(str(E / 'graphs'), '/graphs', 'ro')])
    try:
        commit = ex(name, SNAP).stdout.strip().splitlines()[-1]
        ex(name, "printf '.claude/\\n.codenib/\\n' >> .git/info/exclude")
        if arm == 'guard':
            restore_graph(name, iid)
            p = ex(name, f'{CODENIB} guard install --agent claude --no-prepare 2>&1')
            if p.returncode:
                raise RuntimeError(f'guard install failed: {p.stdout[-400:]}')
        elif arm == 'suite':
            put(name, '/testbed/.claude/settings.local.json', settings_for_suite())
        elif arm != 'native':
            raise ValueError(arm)
        prompt = f"{INSTANCES[iid]['problem_statement']}\n\n{TAIL}"
        args = ['docker', 'exec', '-i', '-w', '/testbed', '-e', 'ANTHROPIC_API_KEY', '-e', 'IS_SANDBOX=1',
                '-e', 'DISABLE_AUTOUPDATER=1', '-e', 'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1',
                '-e', 'CLAUDE_CODE_DISABLE_AUTO_MEMORY=1', '-e', 'BASH_MAX_TIMEOUT_MS=1500000']
        for item in BASE_ENV:
            args += ['-e', item]
        args += [name, 'timeout', str(MAX_SECONDS), 'claude', '-p', '--model', MODEL, '--effort', EFFORT,
                 '--output-format', 'stream-json', '--verbose', '--include-hook-events',
                 '--max-budget-usd', str(MAX_USD), '--dangerously-skip-permissions', '--strict-mcp-config',
                 '--no-session-persistence', '--disallowedTools', 'WebFetch,WebSearch']
        transcript = folder / 'transcript.jsonl'
        t0 = time.time()
        with open(transcript, 'w') as fh:
            p = subprocess.run(args, input=prompt, stdout=fh, stderr=subprocess.PIPE, text=True, errors='replace',
                               timeout=MAX_SECONDS + 120)
        seconds = time.time() - t0
        key = os.environ.get('ANTHROPIC_API_KEY') or ''
        if key:
            text = transcript.read_text(errors='replace')
            if key in text:
                transcript.write_text(text.replace(key, '<redacted>'))
        diff = ex(name, "git add -A -- . ':(exclude).claude' ':(exclude).codenib' >/dev/null 2>&1; git diff --cached --binary HEAD").stdout
        (folder / 'agent.diff').write_text(diff)
        if arm != 'guard':
            restore_graph(name, iid)
        check = ex(name, f'{CODENIB} guard check --base HEAD --json --no-build 2>/dev/null', timeout=600).stdout
        (folder / 'guard_final.json').write_text(check)
        log = ex(name, "find /root/.codenib* -name '*.log' 2>/dev/null | xargs -r tail -n 20 2>/dev/null").stdout
        (folder / 'guard_hook.log').write_text(log)
        meta = {'sid': sid, 'instance': iid, 'arm': arm, 'rep': rep, 'commit': commit, 'exit': p.returncode,
                'stderr': p.stderr[-400:], 'session_seconds': round(seconds, 1), 'wall_seconds': round(time.time() - started, 1),
                'diff_bytes': len(diff), 'timed_out': p.returncode == 124, **summarize(transcript)}
    finally:
        stop(name)
    meta_path.write_text(json.dumps(meta, indent=1))
    return meta
