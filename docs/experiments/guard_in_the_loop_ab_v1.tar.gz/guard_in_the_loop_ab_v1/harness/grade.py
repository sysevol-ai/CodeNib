"""Grade a patch with no model: the official SWE-bench verdict, then the project's full suite against the gold patch."""
import json, re, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
from common import *
from swebench.harness.grading import get_eval_report
from swebench.harness.test_spec import make_test_spec
from swebench.harness.constants import KEY_INSTANCE_ID, KEY_MODEL, KEY_PREDICTION

FULL = './tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 16'
ONE = './tests/runtests.py --verbosity 2 --settings=test_sqlite --parallel 1'
INSTANCES = json.load(open(E / 'instances.json'))
DATASET_ROWS = None

def rows():
    global DATASET_ROWS
    if DATASET_ROWS is None:
        from datasets import load_dataset
        DATASET_ROWS = {r['instance_id']: r for r in load_dataset('princeton-nlp/SWE-bench_Verified', split='test')}
    return DATASET_ROWS

def parse(log):
    """Tests that failed, as labels the runner accepts, and how many ran."""
    fails = set()
    for line in log.splitlines():
        m = re.match(r'^(?:FAIL|ERROR): (\S+) \(([^)]+)\)', line)
        if not m:
            continue
        name, where = m.groups()
        if where.startswith('unittest.loader'):
            fails.add(name)
        elif name in ('setUpClass', 'tearDownClass', 'setUpModule', 'tearDownModule'):
            fails.add(where)
        else:
            fails.add(where if where.endswith('.' + name) else f'{where}.{name}')
    ran = re.search(r'^Ran (\d+) tests? in', log, re.M)
    return fails, int(ran.group(1)) if ran else None

def without_tests(diff):
    """The patch's sections for files outside tests/."""
    sections = re.split(r'(?m)^(?=diff --git )', diff)
    keep = [x for x in sections if x.strip() and not re.match(r'diff --git a/tests/', x)]
    text = ''.join(keep)
    return text if text.endswith('\n') or not text else text + '\n'

def apply_source(name, iid, diff, label):
    """Apply a patch's non-test changes, then the benchmark's tests. An edit to an existing test cannot hide a failure."""
    put(name, '/tmp/source.diff', without_tests(diff or ''))
    put(name, '/tmp/test.diff', INSTANCES[iid]['test_patch'])
    p = ex(name, "if [ -s /tmp/source.diff ]; then git apply /tmp/source.diff || patch --batch --fuzz=5 -p1 -i /tmp/source.diff || exit 11; fi; git apply /tmp/test.diff || exit 12")
    if p.returncode:
        raise RuntimeError(f'{label}: apply failed {p.returncode}: {p.stderr[-300:]}')

def full_run(iid, diff, label):
    name = f"guardab-g-{re.sub(r'[^a-z0-9]+', '', label.lower())[-34:]}"
    start(name, iid)
    try:
        apply_source(name, iid, diff, label)
        p = ex(name, f'timeout 1500 {FULL} 2>&1', timeout=1600)
    finally:
        stop(name)
    fails, ran = parse(p.stdout)
    return {'fails': sorted(fails), 'ran': ran, 'tail': p.stdout[-400:] if ran is None else ''}

def labels_run(iid, diff, labels, label):
    name = f"guardab-l-{re.sub(r'[^a-z0-9]+', '', label.lower())[-34:]}"
    start(name, iid)
    try:
        apply_source(name, iid, diff, label)
        p = ex(name, f"timeout 900 {ONE} {' '.join(labels)} 2>&1", timeout=1000)
    finally:
        stop(name)
    return parse(p.stdout)[0]

def baseline(iid):
    path = E / 'grading/baseline' / f'{iid}.json'
    if path.exists():
        return json.load(open(path))
    gold = INSTANCES[iid]['patch']
    runs = [full_run(iid, gold, f'gold{k}{iid[-5:]}') for k in (1, 2)]
    out = {'runs': runs, 'fails': sorted(set(runs[0]['fails']) | set(runs[1]['fails'])), 'ran': [r['ran'] for r in runs]}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=1))
    return out

def official(iid, diff, label):
    """The SWE-bench verdict, from its own eval script and its own grading code."""
    name = f"guardab-o-{re.sub(r'[^a-z0-9]+', '', label.lower())[-34:]}"
    start(name, iid)
    try:
        put(name, '/tmp/agent.diff', diff or '')
        p = ex(name, "[ -s /tmp/agent.diff ] || exit 0; git apply --verbose /tmp/agent.diff || git apply --verbose --reject /tmp/agent.diff || patch --batch --fuzz=5 -p1 -i /tmp/agent.diff")
        applied = p.returncode == 0
        put(name, '/eval.sh', INSTANCES[iid]['eval_script'])
        q = ex(name, 'timeout 1500 bash /eval.sh 2>&1', timeout=1600)
    finally:
        stop(name)
    spec = make_test_spec(rows()[iid])
    with tempfile.TemporaryDirectory() as tmp:
        folder = Path(tmp) / iid  # the official parser reads the repository from this folder's name
        folder.mkdir()
        log = folder / 'test_output.txt'
        log.write_text(q.stdout, errors='replace')
        pred = {KEY_INSTANCE_ID: iid, KEY_MODEL: 'x', KEY_PREDICTION: diff or ''}
        report = get_eval_report(spec, pred, str(log), include_tests_status=True)[iid]
    return {'applied': applied, 'resolved': bool(report.get('resolved')), 'patch_exists': report.get('patch_exists'),
            'tests_status': {k: {j: len(w) for j, w in v.items()} for k, v in report.get('tests_status', {}).items()}}

def grade(iid, diff, label):
    base = baseline(iid)
    verdict = official(iid, diff, label)
    if not (diff or '').strip():
        return {**verdict, 'candidates': [], 'regressions': [], 'hidden_regression': False, 'clean_success': False, 'ran': None}
    first = full_run(iid, diff, f'{label}a')
    known = set(base['fails'])
    candidates = sorted(set(first['fails']) - known)
    regressions, isolated, second = [], [], None
    if first['ran'] is None:
        out = {**verdict, 'candidates': [], 'regressions': ['<suite did not finish>'], 'ran': None, 'tail': first['tail']}
    else:
        if candidates:
            second = full_run(iid, diff, f'{label}b')
            regressions = sorted(set(candidates) & set(second['fails']))
        if regressions:
            sample = regressions[:60]
            agent1 = labels_run(iid, diff, sample, f'{label}c')
            gold1 = labels_run(iid, INSTANCES[iid]['patch'], sample, f'{label}d')
            isolated = sorted(agent1 - gold1)
        out = {**verdict, 'candidates': candidates, 'regressions': regressions, 'isolated': isolated,
               'ran': first['ran'], 'gold_ran': base['ran'], 'dropped': (base['ran'][0] or 0) - first['ran']}
    out['hidden_regression'] = verdict['resolved'] and bool(out['regressions'])
    out['clean_success'] = verdict['resolved'] and not out['regressions']
    return out
