"""Stop hook for the suite arm: same event, same output shape and same once-per-change rule as the guard."""
import hashlib, json, os, subprocess, sys

STATE = '/tmp/guardab_suite_reported'
COMMAND = os.environ.get('GUARDAB_SUITE_COMMAND', './tests/runtests.py --settings=test_sqlite --parallel 16')

def git(*args):
    return subprocess.run(['git', *args], capture_output=True, text=True, cwd=os.getcwd()).stdout

def main():
    payload = json.loads(sys.stdin.read() or '{}')
    if payload.get('stop_hook_active'):
        return
    os.chdir(payload.get('cwd') or os.getcwd())
    git('add', '-A', '-N', '--', '.', ':(exclude).claude', ':(exclude).codenib')
    diff = git('diff', 'HEAD', '--', '*.py')
    if not diff.strip():
        return
    digest = hashlib.sha256(diff.encode('utf-8', 'surrogateescape')).hexdigest()
    seen = open(STATE).read().split() if os.path.exists(STATE) else []
    if digest in seen:
        return
    with open(STATE, 'a') as fh:
        fh.write(digest + '\n')
    files = git('diff', 'HEAD', '--name-only', '--', '*.py').split()
    text = (
        f'This session changed {len(files)} Python files since it started.\n'
        f"Command that runs the project's full test suite: {COMMAND}\n"
        'A failure that the change caused needs a fix before the work is done.'
    )
    print(json.dumps({'hookSpecificOutput': {'hookEventName': 'Stop', 'additionalContext': text}}))

if __name__ == '__main__':
    main()
