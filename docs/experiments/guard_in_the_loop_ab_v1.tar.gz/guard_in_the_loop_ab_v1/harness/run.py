"""Run the sessions of a cohort, in a seeded order, and start no session the budget cannot cover."""
import argparse, json, random, threading, time
from concurrent.futures import ThreadPoolExecutor
from common import E
import session as S

a = argparse.ArgumentParser()
a.add_argument('--instances', nargs='+', required=True)
a.add_argument('--arms', nargs='+', default=['native', 'guard', 'suite'])
a.add_argument('--reps', nargs='+', type=int, default=[1])
a.add_argument('--workers', type=int, default=4)
a.add_argument('--cap', type=float, required=True)
a.add_argument('--seed', required=True)
a.add_argument('--root', default='sessions')
o = a.parse_args()

rng = random.Random(o.seed)
tasks = []
for rep in o.reps:
    block = []
    for iid in o.instances:
        arms = o.arms[:]
        rng.shuffle(arms)
        block += [(iid, arm, rep) for arm in arms]
    rng.shuffle(block)
    tasks += block
lock, spent, reserved, skipped, done = threading.Lock(), 0.0, 0.0, [], []
print('order', tasks, flush=True)

def work(task):
    global spent, reserved
    while True:  # the budget is a hard limit: every running session is counted at its own maximum
        with lock:
            if spent + reserved + S.MAX_USD <= o.cap:
                reserved += S.MAX_USD
                break
            if reserved == 0:
                skipped.append(task)
                print('skipped for budget', task, flush=True)
                return
        time.sleep(5)
    try:
        m = S.run_session(*task, root=o.root)
    except Exception as exc:
        m = {'sid': '__'.join(map(str, task)), 'error': str(exc)[-500:], 'cost': None}
    with lock:
        reserved -= S.MAX_USD
        spent += m.get('cost') if m.get('cost') is not None else S.MAX_USD
        done.append(m)
        print(json.dumps({'sid': m.get('sid'), 'cost': m.get('cost'), 'turns': m.get('turns'), 'seconds': m.get('session_seconds'),
                          'diff': m.get('diff_bytes'), 'hook': len(m.get('hook_context') or []), 'after': m.get('tools_after_hook'),
                          'edits_after': m.get('edits_after_hook'), 'timed_out': m.get('timed_out'), 'error': m.get('error'),
                          'spent': round(spent, 2)}), flush=True)

with ThreadPoolExecutor(o.workers) as pool:
    list(pool.map(work, tasks))
print('finished', len(done), 'skipped', len(skipped), 'observed cost', round(spent, 2), flush=True)
