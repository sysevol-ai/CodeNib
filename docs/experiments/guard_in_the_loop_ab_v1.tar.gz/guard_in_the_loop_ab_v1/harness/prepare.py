"""Freeze the instance data the experiment reads, with no model involved."""
import json, random, sys
from pathlib import Path
from datasets import load_dataset
from swebench.harness.test_spec import make_test_spec

E = Path(sys.argv[1])
items = json.load(open(sys.argv[2]))
ids = sorted({i['instance_id'] for i in items})
rows = {r['instance_id']: r for r in load_dataset('princeton-nlp/SWE-bench_Verified', split='test') if r['instance_id'] in ids}
out = {}
for iid, r in sorted(rows.items()):
    spec = make_test_spec(r)
    out[iid] = {
        'instance_id': iid, 'repo': r['repo'], 'version': r['version'], 'base_commit': r['base_commit'],
        'problem_statement': r['problem_statement'], 'patch': r['patch'], 'test_patch': r['test_patch'],
        'FAIL_TO_PASS': json.loads(r['FAIL_TO_PASS']), 'PASS_TO_PASS': json.loads(r['PASS_TO_PASS']),
        'image': spec.instance_image_key, 'eval_script': spec.eval_script,
    }
(E / 'instances.json').write_text(json.dumps(out, indent=1))
django = sorted(i for i in out if i.startswith('django__'))
order = django[:]
random.Random('guard-ab-v1').shuffle(order)
print('django instances', len(django)); print('shuffled order', order)
print(out[order[0]]['image']); print(out[order[0]]['eval_script'][:1800])
