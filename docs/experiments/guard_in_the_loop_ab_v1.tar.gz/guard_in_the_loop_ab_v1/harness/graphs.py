"""Build the guard's graph once per instance, before any model call, so every session starts from the same graph."""
import sys, time
from common import *
for iid in sys.argv[1:]:
    tar = E / 'graphs' / f'{iid}.tar'
    if tar.exists():
        print(iid, 'exists'); continue
    name = f'guardab-graph-{iid[-5:]}'
    pull = sh(['docker', 'pull', '-q', image(iid)])
    start(name, iid, MOUNTS + [(str(E / 'graphs'), '/graphs', 'rw')])
    commit = ex(name, SNAP).stdout.strip().splitlines()[-1]
    t = time.time(); p = ex(name, f"{CODENIB} guard prepare 2>&1 | tail -3", timeout=1500); dt = time.time() - t
    q = ex(name, f"cd /root && tar -cf /graphs/{iid}.tar .codenib* && chmod a+rw /graphs/{iid}.tar && du -sh .codenib* | tail -2; ls -a | head -20")
    print(iid, 'commit', commit[:12], f'prepare {dt:.0f}s', p.stdout.strip()[-160:], '|', q.stdout.strip()[-120:], q.stderr[-200:], flush=True)
    stop(name)
