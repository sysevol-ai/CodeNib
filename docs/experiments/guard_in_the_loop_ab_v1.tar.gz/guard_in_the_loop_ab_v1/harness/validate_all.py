"""Check the grader against PatchDiff's labels on every Django patch, with no model."""
import json, re, sys
from concurrent.futures import ThreadPoolExecutor
from common import E
import grade as G
items = [i for i in json.load(open(sys.argv[1])) if i['instance_id'].startswith('django__')]
tag = {}
def norm(label):
    m = re.search(r'::(\S+) \(([^)]+)\)', label)
    if m:
        return f"{m.group(2).split('.')[-1]}.{m.group(1)}"
    return '.'.join(label.replace('::', '.').split('.')[-2:])
def admit(iid):
    g = G.official(iid, G.INSTANCES[iid]['patch'], f'adm{iid[-5:]}')
    b = G.baseline(iid)
    return {'instance': iid, 'gold_resolved': g['resolved'], 'ran': b['ran'], 'known_failures': len(b['fails'])}
def one(args):
    k, it = args
    cache = E / 'grading/validation_rows' / f'{k}.json'
    if cache.exists():
        return json.load(open(cache))
    try:
        r = G.grade(it['instance_id'], it['patch'], f"v{k}{it['kind'][:1]}{it['instance_id'][-5:]}")
    except Exception as exc:
        row = {'instance': it['instance_id'], 'tool': it['tool'], 'kind': it['kind'], 'error': str(exc)[-300:], 'resolved': None, 'expected': len(it['broken']), 'found': 0, 'overlap': 0, 'extra': [], 'missing': [], 'ran': None, 'dropped': None}
        cache.parent.mkdir(parents=True, exist_ok=True); cache.write_text(json.dumps(row))
        print(json.dumps(row), flush=True)
        return row
    want = {norm(b) for b in it['broken']}
    got = {'.'.join(x.split('.')[-2:]) for x in r['regressions']}
    row = {'instance': it['instance_id'], 'tool': it['tool'], 'kind': it['kind'], 'resolved': r['resolved'], 'expected': len(want), 'found': len(got),
           'overlap': len(want & got), 'extra': sorted(got - want)[:6], 'missing': sorted(want - got)[:6], 'ran': r.get('ran'), 'dropped': r.get('dropped')}
    print(json.dumps(row), flush=True)
    cache.parent.mkdir(parents=True, exist_ok=True); cache.write_text(json.dumps(row))
    return row
ids = sorted({i['instance_id'] for i in items})
with ThreadPoolExecutor(4) as pool:
    adm = list(pool.map(admit, ids))
(E / 'grading/admission.json').write_text(json.dumps(adm, indent=1))
print('admission', json.dumps(adm), flush=True)
with ThreadPoolExecutor(4) as pool:
    rows = list(pool.map(one, list(enumerate(items))))
(E / 'grading/validation.json').write_text(json.dumps(rows, indent=1))
print('validation done', len(rows), flush=True)
