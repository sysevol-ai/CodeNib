import json, sys
from concurrent.futures import ThreadPoolExecutor
import grade as G
items = json.load(open(sys.argv[1]))
want = [('django__django-15022','OpenHands'),('django__django-11880','CodeStory'),('django__django-12273','CodeStory'),('django__django-12708','CodeStory'),('django__django-13012','CodeStory'),('django__django-13279','CodeStory'),('django__django-14771','CodeStory'),('django__django-7530','OpenHands'),('django__django-16661','OpenHands')]
def one(pair):
    iid, tool = pair
    it = [i for i in items if i['instance_id'] == iid and i['tool'] == tool][0]
    p = it['patch']; src = G.without_tests(p)
    sections = [l for l in p.splitlines() if l.startswith('diff --git ')]
    o = G.official(iid, p, f'diag{tool[:2]}{iid[-5:]}')
    row = {'instance': iid, 'tool': tool, 'kind': it['kind'], 'patch_bytes': len(p), 'source_bytes': len(src), 'files': sections[:4], 'applied': o['applied'], 'resolved': o['resolved'], 'status': o['tests_status'], 'broken_labels': it['broken'][:2]}
    if iid.endswith(('7530', '16661')):
        base = G.baseline(iid); first = G.full_run(iid, p, f'dgf{tool[:2]}{iid[-5:]}')
        row['full_new_failures'] = sorted(set(first['fails']) - set(base['fails']))[:5]
    return row
with ThreadPoolExecutor(4) as pool:
    for r in pool.map(one, want):
        print(json.dumps(r)[:900], flush=True)
