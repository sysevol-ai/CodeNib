"""Grade every session of a cohort with no model, and write one results file."""
import json, re, sys
from concurrent.futures import ThreadPoolExecutor
from common import E
import grade as G

root = E / sys.argv[1]
sessions = sorted(p for p in root.iterdir() if (p / 'meta.json').exists())

def flagged_ids(folder):
    try:
        data = json.loads((folder / 'guard_final.json').read_text())
    except ValueError:
        return None
    return [t.get('test_id') for t in data.get('tests_at_risk', [])]

def key(label):
    parts = label.split('.')
    return '.'.join(parts[-2:])

def one(folder):
    meta = json.load(open(folder / 'meta.json'))
    out_path = folder / 'grade.json'
    if out_path.exists():
        g = json.load(open(out_path))
    else:
        diff = (folder / 'agent.diff').read_text(errors='replace')
        g = G.grade(meta['instance'], diff, f"{meta['arm']}{meta['rep']}{meta['instance'][-5:]}")
        out_path.write_text(json.dumps(g, indent=1))
    flagged = flagged_ids(folder)
    keys = {key(re.sub(r'::', '.', t.split('.py::')[-1])) for t in (flagged or []) if t}
    return {**{k: meta.get(k) for k in ('sid', 'instance', 'arm', 'rep', 'cost', 'turns', 'session_seconds', 'diff_bytes', 'timed_out', 'subtype', 'tools_after_hook', 'edits_after_hook')},
            'hook_fired': len(meta.get('hook_context') or []), 'resolved': g['resolved'], 'applied': g.get('applied'), 'candidates': g['candidates'],
            'regressions': g['regressions'], 'isolated': g.get('isolated', []), 'hidden_regression': g['hidden_regression'], 'clean_success': g['clean_success'],
            'ran': g.get('ran'), 'dropped': g.get('dropped'), 'guard_flagged': None if flagged is None else len(flagged),
            'regressions_in_guard_list': [r for r in g['regressions'] if key(r) in keys]}

with ThreadPoolExecutor(3) as pool:
    results = list(pool.map(one, sessions))
(root / 'results.json').write_text(json.dumps(results, indent=1))
print('graded', len(results))
