"""Known answers before any model call: gold, an old agent's patch known to break tests, and one known not to."""
import json, sys
from concurrent.futures import ThreadPoolExecutor
from common import *
import grade as G
items = json.load(open(sys.argv[1]))
iid = sys.argv[2]
cases = [('gold', G.INSTANCES[iid]['patch'], None)]
for k, it in enumerate(i for i in items if i['instance_id'] == iid):
    cases.append((f"{it['kind']}{k}", it['patch'], it['broken']))
G.baseline(iid)
print('baseline', iid, 'ran', G.baseline(iid)['ran'], 'known failures', len(G.baseline(iid)['fails']))
with ThreadPoolExecutor(3) as pool:
    futs = [(label, want, pool.submit(G.grade, iid, patch, f'val{label}{iid[-5:]}')) for label, patch, want in cases]
    for label, want, f in futs:
        r = f.result()
        print(json.dumps({'case': label, 'resolved': r['resolved'], 'regressions': r['regressions'][:8], 'isolated': r.get('isolated', [])[:8], 'ran': r['ran'], 'dropped': r.get('dropped'), 'expected_broken': (want or [])[:8]}))
