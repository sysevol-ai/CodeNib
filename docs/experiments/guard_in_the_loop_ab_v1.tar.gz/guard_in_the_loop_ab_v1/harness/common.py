import json, os, re, subprocess, time
from pathlib import Path

E = Path('/mnt/data/zhongming/guard-ab-v1')
SNAP = ("git ls-files -z > /tmp/tracked; rm -rf .git; git init -q; git config user.email snapshot@example.com; "
        "git config user.name snapshot; git config core.fileMode false; git add -A; xargs -0 -a /tmp/tracked git add -f -- ; "
        "GIT_AUTHOR_DATE=2000-01-01T00:00:00Z GIT_COMMITTER_DATE=2000-01-01T00:00:00Z git commit -q -m snapshot --no-verify; git rev-parse HEAD")
PATH = '/opt/miniconda3/envs/testbed/bin:/opt/miniconda3/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
LOCALE = ['LANG=en_US.UTF-8', 'LC_ALL=en_US.UTF-8', 'LANGUAGE=en_US:en', 'PYTHONIOENCODING=utf8']
BASE_ENV = [f'PATH={PATH}', 'CONDA_PREFIX=/opt/miniconda3/envs/testbed', 'CONDA_DEFAULT_ENV=testbed', 'HOME=/root', *LOCALE]

def image(iid):
    return f"swebench/sweb.eval.x86_64.{iid.replace('__', '_1776_')}:latest".lower()

def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, errors='replace', **kw)

def start(name, iid, mounts=()):
    sh(['docker', 'rm', '-f', name])
    args = ['docker', 'run', '-d', '--name', name, '--cpus', '16', '--memory', '48g', '--pids-limit', '8192']
    for host, inner, mode in mounts:
        args += ['-v', f'{host}:{inner}:{mode}']
    p = sh(args + ['--entrypoint', 'sleep', image(iid), 'infinity'])
    if p.returncode:
        raise RuntimeError(p.stderr[-400:])
    ex(name, "sed -i '/en_US.UTF-8/s/^# //g' /etc/locale.gen && locale-gen >/dev/null 2>&1; git config --global --add safe.directory /testbed")

def stop(name):
    sh(['docker', 'rm', '-f', name])

def ex(name, cmd, env=(), timeout=None, stdin=None):
    args = ['docker', 'exec', '-i', '-w', '/testbed']
    for item in [*BASE_ENV, *env]:
        args += ['-e', item]
    return subprocess.run(args + [name, 'bash', '-c', cmd], input=stdin, capture_output=True, text=True, errors='replace', timeout=timeout)

def put(name, path, text):
    p = ex(name, f'mkdir -p "$(dirname {path})" && cat > {path}', stdin=text)
    if p.returncode:
        raise RuntimeError(p.stderr[-300:])

MOUNTS = [(str(E / 'venv'), str(E / 'venv'), 'ro'), (str(E / 'py'), str(E / 'py'), 'ro'),
          (str(E / 'bin/claude'), '/usr/local/bin/claude', 'ro'), (str(E / 'harness/suite_hook.py'), '/opt/guardab/suite_hook.py', 'ro')]
CODENIB = str(E / 'venv/bin/codenib')
