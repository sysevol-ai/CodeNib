"""Fetch each case's pre-fix snapshot, derive gold locations, lay out workspaces."""
import ast, json, re, shutil, subprocess, sys, tarfile, io
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v6")
GIT = ["git", "-c", "user.name=snapshot", "-c", "user.email=snapshot@example.invalid",
       "-c", "gc.auto=0", "-c", "maintenance.auto=false"]

def name(repo):
    return repo.split("/")[1].lower()

def gold_functions(source, lines):
    """Innermost enclosing def/class qualified name for each changed base line."""
    tree = ast.parse(source)
    spans = []
    def walk(node, prefix):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                qual = prefix + child.name
                start = min([child.lineno] + [d.lineno for d in child.decorator_list])
                spans.append((start, child.end_lineno, qual, isinstance(child, ast.ClassDef)))
                walk(child, qual + ".")
            else:
                walk(child, prefix)
    walk(tree, "")
    found = set()
    for line in lines:
        inner = [s for s in spans if s[0] <= line <= s[1]]
        if inner:
            found.add(max(inner, key=lambda s: s[0])[2])
    return sorted(found)

def changed_base_lines(diff, path):
    """Base-side line numbers touched by each hunk of *path*."""
    lines, active, old = [], False, 0
    for row in diff.splitlines():
        if row.startswith("diff --git"):
            active = row.endswith(" b/" + path)
            continue
        if not active:
            continue
        m = re.match(r"@@ -(\d+)(?:,(\d+))? \+", row)
        if m:
            old = int(m.group(1)); continue
        if row.startswith(("---", "+++")):
            continue
        if row.startswith("-"):
            lines.append(old); old += 1
        elif row.startswith("+"):
            lines.append(max(old - 1, 1))   # an insertion belongs to the line above it
        elif row.startswith(" "):
            old += 1
    return sorted(set(lines))

def prepare(case):
    key = name(case["repo"])
    home = ROOT / "ws" / key
    if (home / "case.json").exists():
        return json.loads((home / "case.json").read_text())
    shutil.rmtree(home, ignore_errors=True)
    home.mkdir(parents=True)
    blob = subprocess.check_output(["gh", "api", f"repos/{case['repo']}/tarball/{case['base_commit']}"])
    with tarfile.open(fileobj=io.BytesIO(blob)) as tar:
        top = tar.getnames()[0].split("/")[0]
        tar.extractall(home / "x", filter="data")
    (home / "x" / top).rename(home / "native")
    shutil.rmtree(home / "x")
    subprocess.check_call(GIT + ["init", "-q"], cwd=home / "native")
    subprocess.check_call(GIT + ["add", "-A", "-f"], cwd=home / "native")
    subprocess.check_call(GIT + ["commit", "-qm", "Snapshot"], cwd=home / "native")
    shutil.copytree(home / "native", home / "codenib", symlinks=True)
    diff = subprocess.check_output(
        ["gh", "api", "-H", "Accept: application/vnd.github.diff",
         f"repos/{case['repo']}/compare/{case['base_commit']}...{case['merge_commit']}"], text=True)
    (home / "fix.diff").write_text(diff)
    gold = {}
    for path in case["gold_files"]:
        source = (home / "native" / path).read_text()
        gold[path] = gold_functions(source, changed_base_lines(diff, path))
    py = [p for p in (home / "native").rglob("*.py") if ".git" not in p.parts]
    record = {**case, "key": key, "gold_functions": gold,
              "python_files": len(py),
              "python_lines": sum(len(p.read_bytes().splitlines()) for p in py)}
    (home / "case.json").write_text(json.dumps(record, indent=1))
    return record

if __name__ == "__main__":
    for case in json.load(open(ROOT / "candidates.json")):
        try:
            r = prepare(case)
            print(r["key"], r["python_files"], r["python_lines"], r["gold_functions"], flush=True)
        except Exception as exc:
            print(name(case["repo"]), "FAILED", repr(exc)[:300], flush=True)
