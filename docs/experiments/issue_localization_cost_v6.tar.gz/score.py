"""Score every session against the fix and apply the sealed decision rule."""
import json, re, statistics, sys
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v6")
POLICY = json.loads((ROOT / "policy.json").read_text())

def answer_json(text):
    blocks = re.findall(r"```json\s*(\{.*?\})\s*```", text or "", flags=re.S)
    for raw in reversed(blocks):
        try:
            data = json.loads(raw)
        except ValueError:
            continue
        if isinstance(data, dict) and "files" in data:
            return data
    return None

def norm(path, key):
    path = str(path).strip()
    for arm in ("native", "codenib"):
        prefix = str(ROOT / "ws" / key / arm) + "/"
        if path.startswith(prefix):
            path = path[len(prefix):]
    return path.lstrip("./")

def same_function(predicted, gold):
    predicted = predicted.strip().rstrip("()")
    return predicted == gold or gold.endswith("." + predicted) or predicted.endswith("." + gold)

def score(record, case):
    key = case["key"]
    result = record.get("result") or {}
    usage = result.get("model_usage") or {}
    tokens = sum(sum(v.get(k) or 0 for k in ("inputTokens", "cacheCreationInputTokens",
                                               "cacheReadInputTokens", "outputTokens"))
                 for v in usage.values())
    output = sum(v.get("outputTokens") or 0 for v in usage.values())
    answer = answer_json(record.get("answer")) or {}
    files = [norm(p, key) for p in (answer.get("files") or []) if isinstance(p, str)][:5]
    functions = [(norm(f.get("file", ""), key), str(f.get("name", "")))
                 for f in (answer.get("functions") or []) if isinstance(f, dict)][:8]
    gold_files = case["gold_files"]
    gold_functions = [(path, name) for path, names in case["gold_functions"].items() for name in names]
    hit = [(gp, gn) for gp, gn in gold_functions
           if any(fp == gp and same_function(fn, gn) for fp, fn in functions)]
    tools = record.get("tools") or []
    return {
        "label": record["label"], "case": key, "arm": record["arm"],
        "valid": bool(result) and result.get("subtype") in ("success", "error_max_turns"),
        "subtype": result.get("subtype"), "answered": bool(answer),
        "located": bool(files) and all(g in files for g in gold_files),
        "file_recall": sum(g in files for g in gold_files) / len(gold_files),
        "top1": bool(files) and files[0] in gold_files,
        "function_recall": (len(hit) / len(gold_functions)) if gold_functions else None,
        "tokens": tokens, "output_tokens": output, "turns": result.get("num_turns"),
        "cost": result.get("total_cost_usd"), "peak_context": record.get("peak_context_tokens"),
        "tool_calls": len(tools), "explore_calls": sum(t.endswith("explore_context") for t in tools),
        "first_tool": tools[0] if tools else None,
        "tool_result_chars": record.get("tool_result_chars"),
        "query_seconds": record.get("query_seconds"), "api_ms": result.get("duration_api_ms"),
    }

def load():
    rows = {}
    for folder in sorted((ROOT / "runs").iterdir()):
        path = folder / "record.json"
        if folder.name.startswith("smoke") or not path.exists():
            continue
        record = json.loads(path.read_text())
        case = json.loads((ROOT / "ws" / record["case"] / "case.json").read_text())
        row = score(record, case)
        base = row["label"].removesuffix("-retry")
        # A retry replaces its first attempt only when that attempt was not valid.
        if base not in rows or not rows[base]["valid"]:
            rows[base] = row
    return list(rows.values())

def med(values):
    values = [v for v in values if v is not None]
    return statistics.median(values) if values else None

def compare(rows, arm, base="native"):
    out = {"arm": arm, "cases": {}}
    for metric in ("tokens", "turns", "cost", "output_tokens", "peak_context",
                   "tool_calls", "query_seconds", "api_ms"):
        ratios = {}
        for case in POLICY["cases"]:
            a = med([r[metric] for r in rows if r["case"] == case and r["arm"] == arm and r["valid"]])
            b = med([r[metric] for r in rows if r["case"] == case and r["arm"] == base and r["valid"]])
            if a is not None and b:
                ratios[case] = a / b
        out[metric] = {"median_ratio": med(list(ratios.values())),
                       "cases_lower": sum(v < 1 for v in ratios.values()),
                       "cases": len(ratios), "ratios": ratios}
    located = lambda name: sum(r["located"] for r in rows if r["arm"] == name)
    out["located"], out["located_base"] = located(arm), located(base)
    t, n = out["tokens"], out["turns"]
    non_inferior = out["located"] >= out["located_base"] - 2
    if t["median_ratio"] is not None and t["median_ratio"] <= 0.70 and t["cases_lower"] >= 9 and non_inferior:
        out["verdict"] = "cost benefit"
    elif n["median_ratio"] is not None and n["median_ratio"] <= 0.80 and n["cases_lower"] >= 9 and non_inferior:
        out["verdict"] = "fewer steps without a demonstrated token saving"
    elif t["median_ratio"] is not None and t["median_ratio"] >= 1.30 and t["cases_lower"] <= 3:
        out["verdict"] = "costs more"
    else:
        out["verdict"] = "no demonstrated cost benefit"
    return out

if __name__ == "__main__":
    rows = load()
    summary = {"sessions": len(rows), "arms": {}}
    for arm in POLICY["arms"]:
        mine = [r for r in rows if r["arm"] == arm]
        summary["arms"][arm] = {
            "sessions": len(mine), "valid": sum(r["valid"] for r in mine),
            "located": sum(r["located"] for r in mine), "top1": sum(r["top1"] for r in mine),
            "file_recall": statistics.mean(r["file_recall"] for r in mine) if mine else None,
            "function_recall": statistics.mean(r["function_recall"] for r in mine if r["function_recall"] is not None) if mine else None,
            **{f"median_{m}": med([r[m] for r in mine if r["valid"]])
               for m in ("tokens", "turns", "cost", "output_tokens", "peak_context",
                         "tool_calls", "query_seconds", "api_ms", "tool_result_chars")},
            "total_cost": sum(r["cost"] or 0 for r in mine),
            "explore_sessions": sum(r["explore_calls"] > 0 for r in mine),
            "explore_first": sum(str(r["first_tool"]).endswith("explore_context") for r in mine),
        }
    summary["comparisons"] = [compare(rows, arm) for arm in POLICY["arms"] if arm != "native"]
    (ROOT / "scores.json").write_text(json.dumps({"rows": rows, "summary": summary}, indent=1))
    print(json.dumps(summary, indent=1))
