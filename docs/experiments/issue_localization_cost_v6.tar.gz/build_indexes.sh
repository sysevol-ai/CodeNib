#!/bin/bash
# Build BM25 + symbol graph for every CodeNib workspace; 15-minute limit each.
C=/home/zhongming/.venvs/codenib/bin/codenib
cd /tmp/codenib-ab-v6
build() {
  k=$1; s=$(date +%s)
  timeout 900 $C index ws/$k/codenib --preset graph --language python > index-logs/$k.log 2>&1
  rc=$?; e=$(date +%s)
  echo "{\"key\": \"$k\", \"exit\": $rc, \"seconds\": $((e-s))}" > index-logs/$k.json
  echo "$k exit=$rc seconds=$((e-s))"
}
export -f build; export C
ls ws | xargs -P 3 -I{} bash -c 'build {}'
