"""Model-free admission: both views fresh, and one graph query answers."""
import asyncio, json, sys, time
from pathlib import Path
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path("/tmp/codenib-ab-v6")

async def admit(key):
    case = json.loads((ROOT / "ws" / key / "case.json").read_text())
    build = json.loads((ROOT / "index-logs" / f"{key}.json").read_text())
    ws = ROOT / "ws" / key / "codenib"
    params = StdioServerParameters(
        command="/home/zhongming/.venvs/codenib/bin/python",
        args=["-m", "codenib", "mcp", str(ws), "--tool-surface", "explore",
              "--explore-output", "json"],
        env={"PYTHONPATH": str(ROOT / "codenib-src"), "PATH": "/usr/bin:/bin"})
    started = time.monotonic()
    async with stdio_client(params) as (r, w):
        async with ClientSession(r, w) as session:
            await session.initialize()
            ready = time.monotonic() - started
            tools = [t.name for t in (await session.list_tools()).tools]
            t0 = time.monotonic()
            out = await session.call_tool("explore_context", {"query": case["issue"]["title"]})
            call = time.monotonic() - t0
    data = (getattr(out, "structuredContent", None) or getattr(out, "structured_content", None)
            or json.loads(out.content[0].text))
    data = data.get("result", data)
    codes = [d["code"] for d in data.get("diagnostics", [])]
    plan = data.get("plan", {})
    ok = (build["exit"] == 0 and not (getattr(out, "isError", None) or getattr(out, "is_error", None)) and tools == ["explore_context"]
          and bool(data.get("files")) and data.get("source", {}).get("verified") is True
          and plan.get("dependencies", {}).get("enabled") is True
          and not {"graph_unavailable", "graph_preparing", "route_unavailable"} & set(codes))
    return {"key": key, "admitted": ok, "index_seconds": build["seconds"],
            "server_ready_seconds": round(ready, 2), "first_call_seconds": round(call, 2),
            "files": len(data.get("files", [])), "diagnostics": codes,
            "dependencies_enabled": plan.get("dependencies", {}).get("enabled")}

async def main():
    out = []
    for key in sorted(p.name for p in (ROOT / "ws").iterdir()):
        try:
            rec = await admit(key)
        except Exception as exc:  # noqa: BLE001
            rec = {"key": key, "admitted": False, "error": repr(exc)[:300]}
        print(json.dumps(rec), flush=True)
        out.append(rec)
    (ROOT / "admission.json").write_text(json.dumps(out, indent=1))

asyncio.run(main())
