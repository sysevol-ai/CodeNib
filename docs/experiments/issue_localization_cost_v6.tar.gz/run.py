"""Run one localization session: python run.py <case> <arm> <label> [model]."""
import asyncio, dataclasses, json, os, sys, time
from pathlib import Path
from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient, HookMatcher

ROOT = Path("/tmp/codenib-ab-v6")
CLI = "/home/zhongming/.local/bin/claude"
CODENIB_PY = "/home/zhongming/.venvs/codenib/bin/python"
CODENIB_SRC = str(ROOT / "codenib-src")
TOOLS = ["Read", "Grep", "Glob"]
LIMIT_SECONDS = 600
MAX_TURNS = 30
SYSTEM = ("Use only this checkout and its available tools. Cite repository-relative "
          "paths. You cannot run code or edit files.")
DIRECTED = (" This checkout has a prebuilt code graph. Make explore_context your first "
            "tool call: pass the issue in your own words as the query and any symbols it "
            "names. Then confirm in source, with Read or Grep, only what you still need.")
PROMPT = """A user filed this issue against {repo}. The repository is checked out in the current directory at the commit the issue was reported against.

<issue>
Title: {title}

{body}
</issue>

Find where in the source the fix has to be made. Do not write the fix. Stop as soon as you are confident.

End your answer with one JSON object in a ```json block, and nothing after it:
{{"files": ["repository/relative/path.py"], "functions": [{{"file": "repository/relative/path.py", "name": "Class.method"}}]}}

"files" lists the existing non-test source files that must change, most likely first, at most 5. "functions" lists the functions, methods or classes that must change, most likely first, at most 8."""


def prompt(case):
    return PROMPT.format(repo=case["repo"], title=case["issue"]["title"],
                         body=case["issue"]["body"])


def scope(workspace):
    workspace = Path(workspace).resolve()

    async def before(data, tool_id, context):
        name, args = data["tool_name"], data["tool_input"]
        allowed = name.startswith("mcp__codenib__")
        if name in TOOLS:
            raw = args.get("file_path") if name == "Read" else (args.get("path") or str(workspace))
            path = Path(str(raw)).expanduser()
            path = (path if path.is_absolute() else workspace / path).resolve()
            pattern = str(args.get("pattern", "")) if name == "Glob" else str(args.get("glob", "") or "")
            allowed = path.is_relative_to(workspace) and ".." not in pattern and not pattern.startswith("/")
        out = {"hookEventName": "PreToolUse",
               "permissionDecision": "allow" if allowed else "deny"}
        if not allowed:
            out["permissionDecisionReason"] = "Access is limited to this checkout."
        return {"hookSpecificOutput": out}

    return before


async def run(case, arm, label, model):
    workspace = ROOT / "ws" / case["key"] / ("native" if arm == "native" else "codenib")
    folder = ROOT / "runs" / label
    folder.mkdir(parents=True, exist_ok=True)
    trace = folder / "sdk.jsonl"
    trace.write_text("")
    servers = {}
    if arm != "native":
        servers = {"codenib": {"command": CODENIB_PY,
                               "args": ["-m", "codenib", "mcp", str(workspace),
                                        "--tool-surface", "explore"],
                               "env": {"PYTHONPATH": CODENIB_SRC}}}
    for key in list(os.environ):
        if key.startswith(("CLAUDE_CODE_", "CLAUDECODE", "ANTHROPIC_")):
            os.environ.pop(key)
    options = ClaudeAgentOptions(
        cwd=str(workspace), cli_path=CLI, tools=TOOLS,
        allowed_tools=TOOLS + ["mcp__codenib__*"],
        setting_sources=[], skills=[], plugins=[], strict_mcp_config=True,
        mcp_servers=servers, model=model, effort="medium",
        thinking={"type": "adaptive", "display": "omitted"},
        max_turns=MAX_TURNS,
        env={"CLAUDE_CODE_MAX_OUTPUT_TOKENS": "16384", "ENABLE_TOOL_SEARCH": "false",
             "MCP_CONNECTION_NONBLOCKING": "0", "MCP_TIMEOUT": "120000"},
        hooks={"PreToolUse": [HookMatcher(hooks=[scope(workspace)])]},
        system_prompt={"type": "preset", "preset": "claude_code", "append": SYSTEM + (DIRECTED if arm == "codenib-directed" else "")},
        max_buffer_size=16 * 1024 * 1024)
    record = {"case": case["key"], "arm": arm, "label": label, "model": model,
              "started": time.time(), "tools": [], "peak_context_tokens": 0,
              "tool_result_chars": 0, "rate_events": []}
    client = ClaudeSDKClient(options=options)
    started = time.monotonic()

    def log(payload):
        with trace.open("a") as stream:
            stream.write(json.dumps(payload, default=str) + "\n")

    async def consume():
        await client.connect()
        record["connect_seconds"] = time.monotonic() - started
        record["query_started"] = time.monotonic()
        await client.query(prompt(case))
        async for message in client.receive_response():
            kind = type(message).__name__
            if kind == "SystemMessage" and message.subtype == "init":
                record["init"] = {k: message.data.get(k) for k in
                                  ("model", "apiKeySource", "tools", "mcp_servers",
                                   "claude_code_version")}
                log({"type": "init", "data": record["init"]})
            elif kind == "RateLimitEvent":
                record["rate_events"].append(dataclasses.asdict(message))
            elif kind == "AssistantMessage":
                usage = getattr(message, "usage", None) or {}
                context = sum(usage.get(k) or 0 for k in
                              ("input_tokens", "cache_creation_input_tokens",
                               "cache_read_input_tokens"))
                record["peak_context_tokens"] = max(record["peak_context_tokens"], context)
                blocks = [dataclasses.asdict(b) for b in message.content
                          if type(b).__name__ in {"TextBlock", "ToolUseBlock"}]
                for b in message.content:
                    if type(b).__name__ == "ToolUseBlock":
                        record["tools"].append(b.name)
                    elif type(b).__name__ == "TextBlock":
                        record["answer"] = b.text
                log({"type": kind, "usage": usage, "content": blocks})
            elif kind == "UserMessage" and not isinstance(message.content, str):
                blocks = [dataclasses.asdict(b) for b in message.content
                          if type(b).__name__ == "ToolResultBlock"]
                record["tool_result_chars"] += sum(len(json.dumps(b.get("content"), default=str))
                                                   for b in blocks)
                log({"type": kind, "content": blocks})
            elif kind == "ResultMessage":
                record["result"] = dataclasses.asdict(message)
                log({"type": kind, "data": record["result"]})

    try:
        await asyncio.wait_for(consume(), timeout=LIMIT_SECONDS)
        record["outcome"] = "complete"
    except asyncio.TimeoutError:
        record["outcome"] = "timeout"
    except Exception as exc:  # noqa: BLE001
        record["outcome"] = "error: " + repr(exc)[:300]
    finally:
        try:
            await asyncio.wait_for(client.disconnect(), timeout=30)
        except Exception:  # noqa: BLE001
            pass
    record["wall_seconds"] = time.monotonic() - started
    record["query_seconds"] = time.monotonic() - record.get("query_started", started)
    (folder / "record.json").write_text(json.dumps(record, indent=1, default=str))
    return record


if __name__ == "__main__":
    key, arm, label = sys.argv[1:4]
    model = sys.argv[4] if len(sys.argv) > 4 else "claude-sonnet-5-5"
    case = json.loads((ROOT / "ws" / key / "case.json").read_text())
    r = asyncio.run(run(case, arm, label, model))
    res = r.get("result") or {}
    print(label, r["outcome"], "turns", res.get("num_turns"), "cost", res.get("total_cost_usd"),
          "wall", round(r["wall_seconds"], 1), "tools", r["tools"])
