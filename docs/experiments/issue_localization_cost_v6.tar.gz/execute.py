"""Run the sealed schedule: 12 cases x 3 repetitions x 3 arms, three workers."""
import json, random, subprocess, sys, threading, time
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v6")
POLICY = json.loads((ROOT / "policy.json").read_text())
PY = "/tmp/codenib-sdk-probe-20261027/venv/bin/python"
lock = threading.Lock()
spent = [0.0]

def schedule():
    rng = random.Random(POLICY["seed"])
    triples = [(c, r) for r in range(1, POLICY["repetitions"] + 1) for c in POLICY["cases"]]
    rng.shuffle(triples)
    plan = []
    for index, (case, rep) in enumerate(triples):
        arms = list(POLICY["arms"])
        rng.shuffle(arms)
        plan.append([(f"{index:02d}-{case}-r{rep}-{arm}", case, arm) for arm in arms])
    return plan

def session(label, case, arm, attempt=1):
    name = label if attempt == 1 else f"{label}-retry"
    record = ROOT / "runs" / name / "record.json"
    if not record.exists():
        subprocess.run([PY, str(ROOT / "run.py"), case, arm, name, POLICY["model"]],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=POLICY["session_limit_seconds"] + 120, check=False)
    data = json.loads(record.read_text()) if record.exists() else {"outcome": "error: no record"}
    result = data.get("result") or {}
    infra = (not result or data["outcome"].startswith("error")
             or result.get("subtype") == "error_during_execution")
    with lock:
        spent[0] += result.get("total_cost_usd") or 0.0
        print(time.strftime("%H:%M:%S"), name, data["outcome"], result.get("subtype"),
              "turns", result.get("num_turns"), "cost", round(result.get("total_cost_usd") or 0, 4),
              "total", round(spent[0], 2), flush=True)
    if infra and attempt == 1:
        session(label, case, arm, attempt=2)

def worker(queue):
    while True:
        with lock:
            if not queue or spent[0] >= POLICY["stop_usd"]:
                return
            triple = queue.pop(0)
        for label, case, arm in triple:
            session(label, case, arm)

if __name__ == "__main__":
    plan = schedule()
    if "--plan" in sys.argv:
        print(json.dumps(plan, indent=1)); sys.exit()
    threads = [threading.Thread(target=worker, args=(plan,)) for _ in range(POLICY["workers"])]
    [t.start() for t in threads]; [t.join() for t in threads]
    print("DONE spent", round(spent[0], 2))
