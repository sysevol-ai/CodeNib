"""Mechanical case selection for the issue-localization cost A/B (v6).

For each candidate repository, in list order, take the most recently merged
pull request that satisfies every rule below. No model is involved.
"""
import json, re, subprocess, sys
from pathlib import PurePosixPath

CANDIDATES = [
    "PrefectHQ/prefect", "dagster-io/dagster", "mlflow/mlflow", "ibis-project/ibis",
    "pydata/xarray", "conda/conda", "zulip/zulip", "saleor/saleor",
    "Textualize/textual", "kedro-org/kedro", "spack/spack", "python-poetry/poetry",
    "pypa/pip", "mitmproxy/mitmproxy", "streamlit/streamlit", "wagtail/wagtail",
    "celery/celery", "nautobot/nautobot", "apache/superset", "pantsbuild/pants",
]
MERGED_SINCE = "2026-09-01"
ISSUE_SINCE = "2026-08-01"
QUERY = """
query($q: String!, $after: String) {
  search(query: $q, type: ISSUE, first: 25, after: $after) {
    pageInfo { hasNextPage endCursor }
    nodes { ... on PullRequest {
      number title mergedAt url changedFiles
      mergeCommit { oid parents(first: 2) { nodes { oid } } }
      closingIssuesReferences(first: 5) { nodes {
        number title body createdAt url author { __typename login } } }
      files(first: 60) { nodes { path additions deletions changeType } }
    } }
  }
}"""

def gql(variables):
    args = ["gh", "api", "graphql", "-f", "query=" + QUERY]
    for k, v in variables.items():
        if v is not None:
            args += ["-f", f"{k}={v}"]
    return json.loads(subprocess.check_output(args))["data"]["search"]

def is_test(path):
    p = PurePosixPath(path)
    parts = [x.lower() for x in p.parts]
    return (any(x in ("test", "tests", "testing", "conftest.py", "test_utils", "e2e",
                      "e2e_playwright", "__tests__", "spec", "cypress", "playwright")
                for x in parts)
            or ".test." in p.name or ".spec." in p.name
            or p.name.startswith("test_") or p.name.endswith("_test.py"))

def is_source(path):
    parts = [x.lower() for x in PurePosixPath(path).parts]
    return (path.endswith(".py") and not is_test(path)
            and not any(x in ("docs", "doc", "examples", "example", "benchmarks", "scripts", "migrations") for x in parts))

def reject(pr):
    issues = pr["closingIssuesReferences"]["nodes"]
    if len(issues) != 1:
        return "closes %d issues" % len(issues)
    issue = issues[0]
    if issue["createdAt"][:10] < ISSUE_SINCE:
        return "issue older than cutoff"
    author = issue.get("author") or {}
    if author.get("__typename") != "User":
        return "issue not opened by a user"
    text = issue["title"] + "\n" + (issue["body"] or "")
    if len(issue["body"] or "") < 300:
        return "issue body under 300 characters"
    if pr["changedFiles"] > 60:
        return "more than 60 files"
    files = pr["files"]["nodes"]
    # The fix must be Python only: another language's source on the fix path
    # would make the Python files an incomplete answer.
    other = (".ts", ".tsx", ".js", ".jsx", ".mjs", ".vue", ".rs", ".go", ".c", ".cc",
             ".cpp", ".h", ".hpp", ".java", ".kt", ".rb", ".pyx", ".pxd", ".sql", ".html")
    if any(f["path"].endswith(other) and not is_test(f["path"]) for f in files):
        return "changes source in another language"
    source = [f for f in files if is_source(f["path"])]
    gold = [f for f in source if f["changeType"] == "MODIFIED"]
    if not gold or len(source) != len(gold):
        return "source files added, removed or renamed, or none modified"
    if len(gold) > 3:
        return "more than 3 source files"
    if sum(f["additions"] + f["deletions"] for f in gold) > 100:
        return "more than 100 changed source lines"
    for f in gold:
        if PurePosixPath(f["path"]).name in text or f["path"] in text:
            return "issue text names a gold file"
    parents = (pr["mergeCommit"] or {}).get("parents", {}).get("nodes", [])
    if not parents:
        return "no merge commit"
    return None

def select(repo):
    after, seen, log = None, 0, []
    q = f"repo:{repo} is:pr is:merged merged:>={MERGED_SINCE} linked:issue sort:updated-desc"
    prs = []
    while seen < 200:
        page = gql({"q": q, "after": after})
        prs += [n for n in page["nodes"] if n]
        seen = len(prs)
        if not page["pageInfo"]["hasNextPage"]:
            break
        after = page["pageInfo"]["endCursor"]
    prs.sort(key=lambda p: p["mergedAt"], reverse=True)
    for pr in prs:
        why = reject(pr)
        log.append({"pr": pr["number"], "merged": pr["mergedAt"], "rejected": why})
        if why is None:
            issue = pr["closingIssuesReferences"]["nodes"][0]
            return {
                "repo": repo, "pr": pr["number"], "pr_url": pr["url"], "merged_at": pr["mergedAt"],
                "base_commit": pr["mergeCommit"]["parents"]["nodes"][0]["oid"],
                "merge_commit": pr["mergeCommit"]["oid"],
                "issue": {"number": issue["number"], "url": issue["url"], "created_at": issue["createdAt"],
                          "title": issue["title"], "body": issue["body"]},
                "gold_files": sorted(f["path"] for f in pr["files"]["nodes"]
                                     if is_source(f["path"])),
            }, log
    return None, log

if __name__ == "__main__":
    out, logs = [], {}
    for repo in CANDIDATES:
        try:
            case, log = select(repo)
        except subprocess.CalledProcessError as exc:
            case, log = None, [{"error": str(exc)}]
        logs[repo] = log
        print(repo, "->", (case or {}).get("pr"), f"({len(log)} PRs examined)", flush=True)
        if case:
            out.append(case)
    json.dump(out, open("candidates.json", "w"), indent=1)
    json.dump(logs, open("selection-log.json", "w"), indent=1)
