The bug is an off-by-one comparison in `chop_cells`, at `rich/cells.py:344`. It is only reached for unbroken words that contain characters outside the single-cell fast-path set.

**Code path**

1. `Console.print` (`rich/console.py:1670`) passes each renderable to `render(renderable, render_options)` at `rich/console.py:1731`.
2. `Console.render` (`rich/console.py:1294`) calls `renderable.__rich_console__(self, _options)` at `rich/console.py:1319`.
3. `Text.__rich_console__` (`rich/text.py:689`) calls `self.wrap(...)` at `rich/text.py:696`.
4. `Text.wrap` (`rich/text.py:1201`) calls `divide_line(str(line), width, fold=wrap_overflow == "fold")` at `rich/text.py:1239`. Overflow defaults to `"fold"`.
5. `divide_line` (`rich/_wrap.py:26`) handles a word wider than the whole line (`word_length > width`, `rich/_wrap.py:54`). With `fold` set, it calls `chop_cells(word, width=width)` at `rich/_wrap.py:59` and turns each returned piece into a break position.
6. `chop_cells` (`rich/cells.py:326`):
   - If every character is in `_SINGLE_CELLS` (`_is_single_cell_widths`, `rich/cells.py:35`), it takes the fast path and slices every `width` characters (`rich/cells.py:337-338`). That path is correct.
   - Otherwise it walks the grapheme spans:
     ```python
     if line_size + cell_size >= width:   # rich/cells.py:344
         lines.append(text[line_offset:start])
     ```
     This starts a new line when the next grapheme would make the line **exactly** `width` cells, not only when it would go past `width`. So a line can never be completely full.

**Why the reported cases fail**

- **"€" at width 40:** "€" is one cell wide but isn't in `_SINGLE_CELLS`, so it takes the slow path. At `line_size == 39`, `39 + 1 >= 40` triggers a break, giving 39-cell lines.
- **Japanese (2 cells each) at width 80:** at 78 cells, `78 + 2 >= 80` triggers a break, giving 78 cells (39 characters). At width 40 the same happens at 38.
- **Mixed string at width 21:** `Textual`(7) + `は`(2) + `Python`(6) + `の`(2) + `高`(2) = 19 cells. For `速`, `19 + 2 >= 21` is true, so it breaks after "高" when "速" would have filled the line exactly.

**Why the other cases work**

- **Width 79 with wide characters:** an even running total can never equal 79. At 78 the line really is full (`78 + 2 = 80 > 79`), so `>=` and `>` give the same result.
- **ASCII run:** handled entirely by the fast path at `rich/cells.py:338`, so it never reaches line 344.
- **Japanese words separated by spaces:** each word fits within `width`, so `divide_line` never calls `chop_cells` (`rich/_wrap.py:47-54`, `72-76`).
- **`overflow="ellipsis"`:** `fold` is false, so `divide_line` crops the word instead (`rich/_wrap.py:67-71`). `Text.truncate` then fills the full 80 cells (`rich/text.py:1248`).

**Correct behavior**

As the docstring says (`rich/cells.py:334-335`), each piece should be as wide as possible while staying at most `width` cells. It should break only when adding the next grapheme would go past the width: `if line_size + cell_size > width:`.

With that change:
- 95 Japanese characters at width 80 fold as 80 + 80 + 30 cells.
- At width 40, lines are 40 cells.
- 100 "€" at width 40 fold as 40/40/20.
- The width-21 example breaks after "速" (21 cells).
- Width 79 and all the fast-path cases stay the same.

I didn't edit the code, as you asked.