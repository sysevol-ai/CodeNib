The cause is a case-sensitive prefix check in `Session._compute_new_headers()`. I traced this by reading the code only; I didn't edit or run anything.

## Code path

1. `main()` in `httpie/__main__.py:9` calls `httpie.core.main()` (`httpie/core.py:146`), which calls `program()` at `httpie/core.py:164`.
2. `program()` calls `collect_messages(env, args=args, …)` at `httpie/core.py:207`.
3. `collect_messages()` (`httpie/client.py:43`) works in four steps:
   - It loads the session with `get_httpie_session()` (`httpie/client.py:51`, defined at `httpie/sessions.py:92`).
   - It builds the request headers with `make_request_kwargs()` (`httpie/client.py:60`). That function starts from `make_default_headers()` (`httpie/client.py:343`), adds the session headers and then `args.headers` (`:345–346`), and passes the result through `finalize_headers()` (`:351`, defined at `:192`).
   - It calls `httpie_session.update_headers(request_kwargs['headers'])` at `httpie/client.py:75`.
   - Later it calls `httpie_session.save()` (`httpie/client.py:140`).
4. `Session.update_headers()` (`httpie/sessions.py:230`) calls `self._compute_new_headers(request_headers)` at `httpie/sessions.py:237`.
5. The filter in `Session._compute_new_headers()` (`httpie/sessions.py:200`) is the faulty code:

```python
for prefix in SESSION_IGNORED_HEADER_PREFIXES:   # ['Content-', 'If-']  (sessions.py:35)
    if name.startswith(prefix):                    # sessions.py:223
        break
else:
    new_headers.add(name, value)
```

## Why only some cases fail

`HTTPHeadersDict` ignores case when looking up a header, but it keeps the spelling it was given. `finalize_headers()` copies the names unchanged, so `name` at line 223 is exactly what you typed.

`str.startswith` is case-sensitive. `'content-type'.startswith('Content-')`, `'if-none-match'.startswith('If-')` and `'CONTENT-LANGUAGE'.startswith('Content-')` are all `False`. So the `for … else` branch runs and these headers go into the session. They are saved, then on every later request they come back in through `base_headers` (`httpie/client.py:345`), which is why a plain `GET` still sends them.

The cases that work:
- **Headers typed in canonical case** (`Content-Type`, `If-None-Match`, `Content-Language`) happen to match the mixed-case prefix strings, so they're skipped.
- **HTTPie's own `Content-Type`** for JSON or `--form` data is set with the literal key `'Content-Type'` (`httpie/client.py:272`, `:277`), so it always matches.
- **Headers like `X-Api-Key`** match no prefix, so storing them is correct.
- **`--offline` versus a real server** makes no difference, because the filtering happens before the request is sent.

The same function already compares case-insensitively for `user-agent` and `cookie` (`name.lower()` at `httpie/sessions.py:210` and `:213`). The prefix check is the one place that doesn't.

## Correct behavior

HTTP header names are case-insensitive, so the prefix test should be too. For example: `name.lower().startswith(prefix.lower())`, or store the prefixes in lowercase and compare against `name.lower()`. Then any spelling of a `Content-*` or `If-*` header would be left out of the session file and not replayed, while ordinary headers like `X-Api-Key` would still be stored and replayed as they are now.