## Diagnosis: `TomlPyProject` claims a pyproject.toml that holds only `legacy_tox_ini`

### Code path from `tox list` to the bug

1. `run()` (`src/tox/run.py:20`) calls `main()`. `main()` calls `setup_state(args)` at `src/tox/run.py:42`, and `setup_state` calls `get_options(*args)` at `src/tox/run.py:56`.
2. `get_options()` (`src/tox/config/cli/parse.py:30`) calls `_get_base(...)` at `src/tox/config/cli/parse.py:43`. `_get_base()` then calls `discover_source(selected.config_file, selected.root_dir)` at `src/tox/config/cli/parse.py:125`. `src/tox/session/env_select.py:187` also calls `discover_source`.
3. `discover_source()` (`src/tox/config/source/discover.py:29`) picks one of three branches:
   - No `-c`: `_locate_source()` (`discover.py:63`). It walks up from the current directory through its parents.
   - `-c .`: the directory loop (`discover.py:43-59`).
   - `-c pyproject.toml`: `_load_exact_source()` (`discover.py:80`). Its exact-name filter keeps both pyproject classes.

   All three try the classes in `SOURCE_TYPES` order (`discover.py:20-26`): `ToxIni`, `SetupCfg`, **`TomlPyProject`**, `LegacyToml`, `TomlTox`. The first constructor that doesn't raise `MissingRequiredConfigKeyError` wins.
4. `TomlPyProject.__init__()` (`src/tox/config/source/toml_pyproject.py:87`) finds the `[tool.tox]` table with `_table_at` (line 92). It then decides whether the table holds no native config:

   ```python
   if set(self._our_content.keys()) < {"legacy_tox_ini"}:   # line 95
       raise MissingRequiredConfigKeyError(path)
   ```

### Why exactly this case fails

`<` on sets tests for a **proper** subset.

- **Empty `[tool.tox]`:** `set() < {"legacy_tox_ini"}` is `True`. `TomlPyProject` raises, discovery moves on, and `tox.toml` is used. That's why the empty-stub case works.
- **Only `legacy_tox_ini`:** `{"legacy_tox_ini"} < {"legacy_tox_ini"}` is `False`. Nothing is raised, so `TomlPyProject` is accepted as the source.

`LegacyToml` (`src/tox/config/source/legacy_toml.py:17-25`) comes later in the list. It would read the embedded string and build an `IniSource` from it, but it's never tried.

As a native TOML source, `TomlPyProject` reads `env_list` and `env.<name>` tables out of `[tool.tox]`. None of those exist; the only key is a string. `get_loader` (lines 125-134) finds no `env` table and returns `None`. So:

- `env_list` is empty and tox falls back to the default `py`, printed as `py -> [no description]`.
- `lint` isn't defined anywhere, so `-e lint` gives "provided environments not found".

`-c pyproject.toml`, `-c .` and running from a subdirectory all go through the same ordered loop and stop at the same constructor, so they make no difference.

### Why the other setups work

- **`tox.ini`** and **`setup.cfg` with `[tox:tox]`:** `ToxIni` and `SetupCfg` come before `TomlPyProject` in the list and load the INI text directly.
- **Native `[tool.tox]` tables:** they have keys other than `legacy_tox_ini` (`env_list`, `env`, …), so `TomlPyProject` is the right source.
- **`tox.toml`:** loaded by `TomlTox`. Next to an empty `[tool.tox]` it's reached because the empty table hits the `set()` case above.

### Correct behavior

The comment on line 95 says what was intended: "an empty stub or a legacy pointer holds no config". `TomlPyProject` should step aside when `[tool.tox]` has no keys or only `legacy_tox_ini`. That needs a subset-or-equal test, `<=` (`issubset`), instead of a proper-subset test. Then `MissingRequiredConfigKeyError` is raised, discovery falls through to `LegacyToml`, and the INI string is parsed. `tox list` should show `lint` and `unit` with their descriptions, and `tox run -e lint` / `tox config -e lint` should resolve the environment. Native tables, an empty stub next to `tox.toml`, and the INI files would behave as they do now.

I haven't changed or run anything; this comes from reading the source.