The bug is in `merge_configs`, at `cookiecutter/config.py:54`. When it merges a nested dict, it passes its arguments in the wrong order, so the built-in values overwrite the user's values instead of the other way round.

**Code path**

1. `main()` (`cookiecutter/cli.py:87`) calls `cookiecutter(..., config_file=config_file, ...)` at `cookiecutter/cli.py:219` (the keyword is at `:227`).
2. `cookiecutter()` (`cookiecutter/main.py:29`) calls `get_user_config(...)` at `cookiecutter/main.py:79`.
3. `get_user_config()` (`cookiecutter/config.py:89`) picks the file to load:
   - `--config-file` goes to `get_config(config_file)` at `:123`.
   - `COOKIECUTTER_CONFIG` goes to `get_config(...)` at `:140`.
   - `~/.cookiecutterrc` goes to `get_config(...)` at `:133`.
   
   All three sources end up in the same function, which is why they all fail the same way.
4. `get_config()` (`cookiecutter/config.py:61`) parses the YAML and calls `merge_configs(DEFAULT_CONFIG, yaml_dict)` at `:78`.
5. `merge_configs()` (`cookiecutter/config.py:42`) copies `default` and loops over the user's keys. For any value that is a dict, line 54 does:
   ```python
   new_config[k] = merge_configs(v, default.get(k, {}))
   ```
   Here the user's dict `v` is passed as the base and the built-in dict as the overwrite, which is backwards.
6. Back in `cookiecutter()`, `determine_repo_dir(..., abbreviations=config_dict['abbreviations'])` is called at `cookiecutter/main.py:83-85`.
7. `determine_repo_dir()` (`cookiecutter/repository.py:70`) calls `expand_abbreviations()` at `:101`. That function (`cookiecutter/repository.py:38-53`) faithfully uses `abbreviations['gh']`, which by now holds the built-in GitHub URL again. `is_repo_url` is then true, so `clone()` runs at `:113-119` and the `git clone` from GitHub fails.

**Why only the reported cases fail**

Because of the swap, for a nested dict like `abbreviations`, the result is the user's dict with the built-in `BUILTIN_ABBREVIATIONS` (`cookiecutter/config.py:22-26`) laid on top. So:

- **Redefined `gh`/`gl`/`bb`:** the key exists on both sides, and the built-in value wins. That is the reported failure.
- **New `corp`:** only the user has that key, so nothing overwrites it and it expands correctly.
- **`default_context`:** the built-in default is an empty `OrderedDict` (`:31`), so it has nothing to overwrite with and the user's values survive. The bug only shows up when a key exists on both sides with different values.
- **Top-level plain values** (e.g. `replay_dir`): these go through the `else` branch at `:55-56` and are handled correctly.
- **Plain local path or full URL:** `expand_abbreviations` finds no matching prefix and returns the template unchanged, so the abbreviation table doesn't matter.
- **`--default-config` or no user config:** `copy.copy(DEFAULT_CONFIG)` is returned at `:118`/`:135` without going through `merge_configs`, so `gh:` expands to GitHub as documented.

The same swap also affects the API path where `default_config` is a dict (`:113`).

The existing test `tests/test_get_config.py:12-51` expects a user-defined `gl` to win. It would fail against this code, so it is evidence of what the intended behavior is.

**Correct behavior**

User values should take precedence at every nesting level, while built-in keys the user didn't mention are kept:
```python
new_config[k] = merge_configs(default.get(k, {}), v)
```
With that change, `gh:acme/widget` expands to `/srv/template-mirror/acme/widget`, `gl` and `bb` can be overridden the same way, and `corp:` and `default_context` keep working. I did not edit any code.