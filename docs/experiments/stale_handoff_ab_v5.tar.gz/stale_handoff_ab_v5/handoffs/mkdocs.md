The bug is in `find_or_create_node`, in `mkdocs/utils/__init__.py:325-327`. When it scans the existing nodes for a section it stops at the first item that is a page path rather than a section, so it never finds a section that comes after a page.

**Code path**

1. `mkdocs build` runs `build_command` (`mkdocs/__main__.py:280`), which calls `build.build(cfg, …)` at `mkdocs/__main__.py:288`.
2. `build()` (`mkdocs/commands/build.py:249`) collects the files and then calls `get_navigation(files, config)` at `mkdocs/commands/build.py:296`.
3. `get_navigation()` (`mkdocs/structure/nav.py:130`): when `config['nav']` is `None`, it sorts the pages with `file_sort_key` (line 135) and builds a nav config with `nest_paths(...)` (line 136). That config goes to `_data_to_navigation()` (line 137), which turns each `{title: [...]}` dict into a `Section` (line 193).
4. `nest_paths()` (`mkdocs/utils/__init__.py:338`): for each path it walks the parent folder names and calls `find_or_create_node(branch, part)` (line 351), then appends the path to the branch it gets back (line 353).
5. `find_or_create_node()` (`mkdocs/utils/__init__.py:319`):
   ```python
   for node in branch:
       if not isinstance(node, dict):
           break          # line 327
       if key in node:
           return node[key]
   new_branch = []; branch.append({key: new_branch}) ...
   ```
   The `break` ends the search at the first entry that is a page path (a plain string). The function then appends a new `{key: []}` section, even if a matching section already exists further along the list.

**Why only some cases fail**

`file_sort_key` puts `index.md` first, so the top-level list starts with the string `'index.md'`. Every later lookup stops on that string at once, and every page in a folder gets its own new section. Running the code directly confirms it:

```
nest_paths(['index.md','api/reference.md','guide/install.md','guide/usage.md'])
→ ['index.md', {'Api': [...reference.md]}, {'Guide': ['guide/install.md']}, {'Guide': ['guide/usage.md']}]

nest_paths(['api/reference.md','guide/install.md','guide/usage.md'])
→ [{'Api': [...]}, {'Guide': ['guide/install.md', 'guide/usage.md']}]
```

- **"Api" looks correct** because its folder has only one page. One new section per page gives the right result when there is only one page.
- **A docs root with no top-level page works** because the root list then holds only dicts. The loop never reaches a string, so it finds the existing `Guide` section and reuses it.
- **An explicit `nav:` works** because that config is passed straight to `_data_to_navigation` and never goes through `nest_paths` or `find_or_create_node`.
- **URLs and page content are unaffected** because they come from `File`/`Page` objects, not from how the nav is grouped. Each file is still placed in the nav exactly once and turned into a `Page` once.

The same split happens at any depth: any folder level that has a page listed before a subfolder (for example `guide/index.md` plus `guide/sub/a.md` and `guide/sub/b.md`) splits that subfolder's section.

**Correct behavior**

`find_or_create_node` should check every entry in the branch, skipping strings rather than stopping at them (`continue` instead of `break`, or only testing `isinstance(node, dict) and key in node`). It should only create a new section when no matching dict exists. Then the first example would give `['index.md', {'Api': [...]}, {'Guide': ['guide/install.md', 'guide/usage.md']}]`, the same as the explicit-nav result: one "Guide" section with "Install" and "Usage".

I didn't edit any code; I only ran `nest_paths` directly to confirm the output above.