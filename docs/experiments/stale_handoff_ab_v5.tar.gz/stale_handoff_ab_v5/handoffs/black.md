## The bug: `_maybe_empty_lines_for_class_or_def` gets an adjusted blank-line count, not the user's

### How `black FILE` reaches it
1. `main` (`src/black/__init__.py:562`) calls `reformat_one` for a single file (`:792`). `-c` goes through `reformat_code` (`:757`) instead.
2. `reformat_one` (`:971`) calls `format_file_in_place` (`:1022`). `reformat_code` calls `format_stdin_to_stdout` (`:957`). Both call `format_file_contents` (`:1071`, `:1139`), so `--check` and `--diff` take the same route.
3. `format_file_contents` (`:1217`) calls `format_str` (`:1233`), which calls `_format_str_once` (`:1362`).
4. `_format_str_once` (`:1428`) creates an `EmptyLineTracker` (`:1463`) and calls `elt.maybe_empty_lines(line)` for each line (`:1474`).
5. `EmptyLineTracker.maybe_empty_lines` (`src/black/lines.py:911`) calls `_maybe_empty_lines` (`lines.py:922`).
6. `_maybe_empty_lines` (`lines.py:1016`) passes decorator, def and class lines to `_maybe_empty_lines_for_class_or_def` (`lines.py:1162-1165`).

### The faulty code
In `_maybe_empty_lines`, `before` starts as the user's blank-line count, read from the first leaf's prefix (`lines.py:1027`), and that original value is saved in `user_had_newline` (`lines.py:1042`). After that, whenever a previous def at the same or deeper depth gets popped (`lines.py:1047-1048`), the non-stub branch replaces `before` with black's preferred spacing: `1` inside a class (`lines.py:1140-1141`) and `2` at module level (`lines.py:1159-1160`).

That modified `before` is what `_maybe_empty_lines_for_class_or_def` receives. Its rule for "the user wrote nothing after a dummy implementation" (`lines.py:1310-1321`) then tests:

```python
self.previous_line.is_stub_def and not before and (...)
```

`before` is already 1 or 2 here, never 0, so `newlines` stays at `1 if depth else 2` and the blank lines get inserted. The rule is meant to read the user's input, but it gets black's own adjustment.

### Why only these cases fail
- **`.py` overloads and Protocol methods:** the line before is a stub def, which is popped as `previous_def`. That forces `before` to 2 (module level) or 1 (class body), so the "no blank line" exception can never fire. I reproduced the module-level `@overload` case with `black --diff`: it adds two blank lines before the second `@overload` and before the implementation.
- **`.pyi` files:** the `is_pyi` branches (`lines.py:1068-1138` and `lines.py:1236-1308`) work out spacing on their own and never reach the `else` at `lines.py:1309`, so they behave as before.
- **Functions with real bodies:** `previous_line` is a body line, not a stub def, so getting 2 or 1 blank lines is correct.
- **Dummy implementations the user had already separated:** the user's `before` was non-zero, so the exception wouldn't apply either way, and the result is the same as before.
- **`--preview`:** `Preview.blank_line_after_stub_method` only adds a depth condition joined by `and`, so `not before` still fails.

`is_stub_def` (`lines.py:185`) and the stub-suite joining in `linegen.py:311-338` both work as intended. I checked that the stub lines come out as `def parse(value: int) -> int: ...` with `is_stub_def == True`.

### What it should do
The check at `lines.py:1315` should test the user's original spacing, `not user_had_newline`, instead of the overwritten `before`. Then a dummy implementation followed directly by another def or decorator at the same depth gets 0 blank lines, and the overload groups and Protocol bodies come out unchanged. All other spacing stays as it is now. I haven't edited any code.