## Diagnosis

The fault is a missing separator in `_parse_cmdline_options` (`alembic/script/write_hooks.py:100-101`). When the token is absent, it gets glued onto the front of the user's options with no space between them.

### How `alembic revision` gets there

1. `CommandLine.main` (`alembic/config.py:1014`) calls `run_cmd`, which calls the command function at `alembic/config.py:963`.
2. `command.revision` (`alembic/command.py:191`) builds the scripts at `alembic/command.py:313`: `revision_context.generate_scripts()`.
3. `RevisionContext.generate_scripts` (`alembic/autogenerate/api.py:658`) yields `self._to_script(...)` (line 660).
4. `_to_script` (`alembic/autogenerate/api.py:549`) calls `self.script_directory.generate_revision(...)` at line 565.
5. `ScriptDirectory.generate_revision` (`alembic/script/base.py:616`) writes the file with `_generate_template` (line 732). Then it calls `write_hooks._run_hooks(path, post_write_hooks)` at line 749.
6. `_run_hooks` (`alembic/script/write_hooks.py:70`) wraps each hook in `util.status("Running post write hook ...")` and calls `_invoke` at line 88.
7. `_invoke` (`write_hooks.py:46`) looks up the hook type in the registry and calls `hook(revision_path, options)` at line 67:
   - `console_scripts` (line 137) builds `[sys.executable, "-c", pyscript]` and calls `_run_hook` at line 164.
   - `module` (line 174) builds `[sys.executable, "-m", module_name]` and calls `_run_hook` at line 181.
8. `_run_hook` (line 122) reads `options.get("options", "")` and calls `_parse_cmdline_options` at line 127. It then runs `subprocess.run([*command, *cmdline_options_list])` at line 133.
9. `_parse_cmdline_options` (line 91) is where it goes wrong:
   ```python
   if REVISION_SCRIPT_TOKEN not in cmdline_options_str:
       cmdline_options_str = REVISION_SCRIPT_TOKEN + cmdline_options_str
   ```

### Why the affected cases fail

- **`options = -l 79`** becomes `"REVISION_SCRIPT_FILENAME-l 79"`. `shlex.split` turns that into `["REVISION_SCRIPT_FILENAME-l", "79"]`, and replacing the token gives `["/…/abc_msg.py-l", "79"]`. Black receives two paths, neither of which exists, so it reports that the path does not exist and the real file is never formatted.
- **`options = --quiet`** becomes `["/…/abc_msg.py--quiet"]`: again a single path that doesn't exist.
- **Why it still prints "done" and exits 0:** `subprocess.run` at line 133 is called without `check=True` and its return code is never looked at. Black's non-zero exit is ignored, so `util.status` finishes normally.

### Why the other cases work

- **Token written explicitly** (`-l 79 REVISION_SCRIPT_FILENAME`): the `if` at line 100 is false, so nothing is prepended. `shlex.split` gives a standalone `REVISION_SCRIPT_FILENAME` token, and the replacement at lines 105-108 turns it into exactly the file path.
- **No `options` line:** `_run_hook` passes `""` (line 126). Prepending onto an empty string gives just `"REVISION_SCRIPT_FILENAME"`, which splits to one token and becomes the correct path. There is nothing after it to join with.

### Correct behavior

As the docstring (lines 97-98) and the documentation say, when the token is missing the revision path should be passed as its own first argument. `-l 79` should give `[path, "-l", "79"]`, and `--quiet` should give `[path, "--quiet"]`. The fix is to insert a separator: `REVISION_SCRIPT_TOKEN + " " + cmdline_options_str`.

A secondary issue worth noting: `_run_hook` ignores the subprocess's return code. That is why this failure showed up as a silent "done" instead of an error.

I haven't edited any code.