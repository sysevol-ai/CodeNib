The cause is in `_unpack_args` (`typer/_click/parser.py:46-98`): after it reaches a list argument, it collects the arguments that follow it in reverse order and never flips them back.

## Call path

1. `Typer.__call__` (`typer/main.py:1133`) calls `get_command(self)(*args, **kwargs)` at `typer/main.py:1137`.
2. `get_command` (`typer/main.py:1173`) has exactly one registered command, so it builds a single `TyperCommand` (`typer/core.py:903`) through `get_command_from_info`.
3. Calling that command runs `Command.__call__` (`typer/_click/core.py:800`), which calls `self.main(...)` at line 802.
4. `TyperCommand.main` (`typer/core.py:955`) calls `_main(...)` at line 964.
5. `_main` (`typer/core.py:158`) calls `self.make_context(...)` at line 186. Line 187 later runs `self.invoke(ctx)`, which passes `ctx.params` to `main` (`typer/_click/core.py:741`).
6. `Command.make_context` (`typer/_click/core.py:687`) calls `self.parse_args(ctx, args)` at line 708.
7. `Command.parse_args` (`typer/_click/core.py:711`) builds the parser and calls `parser.parse_args(args=args)` at line 716.
8. `_OptionParser.parse_args` (`typer/_click/parser.py:274`) handles options first (line 285), then calls `_process_args_for_args` at line 286.
9. `_process_args_for_args` (`typer/_click/parser.py:292`) calls `_unpack_args(state.largs + state.rargs, [x.nargs for x in self._args])` at line 293. It then hands `pargs[idx]` to each argument in declaration order (lines 297-298).

## Why it fails

For `sources: list[str], dest, mode`, the arity list (`nargs_spec`) is `[-1, 1, 1]`. Here is what `_unpack_args` does with it:

- **The `-1`:** it is taken from the left and sets `spos = 0`. `rv` becomes `[None]` (lines 85-90).
- **Direction switch:** from then on `_fetch` pops from the **right** of both the remaining arities and the remaining values (lines 63-66). This is deliberate, so the trailing fixed arguments get the trailing values.
- **Reversed collection:** the first pop takes `mode`'s arity and the value `'fast'`. The next takes `dest`'s arity and `'out'`. Both are appended in that order, so `rv = [None, 'fast', 'out']`.
- **Final fill:** line 95 puts the leftover values into the list slot, giving `(('a.txt','b.txt','c.txt'), 'fast', 'out')`.

The function corrects the reversal inside a multi-value tuple (`x.reverse()`, lines 81-82). It never reverses the order of the separate entries collected after `spos`. Upstream Click does this with `rv[spos + 1:] = reversed(rv[spos + 1:])`, and that step is missing here. So `pargs[1]` (`'fast'`) goes to `dest` and `pargs[2]` (`'out'`) goes to `mode`. In the `retries: int` case, `'out'` lands on `retries` and fails int conversion.

I ran `_unpack_args` directly to confirm:
- `(list('abcXY'), [-1,1,1])` returns `(('a','b','c'), 'Y', 'X')`.
- `(list('abX'), [-1,1])` returns `(('a','b'), 'X')`.
- `(list('TMab'), [1,1,-1])` returns `('T','M',('a','b'))`.

## Why the other cases work

- **Exactly one argument after the list:** reversing a single entry changes nothing.
- **List in the last position:** the values before it are popped from the left in order. When the `-1` is reached, no arities are left to pop from the right.
- **No list argument:** `spos` stays `None`, so everything is taken left to right.
- **`--mode fast` as an option:** options are removed earlier, at line 285. Only one fixed argument follows the list, so it's the single-entry case again.

## Correct behavior

The values after the list should be assigned to the trailing arguments in declaration order: `main(['a.txt','b.txt','c.txt'], dest='out', mode='fast')` and `main(['a.txt','b.txt'], dest='out', retries=3)`. To get that, `_unpack_args` should reverse `rv[spos + 1:]` once the loop ends. I haven't edited anything.