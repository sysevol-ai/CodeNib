## Diagnosis

The bug is in `Bucket.load_bytecode` in `src/jinja2/bccache.py:65-81`. When the checksum doesn't match, it resets the bucket but does not return, so it goes on to load the stale bytecode anyway.

### Code path

1. **`Environment.get_template()`** (`src/jinja2/environment.py:982`) resolves `parent` and calls `self._load_template(name, globals)` at `environment.py:1016`.
2. **`Environment._load_template()`** (`environment.py:957`) checks the in-memory `self.cache`. With `auto_reload=True`, an edited file makes `template.is_up_to_date` False (`environment.py:965-967`), so it falls through to `self.loader.load(...)` at `environment.py:975`.
3. **`BaseLoader.load()`** (`src/jinja2/loaders.py:108`) reads the current source with `get_source()` (`loaders.py:126`). It then calls `bcc.get_bucket(environment, name, filename, source)` (`loaders.py:132`) and uses `bucket.code` if it isn't `None` (`loaders.py:133-138`).
4. **`BytecodeCache.get_bucket()`** (`bccache.py:166`) builds the key from the name and filename, and the checksum from the **new** source (`bccache.py:176-178`). It then calls `self.load_bytecode(bucket)` (`bccache.py:179`).
5. **`FileSystemBytecodeCache.load_bytecode()`** (`bccache.py:263`) opens the cache file and calls `bucket.load_bytecode(f)` (`bccache.py:276`).
6. **`Bucket.load_bytecode()`** (`bccache.py:65`) is where it goes wrong:

```python
checksum = pickle.load(f)
if self.checksum != checksum:
    self.reset()          # code = None …
# no return here
try:
    self.code = marshal.load(f)   # … then the stale code is loaded anyway
```

The bad-magic branch above it (`bccache.py:69-71`) does return after `reset()`, but the checksum branch at `bccache.py:74-75` doesn't. So the old compiled code goes into `bucket.code`.

### Why exactly these cases fail

- **Edited template:** the cache key (name + filename) is unchanged, so the old cache file is found. The checksum differs, but `marshal.load` still fills `bucket.code` with the old code. Because `bucket.code` isn't `None`, `loaders.py:137` skips compiling and `loaders.py:143` skips writing a new cache entry. The stale file is never replaced, so the problem persists for every later load and every new `Environment` using that directory.
- **Long-running env with `auto_reload=True`:** the in-memory cache correctly notices the change (step 2) and reloads, but the reload goes through the same bucket path and gets the stale code again. Nothing fails, so nothing is logged.
- **Unedited templates:** the checksums match, so loading the cached code is correct.
- **First load of a new template:** there's no cache file, so `load_bytecode` returns before reading anything (`bccache.py:263-276`). `bucket.code` stays `None`, the template is compiled, and the result is cached.
- **No `bytecode_cache`:** `bcc is None`, so `loaders.py:137-138` always compiles the current source.
- **`env.from_string()`:** it compiles directly and never goes through `BaseLoader.load` or the bytecode cache.

### Correct behavior

A checksum mismatch should be treated as a cache miss, just like a bad magic header. The method should `reset()` and **return** without unmarshalling. Then `bucket.code` stays `None`, `BaseLoader.load` recompiles from the current source (`loaders.py:137-138`), and `set_bucket` overwrites the stale cache file with fresh bytecode and the new checksum (`loaders.py:143-145`). The fix is to add `return` after `self.reset()` at `bccache.py:75`.

As requested, I didn't edit anything.