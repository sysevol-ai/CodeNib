I've found the faulty line. Here is the diagnosis; I didn't edit anything.

## Call path

1. `main()` (`isort/main.py:1021`) sends each file to `sort_imports` (`isort/main.py:1188`, or `:1174` when running jobs in parallel). `sort_imports` (`isort/main.py:77`) calls `api.check_file` (`:90`) for `--check-only`/`--diff`, otherwise `api.sort_file` (`:96`). Stdin (`-`) goes straight to `api.sort_stream` (`isort/main.py:1113`).
2. `sort_file` calls `sort_stream` (`isort/api.py:453`). `check_file` does the same (`isort/api.py:264`/`:285`).
3. `sort_stream` (`isort/api.py:134`) calls `core.process` (`isort/api.py:208`).
4. `process` calls `output.sorted_imports` (`isort/core.py:530`). That function parses the block with `parse.file_contents` and then calls `_build_import_group` (`isort/output.py:73`).
5. `_build_import_group` calls `_with_from_imports` (`isort/output.py:263`), which calls `_with_from_imports_for_module` once per module (`isort/output.py:520`).

All four entry points meet here, which is why every mode shows the bug.

## What the parser records

In `parse.file_contents`, each from-import name becomes a key in an `OrderedDict` whose value says whether the name was imported plainly (`isort/parse.py:392-399`). An alias-only name is still a key, but its value is `False`, because it was removed from `direct_imports` (`isort/parse.py:279`). The alias itself goes into `as_map["from"]["os.path"]` (`isort/parse.py:285`). So `from os import path as osp` gives `{"path": False}` plus `as_map["from"]["os.path"] == ["osp"]`.

## The faulty code

`isort/output.py:592-598`, which only runs when `config.combine_as_imports` is on:

```python
if from_import in parsed.imports[section][import_key][module]:
    from_imports[(idx + 1) : (idx + 1)] = as_imports.pop(from_import)   # keep "path", insert "path as osp" after it
else:
    from_imports[idx : (idx + 1)] = as_imports.pop(from_import)         # replace "path" with "path as osp"
```

Line 595 checks whether the name is a **key** in the dict, but it should check the key's **value**. Every name in `from_imports` came from that dict (`isort/output.py:558`), so the test is always true. The `else` branch, which swaps the bare name for its aliases, never runs. The bare `path` stays and `path as osp` is added after it, so you get `from os import path, path as osp`. The same happens to `List` in `from typing import Dict, List, List as L`.

## Why the other cases are fine

- **Without `--combine-as`:** lines 587-598 are skipped. The loop at `isort/output.py:687` sends aliased names to `_build_as_imports` with `include_straight_import` set from the stored value, so a `False` name is printed only with its alias. The `force_single_line` path reads the value correctly too (`isort/output.py:653`).
- **Name imported plainly and under an alias** (`OrderedDict, OrderedDict as OD`): the value is `True`. Keeping the bare name and inserting the alias after it is correct, so the buggy test happens to give the right result.
- **Straight imports** (`import numpy as np`): these use `as_map["straight"]` and the straight-import builder, and never reach this function.

## Correct behaviour

Line 595 should test the stored flag, e.g. `if parsed.imports[section][import_key][module][from_import]:`. An alias-only name should then be replaced by its aliases:

- `from os import path as osp` → unchanged
- `from typing import List as L, Dict` → `from typing import Dict, List as L`

Names that were also imported plainly keep the current output, e.g. `from collections import OrderedDict, OrderedDict as OD`.