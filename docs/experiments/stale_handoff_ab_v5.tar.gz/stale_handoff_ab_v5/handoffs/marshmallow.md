The bug is in `marshmallow.utils.get_value`. It splits a dotted path only once, at the first dot, so for three or more segments the rest of the path is looked up as one literal key.

**Call path**

1. `Schema.dump()` (`src/marshmallow/schema.py:548`) calls `self._serialize(processed_obj, many=many)` at `src/marshmallow/schema.py:573`.
2. `Schema._serialize()` (`src/marshmallow/schema.py:530`) handles `many=True` by calling itself once per item (`:537-538`). For each field it calls `field_obj.serialize(attr_name, obj, accessor=self.get_attribute)` (`:541`).
3. `Field.serialize()` (`src/marshmallow/fields.py:314`) calls `self.get_value(obj, attr, accessor=accessor)` (`:332`).
4. `Field.get_value()` (`src/marshmallow/fields.py:258`) uses `self.attribute` (`"owner.address.city"`) as the key and calls the accessor (`:275-276`).
5. `Schema.get_attribute()` (`src/marshmallow/schema.py:500`) calls `utils.get_value(obj, attr, default)` (`:506`).
6. `utils.get_value()` (`src/marshmallow/utils.py:97`) sees a `"."` and calls `_get_value_for_keys(obj, key.split(".", 1), default)` (`:108-109`).
7. `_get_value_for_keys()` (`src/marshmallow/utils.py:113-118`) recurses, and for its last key calls `_get_value_for_key()` (`src/marshmallow/utils.py:119-126`).

**Why only three or more segments fail**

`key.split(".", 1)` splits only at the first dot:

- `"owner.name"` becomes `["owner", "name"]`. Each element is one real key, so `_get_value_for_keys` finds `owner`, then `name`. It works.
- `"owner.address.city"` becomes `["owner", "address.city"]`. After finding `owner`, the recursion is left with the single key `"address.city"`. Line 115 passes that whole string to `_get_value_for_key`, which tries `owner["address.city"]` and then `getattr(owner, "address.city", missing)`. Neither exists, so it returns `missing`. Plain dicts and objects fail the same way, and four segments fail too (the leftover key is `"address.geo.zip"`).
- Fields without `attribute` have no dot, so they go straight to `_get_value_for_key` (`:110`).

**Why it's silent**

The lookup returns `missing`, not an error. In `Field.serialize`, with no `dump_default`, the value stays `missing` and is returned (`src/marshmallow/fields.py:333-337`). `Schema._serialize` then skips that field with `if value is missing: continue` (`src/marshmallow/schema.py:542-543`), so the `owner_city` key is simply left out. With `many=True` the same per-item code runs, so the field is dropped from every item.

**Why `load()` is unaffected**

Loading uses `utils.set_value()` (`src/marshmallow/utils.py:131-151`). It also does `split(".", 1)`, but it then calls itself on `rest` (`:149`), so `"address.city"` gets split again. That recursion is what `get_value` is missing.

**Correct behavior**

A dotted `attribute` should be followed one segment at a time, whatever its length. `"owner.address.city"` should give `obj.owner.address.city` (or `obj["owner"]["address"]["city"]`, or a mix), so `dump()` returns `{"owner_city": "Lyon"}`. That would match `load()` and the two-segment case. A missing segment should still give `missing` (or the field's `dump_default`). Either `split(".")` with no limit, or recursing through `get_value` instead of `_get_value_for_key` on the remainder, would do it. I haven't edited anything, as you asked.