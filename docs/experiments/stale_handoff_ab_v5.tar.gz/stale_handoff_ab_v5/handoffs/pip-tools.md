The bug is in `get_compile_command` at `piptools/utils.py:339`. It takes `option.opts[0]` as the option's "long name", but `opts[0]` is just whichever spelling was declared first, and for these options that's the short one. I didn't edit anything. I read the source and printed each option's `opts` from `cli.params`.

## Code path

1. `pip-compile` runs `cli` (`piptools/scripts/compile.py:149`, decorated with `@click.pass_context` at line 102).
2. `cli` creates `OutputWriter(..., click_ctx=ctx, ...)` at `piptools/scripts/compile.py:544` and calls `writer.write(...)` at line 564.
3. `OutputWriter.write` (`piptools/writer.py:269`) loops over `self._iter_lines(...)` at line 284.
4. `_iter_lines` (`piptools/writer.py:201`) loops over `self.write_header()` at line 220.
5. `write_header` (`piptools/writer.py:129`) uses `os.environ.get("CUSTOM_COMPILE_COMMAND") or get_compile_command(self.click_ctx)` at lines 138–140. Because the environment variable is checked first, overriding still works.
6. `get_compile_command` (`piptools/utils.py:304`) goes through `click_ctx.params` and builds the header line.

## Why the affected options fail

Click keeps `opts` in the order the decorator declares them. Several options in `piptools/scripts/options.py` put the short spelling first:

| option | declaration | `opts` |
|---|---|---|
| verbose | `options.py:71` | `['-v', '--verbose']` |
| pre | `options.py:91` | `['-p', '--pre']` |
| find_links | `options.py:123` | `['-f', '--find-links']` |
| upgrade | `options.py:207` | `['-U', '--upgrade']`, secondary `['--no-upgrade']` |
| output_file | `options.py:228` | `['-o', '--output-file']` |

That one wrong name causes two problems:

- **Wrong spelling.** The value is formatted as `f"{option_long_name}=..."` (`utils.py:401`) for options that take a value, or as `option_long_name` (`utils.py:386/389`) for flags. So you get `-o=pins.txt`, `-f=wheels` and `-p`. The name comes from the option definition, not from what was typed, which is why typing `-o`/`-f` yourself gives the same line.
- **Exclusion check misses.** Line 348 tests `{option_long_name, negative_option} & COMPILE_EXCLUDE_OPTIONS`, and that set (`utils.py:37-47`) contains long names only.
  - `--upgrade`: the test set is `{'-U', '--no-upgrade'}`. Neither is in the exclude set, so the option isn't skipped. Its value `True` isn't the default, so `-U` gets written.
  - `--verbose`: it's a `count=True` option, not a flag, so `negative_option` stays `None`. `'-v'` isn't in the set, the value `1` doesn't equal the default `0`, and it's formatted as a valued option: `-v=1`.

## Why the others work

- **Long-only options** (`--allow-unsafe`, `--no-annotate`, `--strip-extras`, `--annotation-style` at `options.py:200`, …) have a long name as their only primary spelling, so `opts[0]` is correct and the exclusion check would also work.
- **Input files** are variadic (`nargs < 0`). They're handled at `utils.py:328-334` before `option_long_name` is ever used.
- **`CUSTOM_COMPILE_COMMAND`** bypasses `get_compile_command` entirely (`writer.py:138`).

## Correct behavior

The "long name" should be picked by its `--` prefix, not by position. For example, take the longest entry in `option.opts`, or the first one starting with `--`. Then:

- `--output-file=pins.txt`, `--find-links=wheels` and `--pre` would be recorded, however the user typed them.
- `--upgrade` and `--verbose` would match `COMPILE_EXCLUDE_OPTIONS` and be left out.

So the three examples should give:

- `pip-compile --find-links=wheels --output-file=pins.txt requirements.in`
- `pip-compile --pre requirements.in`
- `pip-compile requirements.in`