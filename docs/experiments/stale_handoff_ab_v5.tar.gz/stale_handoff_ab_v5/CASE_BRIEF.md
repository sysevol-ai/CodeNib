# Building stale-handoff cases for a context-management A/B study

You are building private benchmark cases. In each case an earlier agent session diagnosed
a bug and wrote a handoff. After that, "another contributor" merged a change. A later agent
session receives the user's bug report plus the old handoff and must fix the bug in the
CURRENT code. The study compares what that later session is told about which parts of the
handoff are out of date, so the cases must be built by reading code only: do NOT use
CodeNib, any MCP server, or any code-graph, call-graph or LSP tool while choosing or writing
a case. Use git, grep/rg, reading files, docker, and running Python.

Never write into /home/zhongming/CodeNib or into anything under /tmp/codenib-ab-v4, never
push anything anywhere. Everything you produce lives under
/tmp/codenib-ab-v5/cases-staging/<case>/ (case = repository name). These files are
confidential until the study ends.

## Inputs per case (read-only)
- `P` = `/tmp/codenib-ab-v4/sources/<case>/`: the snapshot the handoff was written against.
  It is a real release with an injected 1-3 line regression. Copy it; never edit it.
- `/tmp/codenib-ab-v4/private-grading/<case>/`: `regression.patch` (the injected bug;
  reversing it is the true fix on P), `rubric.json` (the call path and mechanism),
  `repro.py` (shows the symptom; exit 1 on P, 0 on upstream), `NOTES.md`, `case.json`.
- `/tmp/codenib-ab-v4/cases-staging/<case>/prompt.txt`: the original bug report. Its first
  paragraph describes the symptom; ignore the trailing "Diagnose ..." instructions.
- `/tmp/codenib-ab-v5/handoffs/<case>.md`: the handoff, a real agent's diagnosis written
  against P. It cites `file:line` locations in P. Treat it as fixed text; never edit it.
- Your assigned change KIND for the case (local or remote), given in your task.
- Image `codenib/ab-v4-arm64:<case>-v1`; target python `/opt/testbed/bin/python`; the
  workspace install command is in `/tmp/codenib-ab-v4/cases-v4.json` (`install`). Run
  checks with e.g.
  `docker run --rm --network none -v <tree>:/w -w /w codenib/ab-v4-arm64:<case>-v1 bash -lc '<install> && python hidden_test.py'`
  (copy hidden_test.py into a scratch copy of the tree; never leave it in `source/`).

## What you build: the concurrent change C (P -> Q)
C is ordinary work by another contributor that was merged after the handoff was written: a
refactor, a small feature, or a cleanup. It does not mention or fix the bug, and the bug
still reproduces in Q with the same reported symptom. C has exactly two parts:

1. **One consequential change**, placed by KIND:
   - `local`: inside a function or method whose body contains a `file:line` the handoff
     cites (for this, a cited line inside a function body counts as citing that function).
   - `remote`: only in functions and methods the handoff does NOT cite, and that call or are
     called by a cited function directly or through one intermediate function (a callee of
     a callee, or a caller of a caller). Prefer files the handoff does not cite at all; if
     the repository makes that impossible, a non-cited function inside a cited file is
     acceptable, and you record that.
   The change is consequential when following the handoff's fix literally in Q is now wrong:
   `stale-fix.patch` (below) must FAIL `hidden_test.py`, while a different small correct fix
   exists that a careful reader of the current code can find. Typical shapes: a function on
   the path now receives, returns or normalizes values differently; the logic the handoff
   points at moved or was split so the literal edit lands in dead or wrong code; a new
   caller or branch now reaches the faulty code with input the old fix mishandles; a callee
   now does part of what the old fix does, so the old fix double-applies it.
   Keep it plausible: a reviewer should see a sensible change, not a trap.
2. **One behavior-neutral edit** in a file the handoff cites, outside every cited function
   (a new small helper or constant, a docstring or comment block, an import reorder), placed
   above at least one cited line so that some cited line numbers shift. It must not change
   behavior.

Size: at most about 60 changed lines over at most 4 files. Do not touch tests other than to
keep the project's own nearby tests passing with the reference fix (prefer no test edits).

## Files to produce in /tmp/codenib-ab-v5/cases-staging/<case>/
1. `source/` - Q as a brand-new git repo with one commit:
   `git init -q && git add -A && git -c user.name=snapshot -c user.email=snapshot@example.invalid commit -qm Snapshot`.
   Start from a plain copy of P's working tree without its `.git` (`rsync -a --exclude .git`).
   No mention of the bug, the handoff, the study or C's purpose anywhere in the tree.
2. `change.patch` - `diff -ruN` (or `git diff --no-index`) from P's tree to Q's tree, C only.
3. `reference-fix.patch` - the correct minimal fix on Q (at most about 10 changed lines),
   applies with `patch -p1` in a copy of `source/`.
4. `stale-fix.patch` - the handoff's own proposed fix carried out literally on Q: reverse
   `regression.patch` against Q (`patch -R -p1`, fuzz allowed). If it no longer applies,
   hand-apply the change the handoff describes at the place the handoff names (or its
   obvious current equivalent) and say in NOTES.md that you did so. It must apply to Q.
5. `hidden_test.py` - standalone, run from the repository root inside the image with
   `python hidden_test.py`; exit 0 when behavior is correct, 1 with a short message
   otherwise. It checks ONLY behavior that `prompt.txt` states: the reported affected
   examples must now behave correctly, and the listed unaffected inputs must still behave as
   stated. Start from v4's `repro.py` and adapt it to Q. No checks of anything the report
   does not promise.
6. `project_tests.txt` - one pytest target per line (paths or node ids) from the project's
   own suite, closest to the code C and the fix touch; they must pass on Q + reference fix.
   Keep the run under about 60 s.
7. `prompt.txt` - the bug report for the later session: the v4 symptom paragraph verbatim.
   Only if C makes a sentence of it untrue, edit that sentence minimally and explain in
   NOTES.md. Do not mention C, the handoff, or anything that hints at what changed.
8. `validation.log` - outputs, inside the image, of:
   (a) hidden_test on Q: exit 1;
   (b) hidden_test on Q + reference-fix: exit 0;
   (c) hidden_test on Q + stale-fix: exit 1 (say which assertion fails and why);
   (d) project_tests on Q + reference-fix: all pass (counts);
   (e) project_tests on Q unfixed and on Q + stale-fix: counts, for the record;
   (f) repro.py from v4 on P still exits 1 (sanity).
9. `case.json` - {"case", "kind", "source_head" (sha of source/ HEAD),
   "image": "codenib/ab-v4-arm64:<case>-v1", "install", "change_message" (one line, as the
   other contributor's commit subject), "changed_files": [...],
   "consequential": {"file", "function", "q_lines": "a-b", "relation": "cited" |
   "callee of <cited fn>" | "caller of <cited fn>" | "callee of callee ..." etc,
   "in_cited_file": bool},
   "neutral_edit": {"file", "q_lines"},
   "cited_files": [...], "cited_functions": [...] (as you read them from the handoff),
   "stale_fix_mode": "reverse-regression" | "hand-applied",
   "why_stale_fix_fails": str, "reference_fix_summary": str}
10. `NOTES.md` - 5-12 lines: what C does and why it is plausible, why the literal fix now
    fails, what a careful fixer must notice in the current code, anything a grader should
    know.

## Checks before you finish each case
- `git -C source log --oneline` shows only "Snapshot"; `git -C source status` clean.
- Applying `change.patch` to a fresh copy of P's tree reproduces `source/` exactly
  (`diff -r --exclude .git`).
- Validation (a)-(f) as required. If you cannot make the stale fix fail hidden_test.py with a
  plausible change of the assigned KIND after a genuine attempt, stop and report why instead
  of forcing an implausible change; do not switch KIND yourself.
- Do not read anything under /tmp/codenib-ab-v4/runs or any other agent's answers.
