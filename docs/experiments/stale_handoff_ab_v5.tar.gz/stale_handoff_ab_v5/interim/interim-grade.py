"""Interim look (user request): grade finished workflows with grade-v5.check.

Writes only under interim/; the sealed grade-v5.py --runs regrades all 99 later.
"""
import importlib.util, json, sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v5")
spec = importlib.util.spec_from_file_location("grade", ROOT / "grade-v5.py")
grade = importlib.util.module_from_spec(spec); spec.loader.exec_module(grade)
terminal = json.loads((ROOT / "ab-policy-v5.json").read_text())["grading"]["terminal"]
done = json.loads((ROOT / "ab-controller-receipt.json").read_text())["completed"]

def one(item):
    folder = Path(item["receipt"]).parent
    receipt = json.loads((folder / "receipt.json").read_text())
    result = (receipt["phases"][0] if receipt["phases"] else {}).get("result") or {}
    ok = bool(result) and all(result.get(k) == terminal[k] for k in
                              ("subtype", "is_error", "terminal_reason", "stop_reason", "api_error_status"))
    patch = (folder / "repair.patch").read_bytes() if (folder / "repair.patch").exists() else None
    g = grade.check(receipt["workflow"]["instance_id"], patch) if patch else {"hidden_exit": None, "tests_exit": None, "accepted_tests": False}
    return {**receipt["workflow"], "terminal_ok": ok, "hidden_exit": g["hidden_exit"],
            "tests_exit": g["tests_exit"], "accepted": ok and g["accepted_tests"], "log": g.get("log")}

with ThreadPoolExecutor(4) as pool:
    rows = list(pool.map(one, done))
(ROOT / "interim" / "interim-outcomes.json").write_text(json.dumps(rows, indent=1) + "\n")
print(len(rows), "graded")
