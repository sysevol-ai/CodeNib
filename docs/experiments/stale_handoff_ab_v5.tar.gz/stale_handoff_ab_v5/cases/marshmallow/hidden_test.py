"""Hidden test: Schema.dump() must include fields whose `attribute` is a dotted
path with three or more segments (objects, dicts, many=True), while two-segment
paths, plain fields and Schema.load() keep working.
Run from the repository root: python hidden_test.py"""

import sys

sys.path.insert(0, "src")

from marshmallow import Schema, fields  # noqa: E402


class Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class PetSchema(Schema):
    name = fields.String()
    owner_name = fields.String(attribute="owner.name")
    owner_city = fields.String(attribute="owner.address.city")
    owner_zip = fields.String(attribute="owner.address.geo.zip")


pet_obj = Obj(
    name="Rex",
    owner=Obj(name="Ana", address=Obj(city="Lyon", geo=Obj(zip="69001"))),
)
pet_dict = {
    "name": "Rex",
    "owner": {"name": "Ana", "address": {"city": "Lyon", "geo": {"zip": "69001"}}},
}
expected = {
    "name": "Rex",
    "owner_name": "Ana",
    "owner_city": "Lyon",
    "owner_zip": "69001",
}

problems = []


def attempt(label, func):
    try:
        return func()
    except Exception as exc:  # noqa: BLE001
        problems.append(f"{label} raised {type(exc).__name__}: {exc}")
        return None


schema = PetSchema()

class PlainSchema(Schema):
    name = fields.String()
    owner_name = fields.String(attribute="owner.name")


# Unaffected inputs: plain field and two-segment path on dump.
for label, data in (("object", pet_obj), ("dict", pet_dict)):
    got = attempt(f"control dump({label})", lambda d=data: PlainSchema().dump(d))
    if got is not None and got != {"name": "Rex", "owner_name": "Ana"}:
        problems.append(f"control: dump({label}) of plain/2-segment fields = {got!r}")

# Unaffected input: load() with the same dotted attributes builds nested dicts.
loaded = attempt(
    "load()",
    lambda: schema.load(
        {"name": "Rex", "owner_name": "Ana", "owner_city": "Lyon", "owner_zip": "69001"}
    ),
)
want_loaded = {
    "name": "Rex",
    "owner": {"name": "Ana", "address": {"city": "Lyon", "geo": {"zip": "69001"}}},
}
if loaded is not None and loaded != want_loaded:
    problems.append(f"control: load() = {loaded!r}")

# Affected inputs: three- and four-segment attribute paths on dump.
for label, data in (("object", pet_obj), ("dict", pet_dict)):
    got = attempt(f"dump({label})", lambda d=data: schema.dump(d))
    if got is not None and got != expected:
        problems.append(f"dump({label}) = {got!r}, expected {expected!r}")
got = attempt("dump(many=True)", lambda: PetSchema(many=True).dump([pet_obj, pet_dict]))
if got is not None and got != [expected, expected]:
    problems.append(f"dump(many=True) = {got!r}")

if problems:
    print("FAIL: Schema.dump() with dotted attribute paths is wrong:")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print("OK: dotted attribute paths dump correctly at every depth")
sys.exit(0)
