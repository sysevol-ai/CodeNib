"""Hidden test: user-config abbreviations, including overrides of built-in prefixes.

Run from the repository root inside the case image: ``python hidden_test.py``.
Runs the ``cookiecutter`` CLI (``python -m cookiecutter --no-input``) against local
templates only. https://github.com/ is redirected through git's ``insteadOf`` either
to a nonexistent path (so a clone attempt fails fast) or, for the runs where the
built-in ``gh:`` expansion is the documented behavior, to a local stand-in repo.

Exit 0 when every invocation behaves as the bug report says it should, 1 otherwise.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parent


def make_template(root: Path, owner: str) -> None:
    (root / "{{cookiecutter.project_slug}}").mkdir(parents=True)
    (root / "cookiecutter.json").write_text(
        json.dumps({"project_slug": "widget", "owner": owner}), encoding="utf-8"
    )
    (root / "{{cookiecutter.project_slug}}" / "README.txt").write_text(
        "owner={{ cookiecutter.owner }}\n", encoding="utf-8"
    )


def make_git_repo(root: Path, owner: str) -> None:
    make_template(root, owner)
    git = ["git", "-c", "user.name=t", "-c", "user.email=t@example.invalid"]
    for args in (["init", "-q"], ["add", "-A"], ["commit", "-qm", "template"]):
        subprocess.run([*git, *args], cwd=root, check=True, capture_output=True)


def run(args: list[str], out: Path, env: dict[str, str]) -> tuple[int, str, str]:
    out.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        [sys.executable, "-m", "cookiecutter", "--no-input", "-o", str(out), *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=120,
    )
    readme = out / "widget" / "README.txt"
    content = (
        readme.read_text(encoding="utf-8").strip()
        if readme.exists()
        else "<no project generated>"
    )
    return proc.returncode, content, (proc.stdout + proc.stderr).strip()


def main() -> int:
    failures: list[str] = []
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        mirror = base / "mirror"
        make_template(mirror / "acme" / "widget", "nobody")
        make_git_repo(base / "gitmirror" / "acme" / "widget.git", "nobody")
        # Local stand-in for https://github.com/acme/widget.git
        make_git_repo(base / "fakegithub" / "acme" / "widget.git", "github")

        config_text = (
            "cookiecutters_dir: {0}/cache\n"
            "replay_dir: {0}/replay\n"
            "default_context:\n"
            "  owner: from-config\n"
            "abbreviations:\n"
            "  gh: {1}/{{0}}\n"
            "  gl: {1}/{{0}}\n"
            "  bb: {1}/{{0}}\n"
            "  corp: {1}/{{0}}\n"
        ).format(base, mirror)
        config = base / "cfg.yaml"
        config.write_text(config_text, encoding="utf-8")

        homes = {name: base / name for name in ("home", "home_rc")}
        for home in homes.values():
            home.mkdir()
        (homes["home_rc"] / ".cookiecutterrc").write_text(config_text, encoding="utf-8")

        def env_for(home: str, github: str, **extra: str) -> dict[str, str]:
            env = dict(os.environ)
            env.pop("COOKIECUTTER_CONFIG", None)
            env["PYTHONPATH"] = os.pathsep.join(
                p for p in (str(REPO), env.get("PYTHONPATH", "")) if p
            )
            env.update(
                HOME=str(homes[home]),
                GIT_TERMINAL_PROMPT="0",
                GIT_CONFIG_COUNT="1",
                GIT_CONFIG_KEY_0=f"url.{github}.insteadOf",
                GIT_CONFIG_VALUE_0="https://github.com/",
                **extra,
            )
            return env

        no_github = "file:///nonexistent-github-mirror/"
        fake_github = f"file://{base}/fakegithub/"
        cfg = ["--config-file", str(config)]
        cases = [
            # Reported as affected: user abbreviations redefining built-in prefixes.
            ("--config-file redefining 'gh:'", cfg + ["gh:acme/widget"],
             env_for("home", no_github), "owner=from-config"),
            ("--config-file redefining 'gl:'", cfg + ["gl:acme/widget"],
             env_for("home", no_github), "owner=from-config"),
            ("--config-file redefining 'bb:'", cfg + ["bb:acme/widget"],
             env_for("home", no_github), "owner=from-config"),
            ("~/.cookiecutterrc redefining 'gh:'", ["gh:acme/widget"],
             env_for("home_rc", no_github), "owner=from-config"),
            ("COOKIECUTTER_CONFIG redefining 'gh:'", ["gh:acme/widget"],
             env_for("home", no_github, COOKIECUTTER_CONFIG=str(config)),
             "owner=from-config"),
            # Reported as unaffected.
            ("custom 'corp:' abbreviation", cfg + ["corp:acme/widget"],
             env_for("home", no_github), "owner=from-config"),
            ("plain local path with the same config",
             cfg + [str(mirror / "acme" / "widget")],
             env_for("home", no_github), "owner=from-config"),
            ("full URL with the same config",
             cfg + [f"file://{base}/gitmirror/acme/widget.git"],
             env_for("home", no_github), "owner=from-config"),
            ("--default-config with 'gh:' expands to GitHub",
             ["--default-config", "gh:acme/widget"],
             env_for("home", fake_github), "owner=github"),
            ("no user config with 'gh:' expands to GitHub", ["gh:acme/widget"],
             env_for("home", fake_github), "owner=github"),
            ("--default-config with a plain local path",
             ["--default-config", str(mirror / "acme" / "widget")],
             env_for("home", no_github), "owner=nobody"),
        ]
        for index, (label, args, env, expected) in enumerate(cases):
            code, content, output = run(args, base / f"out{index}", env)
            ok = code == 0 and content == expected
            print(f"[{'ok' if ok else 'WRONG'}] {label}: exit {code}, README {content!r}")
            if not ok:
                tail = output.splitlines()[-1] if output else ""
                failures.append(
                    f"{label}: expected {expected!r}; last output line: {tail}"
                )

    if failures:
        print("FAIL: abbreviation/config handling is wrong:")
        for line in failures:
            print("  - " + line)
        return 1
    print("PASS: user-config abbreviations (including built-in overrides) honoured")
    return 0


if __name__ == "__main__":
    sys.exit(main())
