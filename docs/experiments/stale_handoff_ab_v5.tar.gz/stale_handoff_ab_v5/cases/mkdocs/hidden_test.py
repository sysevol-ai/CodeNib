"""Build small MkDocs sites through the `mkdocs build` CLI and check the sidebar navigation.

Run from the repository root inside the case image: `python hidden_test.py`.
Exit 1 when the navigation is wrong (or a build fails), 0 when every site is correct.
"""

from __future__ import annotations

import posixpath
import re
import subprocess
import sys
import tempfile
from pathlib import Path

TOGGLE_OR_ITEM = re.compile(
    r'class="nav-link dropdown-toggle[^"]*"[^>]*>([^<]+)</a>'  # a section heading
    r'|<a href="([^"]+)" class="dropdown-item[^"]*"'  # a page inside a section
)


def build(root: Path, files: dict[str, str], nav: str | None = None) -> list[tuple[str, list[str]]]:
    docs = root / "docs"
    for rel, text in files.items():
        path = docs / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    config = "site_name: Demo\ntheme: mkdocs\n" + (nav or "")
    (root / "mkdocs.yml").write_text(config, encoding="utf-8")
    proc = subprocess.run(
        [sys.executable, "-m", "mkdocs", "build", "-q", "-f", str(root / "mkdocs.yml"), "-d", str(root / "site")],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        print(proc.stdout + proc.stderr)
        print(f"FAIL: mkdocs build failed for {root.name} (exit {proc.returncode})")
        raise SystemExit(1)
    page_url = ""
    if not (root / "site" / "index.html").exists():  # no top-level page: read the nav from a nested page
        page_url = "guide/install/"
    html = (root / "site" / page_url / "index.html").read_text(encoding="utf-8")
    sections: list[tuple[str, list[str]]] = []
    for match in TOGGLE_OR_ITEM.finditer(html):
        title, href = match.groups()
        if title is not None:
            sections.append((title.strip(), []))
        elif sections:
            sections[-1][1].append(posixpath.normpath(posixpath.join(page_url, href)) + "/")
    return sections


def main() -> int:
    nested = {
        "index.md": "# Welcome\n",
        "guide/install.md": "# Install\n",
        "guide/usage.md": "# Usage\n",
        "api/reference.md": "# Reference\n",
    }
    expected_nested = [("Api", ["api/reference/"]), ("Guide", ["guide/install/", "guide/usage/"])]
    failures: list[str] = []
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)

        # Affected: no `nav` key, a folder holding two pages next to a top-level page.
        got = build(base / "auto", nested)
        if got != expected_nested:
            failures.append(f"auto-generated nav: expected {expected_nested}, got {got}")

        # Unaffected: the same files with an explicit `nav` in mkdocs.yml.
        explicit = (
            "nav:\n"
            "  - Home: index.md\n"
            "  - Api:\n"
            "    - api/reference.md\n"
            "  - Guide:\n"
            "    - guide/install.md\n"
            "    - guide/usage.md\n"
        )
        got = build(base / "explicit", nested, explicit)
        if got != expected_nested:
            failures.append(f"explicit nav: expected {expected_nested}, got {got}")

        # Unaffected: every folder holds a single page.
        single = {"index.md": "# Welcome\n", "guide/install.md": "# Install\n", "api/reference.md": "# Reference\n"}
        want = [("Api", ["api/reference/"]), ("Guide", ["guide/install/"])]
        got = build(base / "single", single)
        if got != want:
            failures.append(f"single-page folders: expected {want}, got {got}")

        # Unaffected: no top-level page, so the docs root holds only folders.
        no_root = {"guide/install.md": "# Install\n", "guide/usage.md": "# Usage\n", "api/reference.md": "# Reference\n"}
        got = build(base / "noroot", no_root)
        if got != expected_nested:
            failures.append(f"docs root without pages: expected {expected_nested}, got {got}")

    if failures:
        print("FAIL: auto-generated navigation is wrong:")
        for line in failures:
            print("  - " + line)
        return 1
    print("OK: auto-generated and explicit navigation group pages under one section per folder")
    return 0


if __name__ == "__main__":
    sys.exit(main())
