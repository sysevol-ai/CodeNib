"""Check the command recorded in the pip-compile output header.

Runs ``pip-compile`` (via ``python -m piptools compile``) offline against a
throw-away local wheel and checks the "#    pip-compile ..." line it writes into
the output file header, for the inputs named in the bug report.

Exit 1 when the recorded command is wrong, 0 when it is correct.
"""

import base64
import hashlib
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


def build_wheel(dest: Path) -> None:
    """Write a minimal pure-Python wheel ``demo_pkg-1.0`` into *dest*."""
    name = "demo_pkg-1.0"
    files = {
        "demo_pkg/__init__.py": b"",
        f"{name}.dist-info/METADATA": (
            b"Metadata-Version: 2.1\nName: demo-pkg\nVersion: 1.0\n"
        ),
        f"{name}.dist-info/WHEEL": (
            b"Wheel-Version: 1.0\nGenerator: repro\nRoot-Is-Purelib: true\n"
            b"Tag: py3-none-any\n"
        ),
    }
    record = []
    for path, data in files.items():
        digest = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=")
        record.append(f"{path},sha256={digest.decode()},{len(data)}")
    record.append(f"{name}.dist-info/RECORD,,")
    files[f"{name}.dist-info/RECORD"] = ("\n".join(record) + "\n").encode()
    with zipfile.ZipFile(dest / f"{name}-py3-none-any.whl", "w") as zf:
        for path, data in files.items():
            zf.writestr(path, data)


def recorded_command(workdir: Path, args, extra_env=None, out="requirements.txt"):
    env = dict(os.environ)
    env.pop("CUSTOM_COMPILE_COMMAND", None)
    env["PIP_FIND_LINKS"] = str(workdir / "wheels")
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    env.update(extra_env or {})
    proc = subprocess.run(
        [sys.executable, "-m", "piptools", "compile", "--cache-dir",
         str(workdir / "cache"), *args],
        cwd=workdir, env=env, capture_output=True, text=True,
    )
    if proc.returncode != 0:
        print(proc.stdout, proc.stderr)
        raise SystemExit(f"pip-compile failed for args {args!r}")
    text = (workdir / out).read_text()
    (workdir / out).unlink()
    for line in text.splitlines():
        if line.startswith("#    "):
            return line[5:].strip()
    raise SystemExit(f"no recorded command in header for args {args!r}:\n{text}")


def main() -> int:
    failures = []
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        (work / "wheels").mkdir()
        build_wheel(work / "wheels")
        (work / "requirements.in").write_text("demo-pkg\n")

        cases = [
            # (description, args, extra env, output file, expected recorded command)
            (
                "-o/--output-file and -f/--find-links",
                ["--output-file", "pins.txt", "--find-links", "wheels",
                 "requirements.in"],
                None, "pins.txt",
                "pip-compile --find-links=wheels --output-file=pins.txt "
                "requirements.in",
            ),
            (
                "short spellings -o and -f",
                ["-o", "pins.txt", "-f", "wheels", "requirements.in"],
                None, "pins.txt",
                "pip-compile --find-links=wheels --output-file=pins.txt "
                "requirements.in",
            ),
            (
                "one-off --upgrade and --verbose are left out",
                ["--upgrade", "--verbose", "requirements.in"],
                None, "requirements.txt",
                "pip-compile requirements.in",
            ),
            (
                "--pre",
                ["--pre", "requirements.in"],
                None, "requirements.txt",
                "pip-compile --pre requirements.in",
            ),
            # Unaffected inputs
            (
                "long-only options and flag pairs",
                ["--allow-unsafe", "--no-annotate", "--strip-extras",
                 "--no-emit-index-url", "requirements.in"],
                None, "requirements.txt",
                "pip-compile --allow-unsafe --no-annotate --no-emit-index-url "
                "--strip-extras requirements.in",
            ),
            (
                "valued long-only option",
                ["--annotation-style", "line", "requirements.in"],
                None, "requirements.txt",
                "pip-compile --annotation-style=line requirements.in",
            ),
            (
                "CUSTOM_COMPILE_COMMAND",
                ["-o", "pins.txt", "requirements.in"],
                {"CUSTOM_COMPILE_COMMAND": "make pins"}, "pins.txt",
                "make pins",
            ),
        ]
        for desc, args, env, out, expected in cases:
            got = recorded_command(work, args, env, out)
            status = "ok" if got == expected else "WRONG"
            print(f"[{status}] {desc}: {got}")
            if got != expected:
                print(f"         expected: {expected}")
                failures.append(desc)

    if failures:
        print(f"FAIL: wrong command recorded in the header for: {failures}")
        return 1
    print("header command recorded correctly for all inputs")
    return 0


if __name__ == "__main__":
    sys.exit(main())
