"""Check that tox picks up a project's configuration from every supported location.

Run from the repository root inside the case image: `python hidden_test.py`.
Exit 0 when every check passes, 1 (with a short message per failure) otherwise.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

INI_BODY = """\
[tox]
env_list = lint, unit
skipsdist = true

[testenv:lint]
description = run linters
skip_install = true
commands = python -c 'print("lint")'

[testenv:unit]
description = run unit tests
skip_install = true
commands = python -c 'print("unit")'
"""

TOML_TABLES = """\
env_list = ["lint", "unit"]
skipsdist = true

[{prefix}env.lint]
description = "run linters"
skip_install = true
commands = [["python", "-c", "print('lint')"]]

[{prefix}env.unit]
description = "run unit tests"
skip_install = true
commands = [["python", "-c", "print('unit')"]]
"""

PROJECT = '[project]\nname = "demo"\nversion = "0.1"\n'
LEGACY = "pyproject.toml legacy_tox_ini"

PROJECTS: dict[str, dict[str, str]] = {
    # affected: pyproject.toml holding the INI text under [tool.tox] legacy_tox_ini, no other tox config file
    LEGACY: {
        "pyproject.toml": PROJECT + '\n[tool.tox]\nlegacy_tox_ini = """\n' + INI_BODY + '"""\n',
    },
    # stated as working
    "tox.ini": {"tox.ini": INI_BODY},
    "setup.cfg [tox:tox]": {"setup.cfg": INI_BODY.replace("[tox]", "[tox:tox]")},
    "pyproject.toml native [tool.tox]": {
        "pyproject.toml": PROJECT + "\n[tool.tox]\n" + TOML_TABLES.format(prefix="tool.tox."),
    },
    "tox.toml": {"tox.toml": TOML_TABLES.format(prefix="")},
    "tox.toml next to pyproject.toml with an empty [tool.tox]": {
        "pyproject.toml": PROJECT + "\n[tool.tox]\n",
        "tox.toml": TOML_TABLES.format(prefix=""),
    },
}

EXPECTED = {"lint": "run linters", "unit": "run unit tests"}


def tox(cwd: Path, home: Path, *args: str) -> tuple[int, str, str]:
    env = dict(os.environ, HOME=str(home), XDG_CONFIG_HOME=str(home / ".config"), NO_COLOR="1")
    env.pop("TOX_USER_CONFIG_FILE", None)
    proc = subprocess.run(
        [sys.executable, "-m", "tox", *args], cwd=cwd, capture_output=True, text=True, env=env, timeout=300
    )
    return proc.returncode, proc.stdout, proc.stdout + proc.stderr


def listed_envs(stdout: str) -> dict[str, str]:
    listed: dict[str, str] = {}
    for line in stdout.splitlines():
        if " -> " in line:
            name, _, desc = line.partition(" -> ")
            listed[name.strip()] = desc.strip()
    return listed


def short(text: str) -> str:
    lines = [line for line in text.strip().splitlines() if line.strip()]
    return " | ".join(lines[-3:])


def main() -> int:
    failures: list[str] = []
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        home = base / "home"
        home.mkdir()
        roots: dict[str, Path] = {}
        for index, (label, files) in enumerate(PROJECTS.items()):
            project = base / f"project{index}"
            project.mkdir()
            for name, text in files.items():
                (project / name).write_text(text, encoding="utf-8")
            roots[label] = project
            code, out, _ = tox(project, home, "list")
            if code != 0 or listed_envs(out) != EXPECTED:
                failures.append(f"{label}: `tox list` exit {code}, listed {listed_envs(out)} (expected {EXPECTED})")

        legacy = roots[LEGACY]
        subdir = legacy / "src" / "pkg"
        subdir.mkdir(parents=True)
        for where, args in (
            ("project root", ("list", "-c", "pyproject.toml")),
            ("project root", ("list", "-c", ".")),
            ("subdirectory src/pkg", ("list",)),
        ):
            cwd = legacy if where == "project root" else subdir
            code, out, _ = tox(cwd, home, *args)
            if code != 0 or listed_envs(out) != EXPECTED:
                failures.append(
                    f"{LEGACY}: `tox {' '.join(args)}` from {where} exit {code}, listed {listed_envs(out)}"
                    f" (expected {EXPECTED})"
                )

        code, out, both = tox(legacy, home, "config", "-e", "lint", "-k", "description")
        if code != 0 or "description = run linters" not in out:
            failures.append(f"{LEGACY}: `tox config -e lint` exit {code}: {short(both)}")

        code, out, both = tox(legacy, home, "run", "-e", "lint")
        if code != 0 or "provided environments not found" in both or "lint: OK" not in out:
            failures.append(f"{LEGACY}: `tox run -e lint` exit {code}: {short(both)}")

    if failures:
        print("FAIL: tox does not pick up the project's configuration:")
        for line in failures:
            print("  - " + line)
        return 1
    print("OK: every configuration location is used, and the legacy_tox_ini environments are found and run")
    return 0


if __name__ == "__main__":
    sys.exit(main())
