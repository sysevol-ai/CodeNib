"""Hidden test: positional CLI values must bind to the right parameters.

Run from the repository root: ``python hidden_test.py``. Writes small
single-command Typer apps (``app = typer.Typer()`` + ``@app.command()`` +
``app()``) into a temp dir, runs each as a CLI and checks which values each
parameter receives. Covers exactly the inputs the bug report lists.

Exit 0 when every case binds correctly, 1 otherwise.
"""

import json
import os
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

REPO = Path(__file__).resolve().parent

APPS = {
    # Affected: a list argument followed by two single arguments.
    "cli_copy_mode": """
        def main(sources: list[str], dest: str, mode: str):
            print(json.dumps({"sources": sources, "dest": dest, "mode": mode}))
    """,
    # Affected: same shape with a typed trailing argument.
    "cli_copy_count": """
        def main(sources: list[str], dest: str, retries: int):
            print(json.dumps({"sources": sources, "dest": dest, "retries": retries}))
    """,
    # Unaffected: a list argument followed by exactly one argument.
    "cli_copy": """
        def main(sources: list[str], dest: str):
            print(json.dumps({"sources": sources, "dest": dest}))
    """,
    # Unaffected: a list argument in the last position.
    "cli_tag": """
        def main(tag: str, mode: str, files: list[str]):
            print(json.dumps({"tag": tag, "mode": mode, "files": files}))
    """,
    # Unaffected: no list argument at all.
    "cli_plain": """
        def main(first: str, second: str, third: str):
            print(json.dumps({"first": first, "second": second, "third": third}))
    """,
    # Unaffected: a positional dest plus --mode as an option.
    "cli_copy_opt": """
        def main(sources: list[str], dest: str, mode: str = typer.Option("safe")):
            print(json.dumps({"sources": sources, "dest": dest, "mode": mode}))
    """,
}

HEADER = """
import json
import typer

app = typer.Typer()

@app.command()
"""

FOOTER = """
if __name__ == "__main__":
    app()
"""

CASES = [
    # (app, argv, expected parsed values)
    ("cli_copy_mode", ["a.txt", "b.txt", "c.txt", "out", "fast"],
     {"sources": ["a.txt", "b.txt", "c.txt"], "dest": "out", "mode": "fast"}),
    ("cli_copy_count", ["a.txt", "b.txt", "out", "3"],
     {"sources": ["a.txt", "b.txt"], "dest": "out", "retries": 3}),
    ("cli_copy", ["a.txt", "b.txt", "out"],
     {"sources": ["a.txt", "b.txt"], "dest": "out"}),
    ("cli_tag", ["v1", "fast", "a.txt", "b.txt"],
     {"tag": "v1", "mode": "fast", "files": ["a.txt", "b.txt"]}),
    ("cli_plain", ["one", "two", "three"],
     {"first": "one", "second": "two", "third": "three"}),
    ("cli_copy_opt", ["a.txt", "b.txt", "out", "--mode", "fast"],
     {"sources": ["a.txt", "b.txt"], "dest": "out", "mode": "fast"}),
]


def main() -> int:
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join(
        p for p in (str(REPO), env.get("PYTHONPATH", "")) if p
    )
    env["TERM"] = "dumb"
    failures = []
    with tempfile.TemporaryDirectory() as tmp:
        for name, body in APPS.items():
            src = HEADER + textwrap.dedent(body) + FOOTER
            Path(tmp, f"{name}.py").write_text(src)
        for name, argv, expected in CASES:
            proc = subprocess.run(
                [sys.executable, f"{name}.py", *argv],
                cwd=tmp, capture_output=True, text=True, env=env,
            )
            cmd = f"python {name}.py {' '.join(argv)}"
            if "Traceback" in proc.stderr:
                print(proc.stderr)
                print(f"FAIL: crash while running {cmd}")
                return 1
            if proc.returncode != 0:
                err = [ln.strip(" │╭╰─") for ln in proc.stderr.splitlines()]
                print(f"[WRONG] {cmd}: exit {proc.returncode}: "
                      f"{' / '.join(ln for ln in err if ln)}")
                failures.append(cmd)
                continue
            got = json.loads(proc.stdout)
            ok = got == expected
            print(f"[{'ok' if ok else 'WRONG'}] {cmd}: {got}")
            if not ok:
                print(f"         expected: {expected}")
                failures.append(cmd)
    if failures:
        print(f"FAIL: positional values bound to the wrong parameters: {failures}")
        return 1
    print("PASS: all positional arguments bound correctly")
    return 0


if __name__ == "__main__":
    sys.exit(main())
