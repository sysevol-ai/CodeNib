"""Run from the repository root: python hidden_test.py

With combine_as_imports, isort must not add a plain import for a name that the
file only imports under an alias. Checks the `isort` CLI on temp files and stdin.
Exit 0 when behavior is correct, 1 otherwise.
"""
import os
import subprocess
import sys
import tempfile

SOURCE = '''\
import sys
from typing import List as L, Dict
from os import path as osp
from collections import OrderedDict, OrderedDict as OD
import numpy as np

print(sys, L, Dict, osp, OrderedDict, OD, np)
'''

COMBINED = '''\
import sys
from collections import OrderedDict, OrderedDict as OD
from os import path as osp
from typing import Dict, List as L

import numpy as np

print(sys, L, Dict, osp, OrderedDict, OD, np)
'''

DEFAULT = '''\
import sys
from collections import OrderedDict
from collections import OrderedDict as OD
from os import path as osp
from typing import Dict
from typing import List as L

import numpy as np

print(sys, L, Dict, osp, OrderedDict, OD, np)
'''

# Unaffected even with --combine-as: names imported both plainly and aliased,
# and straight `import x as y`.
BOTH = '''\
from collections import OrderedDict, OrderedDict as OD
import numpy as np

print(OrderedDict, OD, np)
'''
BOTH_OUT = '''\
from collections import OrderedDict, OrderedDict as OD

import numpy as np

print(OrderedDict, OD, np)
'''

repo_root = os.getcwd()
workdir = tempfile.mkdtemp()
env = dict(os.environ)
env['PYTHONPATH'] = repo_root + os.pathsep + env.get('PYTHONPATH', '')


def isort_cli(args, stdin=None):
    return subprocess.run(
        [sys.executable, '-m', 'isort', *args],
        cwd=workdir, env=env, capture_output=True, text=True, input=stdin,
    )


def run_isort(filename, content, *options):
    path = os.path.join(workdir, filename)
    with open(path, 'w') as f:
        f.write(content)
    proc = isort_cli([*options, path])
    if proc.returncode != 0:
        print(proc.stdout, proc.stderr)
        print(f'FAIL: isort {" ".join(options)} {filename} exited {proc.returncode}')
        sys.exit(1)
    with open(path) as f:
        return f.read()


def added_lines(out):
    return [line for line in out.splitlines() if line not in COMBINED.splitlines()]


failures = []

# Affected: rewriting the file with --combine-as or the django profile.
for name, options in [('combine_as.py', ('--combine-as',)),
                      ('django.py', ('--profile', 'django'))]:
    out = run_isort(name, SOURCE, *options)
    if out != COMBINED:
        failures.append(f'isort {" ".join(options)}: unexpected import lines {added_lines(out)}')

# Affected: reading stdin.
proc = isort_cli(['--combine-as', '-'], stdin=SOURCE)
if proc.returncode != 0 or proc.stdout != COMBINED:
    failures.append(f'isort --combine-as - (stdin): exit {proc.returncode}, '
                    f'unexpected import lines {added_lines(proc.stdout)}')

# Affected: --check-only on a file that is already correctly combined.
path = os.path.join(workdir, 'already_sorted.py')
with open(path, 'w') as f:
    f.write(COMBINED)
proc = isort_cli(['--combine-as', '--check-only', path])
if proc.returncode != 0:
    failures.append(f'isort --combine-as --check-only reports a correctly sorted file '
                    f'as wrong (exit {proc.returncode}): {(proc.stdout + proc.stderr).strip()}')

# Unaffected: default options.
out = run_isort('default.py', SOURCE)
if out != DEFAULT:
    failures.append(f'default options changed output:\n{out}')

# Unaffected: plain+aliased name and straight alias with --combine-as.
out = run_isort('both.py', BOTH, '--combine-as')
if out != BOTH_OUT:
    failures.append(f'--combine-as with plain+aliased name changed output:\n{out}')

if failures:
    print('FAIL:', *failures, sep='\n  ')
    sys.exit(1)
print('OK: --combine-as keeps alias-only imports as aliases; unaffected inputs are unchanged.')
sys.exit(0)
