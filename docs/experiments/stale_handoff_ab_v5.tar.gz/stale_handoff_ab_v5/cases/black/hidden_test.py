"""Hidden test. Run from the repository root: python hidden_test.py

Black must keep consecutive one-line dummy implementations ("def f(): ...") together
in .py files when the user wrote them without blank lines (an @overload group and
Protocol methods), with `black FILE`, `--check`/`--diff` and `-c`, with and without
`--preview`. Inputs the report lists as unaffected must still format as stated.
Exit 0 when all of that holds, 1 otherwise.
"""
import os
import subprocess
import sys
import tempfile

OVERLOADS = '''\
from typing import overload


@overload
def parse(value: int) -> int: ...
@overload
def parse(value: str) -> str: ...
def parse(value):
    return value
'''

PROTOCOL = '''\
from typing import Protocol


class Reader(Protocol):
    def read(self, size: int) -> bytes: ...
    def close(self) -> None: ...
'''

# Unaffected inputs, with the output black is expected to produce.
REGULAR_IN = '''\
def first():
    return 1
def second():
    return 2
'''
REGULAR_OUT = '''\
def first():
    return 1


def second():
    return 2
'''

REGULAR_CLASS_IN = '''\
class Reader:
    def read(self):
        return b""
    def close(self):
        return None
'''
REGULAR_CLASS_OUT = '''\
class Reader:
    def read(self):
        return b""

    def close(self):
        return None
'''

SEPARATED = '''\
def first(): ...


def second(): ...
'''

PYI_IN = '''\
from typing import overload
@overload
def parse(value: int) -> int: ...
@overload
def parse(value: str) -> str: ...
class Reader:
    def read(self, size: int) -> bytes: ...
    def close(self) -> None: ...
'''
PYI_OUT = '''\
from typing import overload

@overload
def parse(value: int) -> int: ...
@overload
def parse(value: str) -> str: ...

class Reader:
    def read(self, size: int) -> bytes: ...
    def close(self) -> None: ...
'''

repo_root = os.getcwd()
workdir = tempfile.mkdtemp()
env = dict(os.environ, BLACK_CACHE_DIR=os.path.join(workdir, ".cache"))
env["PYTHONPATH"] = os.path.join(repo_root, "src") + os.pathsep + env.get("PYTHONPATH", "")

problems = []


def black(*args):
    return subprocess.run(
        [sys.executable, "-m", "black", *args],
        cwd=workdir, env=env, capture_output=True, text=True,
    )


def write(filename, content):
    path = os.path.join(workdir, filename)
    with open(path, "w") as f:
        f.write(content)
    return path


def format_file(filename, content, *flags):
    path = write(filename, content)
    proc = black("-q", *flags, path)
    if proc.returncode != 0:
        problems.append(
            f"black {' '.join(flags)} {filename} exited {proc.returncode}: "
            f"{(proc.stderr or proc.stdout).strip()[-300:]}"
        )
        return None
    with open(path) as f:
        return f.read()


# Affected inputs: must be left unchanged by every entry point, with and without
# --preview.
for flags in ((), ("--preview",)):
    label = " ".join(flags) or "default"
    for name, content in (("overloads.py", OVERLOADS), ("protocol.py", PROTOCOL)):
        out = format_file(name, content, *flags)
        if out is not None and out != content:
            problems.append(f"[{label}] black FILE changed {name}:\n{out}")

        path = write(name, content)
        proc = black("--check", "--diff", "-q", *flags, path)
        if proc.returncode != 0 or proc.stdout.strip():
            problems.append(
                f"[{label}] black --check --diff {name}: exit {proc.returncode}\n"
                f"{proc.stdout}{proc.stderr.strip()[-300:]}"
            )

        proc = black("-q", *flags, "-c", content)
        if proc.returncode != 0 or proc.stdout != content:
            problems.append(
                f"[{label}] black -c for {name}: exit {proc.returncode}\n"
                f"{proc.stdout}{proc.stderr.strip()[-300:]}"
            )

# Unaffected inputs.
for name, content, expected in (
    ("regular.py", REGULAR_IN, REGULAR_OUT),
    ("regular_class.py", REGULAR_CLASS_IN, REGULAR_CLASS_OUT),
    ("separated.py", SEPARATED, SEPARATED),
    ("stubs.pyi", PYI_IN, PYI_OUT),
):
    out = format_file(name, content)
    if out is not None and out != expected:
        problems.append(f"unaffected input {name}: unexpected output:\n{out}")

if problems:
    print("FAIL:")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print("OK: dummy implementations stay grouped in .py files; unaffected inputs format as expected.")
sys.exit(0)
