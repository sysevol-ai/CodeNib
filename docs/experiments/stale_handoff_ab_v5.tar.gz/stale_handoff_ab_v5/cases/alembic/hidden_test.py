"""Check that `alembic revision` post-write hooks process the new revision file.

Run from the repository root: python hidden_test.py
Exit 0 when every configuration formats the new file, 1 (with a short message) otherwise.
"""

import os
import shutil
import subprocess
import sys
import tempfile

REPO = os.path.abspath(os.path.dirname(__file__) or ".")
ENV = dict(os.environ, PYTHONPATH=REPO + os.pathsep + os.environ.get("PYTHONPATH", ""))


class AlembicFailed(Exception):
    pass


def alembic(project, *args):
    proc = subprocess.run(
        [sys.executable, "-m", "alembic", *args],
        cwd=project,
        env=ENV,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise AlembicFailed(
            f"alembic {' '.join(args)} exited {proc.returncode}:\n{proc.stdout}{proc.stderr}"
        )
    return proc.stdout + proc.stderr


# (label, hook lines for [post_write_hooks]); every one must format the new file
CASES = [
    # reported as affected
    (
        "console_scripts, options without token (-l 79)",
        ["hooks = black", "black.type = console_scripts",
         "black.entrypoint = black", "black.options = -l 79"],
    ),
    (
        "module, options without token (--quiet)",
        ["hooks = black", "black.type = module", "black.module = black",
         "black.options = --quiet"],
    ),
    # reported as still working
    (
        "console_scripts, options with REVISION_SCRIPT_FILENAME",
        ["hooks = black", "black.type = console_scripts",
         "black.entrypoint = black",
         "black.options = -l 79 REVISION_SCRIPT_FILENAME"],
    ),
    (
        "console_scripts, no options line",
        ["hooks = black", "black.type = console_scripts",
         "black.entrypoint = black"],
    ),
]


def main():
    project = tempfile.mkdtemp()
    problems = []
    try:
        alembic(project, "init", "migrations")
        ini_path = os.path.join(project, "alembic.ini")
        with open(ini_path) as f:
            original_ini = f.read()
        if "\n[post_write_hooks]\n" not in original_ini:
            print("FAIL: generated alembic.ini has no [post_write_hooks] section")
            return 1

        for n, (label, hook_lines) in enumerate(CASES, start=1):
            with open(ini_path, "w") as f:
                f.write(original_ini.replace(
                    "\n[post_write_hooks]\n",
                    "\n[post_write_hooks]\n" + "\n".join(hook_lines) + "\n",
                ))
            rev_id = f"abc{n:09d}"
            try:
                output = alembic(project, "revision", "-m", f"step {n}", "--rev-id", rev_id)
            except AlembicFailed as exc:
                problems.append(f"{label}: {exc}")
                continue
            versions = os.path.join(project, "migrations", "versions")
            found = [
                os.path.join(versions, p)
                for p in os.listdir(versions)
                if p.startswith(rev_id) and p.endswith(".py")
            ]
            if len(found) != 1:
                problems.append(f"{label}: expected one new revision file, found {found}")
                continue
            with open(found[0]) as f:
                text = f.read()
            # black rewrites the template's single-quoted repr() into double quotes
            if f'revision: str = "{rev_id}"' not in text:
                problems.append(f"{label}: the new revision file was not processed by the hook")
                for line in output.splitlines():
                    if line.strip():
                        problems.append("    | " + line.strip())
    finally:
        shutil.rmtree(project, ignore_errors=True)

    if problems:
        print("FAIL: post-write hook did not format the new revision file:")
        for p in problems:
            print("  -", p)
        return 1
    print("OK: post-write hooks ran on the new revision file in every configuration")
    return 0


if __name__ == "__main__":
    sys.exit(main())
