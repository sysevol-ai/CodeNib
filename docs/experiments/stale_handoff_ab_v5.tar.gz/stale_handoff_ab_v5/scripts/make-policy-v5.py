"""Build the v5 policy, the agent-visible tasks and the staleness marks.

Inputs: admitted cases in cases-v5.json (from cases-staging), handoffs/, the
v4 snapshots the handoffs were written against, and stale-marks/ (computed by
stale_marks.py before this script runs). Model-free; run before sealing.
"""

import hashlib
import json
import random
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v5")
V4 = Path("/tmp/codenib-ab-v4")
ARMS = ["plain", "file", "graph"]
REPS = 3
SEED = 20261104
TURNS = 40
TIMEOUT = 600

PREAMBLE = (
    "An earlier agent session diagnosed this bug, and its diagnosis is below. Other "
    "changes have been merged into this checkout since it was written, so parts of it "
    "may be out of date.\n\n"
    "Fix the bug in the current code so that the behavior described above is correct. "
    "Keep the change small and focused on the bug, run whatever checks you find useful, "
    "and do not commit. Finish with a short summary of what you changed and why."
)

STATUS = {
    "unchanged": "unchanged",
    "changed": "changed",
    "moved": "moved with its code unchanged",
    "moved and changed": "moved and changed",
    "gone": "not found in the current code",
    "new": "new",
}


def sha_text(text):
    return hashlib.sha256(text.encode()).hexdigest()


def file_block(marks):
    changed = [f"`{p}`" for p, s in marks["file"].items() if s != "unchanged"]
    same = [f"`{p}`" for p, s in marks["file"].items() if s == "unchanged"]
    lines = [
        "<staleness-check>",
        "An automatic check compared each file the diagnosis cites between the code it "
        "was written against and the current code.",
        "Changed since: " + (", ".join(changed) if changed else "none"),
        "Unchanged: " + (", ".join(same) if same else "none"),
        "</staleness-check>",
    ]
    return "\n".join(lines)


def graph_block(marks):
    graph = marks["graph"]
    lines = [
        "<staleness-check>",
        "An automatic check used a code graph to compare each function the diagnosis "
        "cites between the code it was written against and the current code, together "
        "with the functions within two calls of it. Locations are in the current code.",
    ]
    # List each changed function once, under the cited function it is closest
    # to: a direct call wins over one through another function, then the
    # earlier cited function.
    home = {}
    for index, item in enumerate(graph["definitions"]):
        for rel in item["related"]:
            rank = (rel["through"] is not None, index)
            if rel["name"] not in home or rank < home[rel["name"]][0]:
                home[rel["name"]] = (rank, index, id(rel))
    for index, item in enumerate(graph["definitions"]):
        cited = ", ".join(item["cited"])
        state = STATUS[item["status"]]
        where = f", now at `{item['now']}`" if item["now"] else ""
        lines.append(f"- `{item['name']}` (cited at {cited}): {state}{where}.")
        for rel in item["related"]:
            if home[rel["name"]][1:] != (index, id(rel)):
                continue
            through = f" through `{rel['through']}`" if rel["through"] else ""
            site = f", call at `{rel['call_site']}`" if rel["call_site"] else ""
            lines.append(
                f"  - It {rel['relation']} `{rel['name']}` (`{rel['at']}`{site}){through}, "
                f"which is {STATUS[rel['status']]}."
            )
    if graph["module_level"]:
        lines.append("Cited lines outside any function: " + ", ".join(graph["module_level"]) + ".")
    lines.append("Other functions within two calls of these are unchanged.")
    lines.append("</staleness-check>")
    return "\n".join(lines)


def prompt(report, handoff, arm, marks):
    text = f"{report.strip()}\n\n{PREAMBLE}\n\n<earlier-diagnosis>\n{handoff.strip()}\n</earlier-diagnosis>"
    if arm == "file":
        text += "\n\n" + file_block(marks)
    elif arm == "graph":
        text += "\n\n" + graph_block(marks)
    return text


def main():
    cases = json.loads((ROOT / "cases-v5.json").read_text())
    v4_policy = json.loads((V4 / "ab-policy-v4.json").read_text())
    tasks = []
    for case, info in sorted(cases.items()):
        report = (ROOT / "private-grading" / case / "prompt.txt").read_text()
        handoff = (ROOT / "handoffs" / f"{case}.md").read_text()
        marks = json.loads((ROOT / "stale-marks" / f"{case}.json").read_text())
        for arm in ARMS:
            text = prompt(report, handoff, arm, marks)
            tasks.append({
                "task_id": f"ab5-{case}-{arm}-repair", "instance_id": case, "arm": arm,
                "sequence": 1, "kind": "repair", "timeout_seconds": TIMEOUT,
                "source_commit": info["source_head"], "prompt": text,
                "prompt_sha256": sha_text(text),
            })
    rng = random.Random(SEED)
    order = sorted(cases)
    rng.shuffle(order)
    workflows = []
    for rep in range(1, REPS + 1):
        for case in order:
            arms = ARMS[:]
            rng.shuffle(arms)
            for arm in arms:
                workflows.append({"workflow_index": len(workflows), "instance_id": case,
                                  "arm": arm, "rep": rep})
    agent = dict(v4_policy["agent"])
    agent["max_turns_per_query"] = TURNS
    agent["tool_choice"] = "automatic; native tools only in every arm"
    policy = {
        "schema_version": 5,
        "protocol_type": "stale-handoff repair A/B",
        "status": "built_before_admission",
        "question": "When an agent continues a fix from an earlier diagnosis after the code "
                    "has changed, do per-claim staleness marks (file level or code-graph "
                    "level) lead to more correct fixes than a generic warning alone?",
        "arms": {
            "plain": {"handoff": "diagnosis plus the generic out-of-date warning"},
            "file": {"handoff": "plus a file-level check of every cited file"},
            "graph": {"handoff": "plus a code-graph check of every cited function and "
                                 "changed functions within two calls",
                      "annotator": {"path": "stale_marks.py",
                                    "sha256": hashlib.sha256((ROOT / "stale_marks.py").read_bytes()).hexdigest()}},
        },
        "cases": {case: {"image": info["image"], "install": info["install"],
                         "kind": info["kind"], "source_head": info["source_head"],
                         "target_python": "/opt/testbed/bin/python"}
                  for case, info in cases.items()},
        "agent": agent,
        "execution_order": {"seed": SEED, "workflows": workflows,
                            "concurrency": 3},
        "budget": {"session_cap_usd": 3.0, "stop_at_estimate_usd": 35.0,
                   "planned_estimate_usd": 25.0},
        "grading": {
            "terminal": v4_policy["grading"]["terminal"],
            "acceptance": "a successful terminal, and with the session's whole workspace "
                          "patch applied to the case snapshot (test files the project's "
                          "listed tests use restored first), hidden_test.py exits 0 and "
                          "every listed project test passes, inside the case image "
                          "without network",
        },
    }
    (ROOT / "ab-policy-v5.json").write_text(json.dumps(policy, indent=1) + "\n")
    (ROOT / "ab-tasks-v5.json").write_text(json.dumps({"tasks": tasks}, indent=1) + "\n")
    print(len(tasks), "tasks", len(workflows), "workflows")


if __name__ == "__main__":
    main()
