"""Seal the v5 inputs after model-free admission.

Admission per case: the case's own patches checked by grade-v5.py (unfixed and
stale fail the hidden test, reference passes everything) and one prepare-only
workflow (the case's first in repetition 1). Arms share one environment, so
one target identity per case is recorded. Every input file is then bound by
SHA-256 in execution-binding-ab5.json, which is sealed.
"""

import hashlib
import json
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v5")


def sha(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


policy = json.loads((ROOT / "ab-policy-v5.json").read_text())
order = policy["execution_order"]["workflows"]
targets, admissions, seen = {}, [], set()
for plan in order:
    case = plan["instance_id"]
    if case in seen:
        continue
    seen.add(case)
    folder = ROOT / "admission" / f"{plan['workflow_index']:03d}-{case}-{plan['arm']}-r{plan['rep']}"
    receipt = json.loads((folder / "receipt.json").read_text())
    assert receipt["status"] == "prepared_no_inference", (folder, receipt.get("error"))
    assert receipt["workflow"] == plan
    targets[case] = receipt["target_identity"]
    checks = json.loads((ROOT / "admission" / f"{case}.json").read_text())
    assert checks["admitted"], case
    admissions.append({"workflow": plan, "receipt": str(folder / "receipt.json"),
                       "sha256": sha(folder / "receipt.json"),
                       "patch_checks": str(ROOT / "admission" / f"{case}.json"),
                       "patch_checks_sha256": sha(ROOT / "admission" / f"{case}.json")})
assert seen == set(policy["cases"])

(ROOT / "expected-target-identities.json").write_text(json.dumps(targets, indent=2) + "\n")

inputs = [
    "run-ab-v5.py", "execute-ab-v5.py", "native-scope-ab5.py", "make-policy-v5.py",
    "stale_marks.py", "grade-v5.py", "handoff-selection.json",
    "ab-policy-v5.json", "ab-tasks-v5.json", "cases-v5.json",
    "helpers/benchmark_context_claude.py", "expected-target-identities.json",
]
inputs += sorted(str(p.relative_to(ROOT)) for p in (ROOT / "handoffs").glob("*.md"))
inputs += sorted(str(p.relative_to(ROOT)) for p in (ROOT / "stale-marks").glob("*.json"))
inputs += sorted(
    str(path.relative_to(ROOT))
    for path in (ROOT / "private-grading").rglob("*")
    if path.is_file() and "__pycache__" not in path.parts
)
files = {str(ROOT / name): sha(ROOT / name) for name in inputs}
binding = {
    "status": "admitted_before_inference",
    "policy_sha256": sha(ROOT / "ab-policy-v5.json"),
    "tasks_sha256": sha(ROOT / "ab-tasks-v5.json"),
    "execution_order": order,
    "files": files,
    "sources": {case: policy["cases"][case]["source_head"] for case in policy["cases"]},
    "images": {case: policy["cases"][case]["image"] for case in policy["cases"]},
    "admissions": admissions,
    "model_calls_started": False,
}
(ROOT / "execution-binding-ab5.json").write_text(json.dumps(binding, indent=2) + "\n")
(ROOT / "execution-binding-ab5-freeze.json").write_text(json.dumps(
    {"sha256": sha(ROOT / "execution-binding-ab5.json")}, indent=2) + "\n")
print(len(files), "files bound;", len(admissions), "admissions;",
      "freeze", sha(ROOT / "execution-binding-ab5.json")[:16])
