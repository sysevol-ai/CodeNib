"""Stage authored cases and compute their staleness marks (model-free).

For each case in cases-staging: copy source/ to sources/<case> (Q), copy the
grading material to private-grading/<case>, add it to cases-v5.json, and run
stale_marks.py on copies of P (the v4 snapshot) and Q. Whether the graph check
names the consequential change is recorded for the report; it is not an
admission criterion.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v5")
V4 = Path("/tmp/codenib-ab-v4")
CANDIDATE = Path("/tmp/claude-1001/-home-zhongming-CodeNib/5f1cd921-6685-43cd-ae42-9a375f521d60/scratchpad/wt-cand4")
VENV_PY = Path.home() / ".venvs/codenib/bin/python"
GRADING = ["hidden_test.py", "project_tests.txt", "reference-fix.patch", "stale-fix.patch",
           "change.patch", "prompt.txt", "case.json", "NOTES.md", "validation.log"]


def stage(case):
    staging = ROOT / "cases-staging" / case
    info = json.loads((staging / "case.json").read_text())
    q = ROOT / "sources" / case
    if q.exists():
        shutil.rmtree(q)
    shutil.copytree(staging / "source", q, symlinks=True)
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=q, text=True).strip()
    assert head == info["source_head"], (case, head, info["source_head"])
    assert subprocess.check_output(["git", "rev-list", "--all", "--count"], cwd=q, text=True).strip() == "1"
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=q, text=True).strip()
    grading = ROOT / "private-grading" / case
    grading.mkdir(parents=True, exist_ok=True)
    for name in GRADING:
        shutil.copy(staging / name, grading / name)
    v4 = json.loads((V4 / "cases-v4.json").read_text())[case]
    entry = {"kind": info["kind"], "source_head": head, "image": v4["image"],
             "image_tag": v4["image_tag"], "install": v4["install"],
             "consequential": info["consequential"], "neutral_edit": info["neutral_edit"],
             "changed_files": info["changed_files"], "stale_fix_mode": info["stale_fix_mode"]}
    marks_path = ROOT / "stale-marks" / f"{case}.json"
    marks_path.parent.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=f"marks-{case}-") as tmp:
        p_copy, q_copy = Path(tmp) / "P" / case, Path(tmp) / "Q" / case
        shutil.copytree(V4 / "sources" / case, p_copy, symlinks=True)
        shutil.copytree(q, q_copy, symlinks=True)
        env = dict(os.environ, CODENIB_HOME=str(ROOT / "marks-home"))
        subprocess.run([str(VENV_PY), str(ROOT / "stale_marks.py"), str(p_copy), str(q_copy),
                        str(ROOT / "handoffs" / f"{case}.md"), str(marks_path)],
                       cwd=CANDIDATE, env=env, check=True, capture_output=True)
    marks = json.loads(marks_path.read_text())
    target = info["consequential"]["function"].split()[0].split(".")[-1].split("(")[0]
    named = [d["name"] for d in marks["graph"]["definitions"] if d["status"] != "unchanged"]
    named += [r["name"] for d in marks["graph"]["definitions"] for r in d["related"]]
    entry["graph_names_consequential"] = any(target in n for n in named)
    entry["file_flags"] = marks["file"]
    return entry


def main():
    cases_path = ROOT / "cases-v5.json"
    cases = json.loads(cases_path.read_text()) if cases_path.exists() else {}
    for case in sys.argv[1:]:
        cases[case] = stage(case)
        print(case, cases[case]["kind"], "graph names consequential:",
              cases[case]["graph_names_consequential"], cases[case]["file_flags"])
    cases_path.write_text(json.dumps(cases, indent=1) + "\n")


if __name__ == "__main__":
    main()
