"""Run the sealed v5 workflows in order, three at a time, and keep every outcome."""
import argparse
import datetime
import hashlib
import json
import subprocess
import time
from pathlib import Path

ROOT = Path('/tmp/codenib-ab-v5')
PYTHON = '/tmp/codenib-sdk-probe-20261027/venv/bin/python'
CONCURRENCY = 3
STOP_USD = 35.0
NO_USAGE_USD = 1.0


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def verify(binding_path):
    freeze = json.loads((ROOT / 'execution-binding-ab5-freeze.json').read_text())
    assert sha(binding_path) == freeze['sha256']
    binding = json.loads(binding_path.read_text())
    assert binding['status'] == 'admitted_before_inference'
    for path, expected in binding['files'].items():
        assert sha(path) == expected, path
    return binding


def finish(record, plan, process):
    index = plan['workflow_index']
    receipts = list((ROOT / 'runs').glob('%03d-*/receipt.json' % index))
    assert len(receipts) == 1, 'Missing workflow receipt'
    value = json.loads(receipts[0].read_text())
    assert value['finished_utc'] and all(c['removed'] for c in value['cleanup'])
    assert value['workflow'] == plan
    # Attempt 2: a session without final usage (a timeout) is charged $1, over
    # five times any completed session in attempt 1, not its $3 cap; the cap
    # charge stopped attempt 1's estimate long before its real cost.
    estimate = sum(s.get('sdk_estimate_usd', NO_USAGE_USD) for s in value['sessions'])
    record['sdk_estimate_usd'] += estimate
    record['completed'].append({
        'workflow': plan, 'receipt': str(receipts[0]), 'receipt_sha256': sha(receipts[0]),
        'process_exit': process.returncode, 'status': value['status'],
        'sdk_estimate_usd': estimate,
        'observed_workflow_seconds': value.get('observed_workflow_seconds'),
        'cohort_stop_reason': value.get('cohort_stop_reason'),
        'sessions_without_final_usage': sum(1 for s in value['sessions'] if not s.get('usage_complete'))})
    print('TERMINAL', index, plan['instance_id'], plan['arm'], value['status'],
          value.get('observed_workflow_seconds'), round(estimate, 3),
          value.get('cohort_stop_reason'), flush=True)
    if value.get('cohort_stop_reason'):
        record['stop_reason'] = value['cohort_stop_reason']
    if process.returncode:
        record['stop_reason'] = 'Driver process failed; preserve partial cohort'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    binding_path = ROOT / 'execution-binding-ab5.json'
    binding = verify(binding_path)
    if args.verify_only:
        print('Exact pre-inference binding verified:', len(binding['files']), 'files', flush=True)
        return
    path = ROOT / 'ab-controller-receipt.json'
    assert not path.exists(), 'One planned cohort only; preserve prior receipts'
    assert not (ROOT / 'runs').exists(), 'Do not restart an existing cohort'
    record = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'binding_sha256': sha(binding_path), 'status': 'running', 'concurrency': CONCURRENCY,
              'completed': [], 'sdk_estimate_usd': 0, 'stop_reason': None}
    write(path, record)
    pending = list(binding['execution_order'])
    running = []
    try:
        while pending or running:
            for item in list(running):
                plan, process, stream = item
                if process.poll() is not None:
                    stream.close()
                    running.remove(item)
                    finish(record, plan, process)
                    write(path, record)
            if record['stop_reason']:
                pending = []
            elif record['sdk_estimate_usd'] >= STOP_USD:
                record['stop_reason'] = 'Prospective round estimate stop threshold'
                pending = []
            while pending and len(running) < CONCURRENCY and not record['stop_reason']:
                for file, expected in binding['files'].items():
                    assert sha(file) == expected, file
                plan = pending.pop(0)
                index = plan['workflow_index']
                stream = (ROOT / ('ab-model-%d-controller.log' % index)).open('x')
                process = subprocess.Popen([PYTHON, '-u', str(ROOT / 'run-ab-v5.py'),
                                            '--index', str(index)], stdout=stream,
                                           stderr=subprocess.STDOUT)
                running.append((plan, process, stream))
                time.sleep(5)
            time.sleep(2)
        record['status'] = ('stopped_preserving_partial_cohort' if record['stop_reason']
                            else 'model_execution_terminal_pending_grading')
    except Exception as exc:
        record['status'] = 'controller_error_preserving_partial_cohort'
        record['stop_reason'] = type(exc).__name__ + ': ' + str(exc)
        raise
    finally:
        record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(path, record)


if __name__ == '__main__':
    main()
