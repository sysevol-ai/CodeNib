"""Summarize graded v5 outcomes against the sealed decision rule.

Reads outcomes-v5.json (grade-v5.py --runs), cases-v5.json, the run receipts
and the admission checks; writes results-v5.json and prints the tables.
"""

import json
import re
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v5")
ARMS = ["plain", "file", "graph"]


def hidden_tail(log, lines=10):
    """The last lines the hidden test printed, with temp paths normalized."""
    text = (log or "").split("HIDDEN_EXIT=")[0]
    text = re.sub(r"/tmp/tmp[\w-]+", "/tmp/X", text)
    return [l.rstrip() for l in text.strip().splitlines()][-lines:]


def decide(acc, local, remote, wins, n_remote):
    helps = {a: acc[a] - acc["plain"] >= 5 and wins[a][0] > wins[a][1] for a in ("file", "graph")}
    if acc["plain"] >= 30:
        return "no room for a staleness check", helps
    if not any(helps.values()):
        return "no demonstrated benefit", helps
    graph = (helps["graph"] and acc["graph"] - acc["file"] >= 4 and local["graph"] >= local["file"]
             and (n_remote < 3 or remote["graph"] - remote["file"] >= 3))
    return ("the code graph is needed" if graph else "a file-level check is enough"), helps


def main():
    cases = json.loads((ROOT / "cases-v5.json").read_text())
    rows = json.loads((ROOT / "outcomes-v5.json").read_text())
    assert len(rows) == 99 and len({(r["instance_id"], r["arm"], r["rep"]) for r in rows}) == 99
    stale_tail = {c: hidden_tail(json.loads((ROOT / "admission" / f"{c}.json").read_text())["stale"]["log"])
                  for c in cases}
    unfixed_tail = {c: hidden_tail(json.loads((ROOT / "admission" / f"{c}.json").read_text())["unfixed"]["log"])
                    for c in cases}
    per_case = defaultdict(lambda: defaultdict(int))
    metrics = defaultdict(lambda: defaultdict(list))
    failures = defaultdict(lambda: defaultdict(int))
    for r in rows:
        case, arm = r["instance_id"], r["arm"]
        per_case[case][arm] += r["accepted"]
        folder = next((ROOT / "runs").glob("%03d-*" % r["workflow_index"]))
        session = json.loads((folder / "receipt.json").read_text())["sessions"][0]
        final = session.get("final_result") or {}
        metrics[arm]["seconds"].append(session["seconds"])
        metrics[arm]["turns"].append(final.get("num_turns"))
        metrics[arm]["tokens"].append(session.get("normalized_tokens"))
        metrics[arm]["usd"].append(session.get("sdk_estimate_usd"))
        if r["accepted"]:
            continue
        grade = json.loads((folder / "grade.json").read_text())
        if not r["terminal_ok"]:
            kind = "session did not end normally"
        elif grade.get("hidden_exit") is None:
            kind = "no patch or patch did not apply"
        elif grade["hidden_exit"] == 0:
            kind = "hidden test passed, project tests failed"
        elif hidden_tail(grade.get("log")) == stale_tail[case]:
            kind = "hidden test fails like the literal stale fix"
        elif hidden_tail(grade.get("log")) == unfixed_tail[case]:
            kind = "hidden test fails like the unfixed code"
        else:
            kind = "hidden test fails another way"
        failures[arm][kind] += 1
    acc = {a: sum(per_case[c][a] for c in cases) for a in ARMS}
    by_kind = {k: {a: sum(per_case[c][a] for c in cases if cases[c]["kind"] == k) for a in ARMS}
               for k in ("local", "remote")}
    wins = {a: (sum(per_case[c][a] > per_case[c]["plain"] for c in cases),
                sum(per_case[c][a] < per_case[c]["plain"] for c in cases)) for a in ("file", "graph")}
    n_remote = sum(cases[c]["kind"] == "remote" for c in cases)
    verdict, helps = decide(acc, by_kind["local"], by_kind["remote"], wins, n_remote)
    summary = {
        "accepted": acc, "by_kind": by_kind, "wins_losses_vs_plain": wins, "helps": helps,
        "verdict": verdict,
        "per_case": {c: {"kind": cases[c]["kind"], **{a: per_case[c][a] for a in ARMS}} for c in sorted(cases)},
        "failures": {a: dict(failures[a]) for a in ARMS},
        # Sessions that ended without final usage have no turns or cost; they
        # are left out of those statistics and counted under failures.
        "metrics": {a: {m: {"median": statistics.median(v), "mean": statistics.mean(v), "sum": sum(v),
                            "n": len(v)}
                        for m, v in ((m, [x for x in v if x is not None]) for m, v in metrics[a].items())}
                    for a in ARMS},
        "graph_names_consequential": {c: cases[c]["graph_names_consequential"] for c in sorted(cases)},
    }
    (ROOT / "results-v5.json").write_text(json.dumps(summary, indent=1) + "\n")
    print("accepted /33:", acc, "| by kind:", by_kind)
    print("wins-losses vs plain:", wins, "| helps:", helps, "| verdict:", verdict)
    print("%-13s %-6s %5s %5s %5s" % ("case", "kind", *ARMS))
    for c, v in summary["per_case"].items():
        print("%-13s %-6s %5d %5d %5d" % (c, v["kind"], v["plain"], v["file"], v["graph"]))
    for a in ARMS:
        m = summary["metrics"][a]
        print(a, "median s %.0f turns %.0f tokens %.0f usd %.3f | total usd %.2f" % (
            m["seconds"]["median"], m["turns"]["median"], m["tokens"]["median"], m["usd"]["median"],
            m["usd"]["sum"]), "| failures", dict(failures[a]))


if __name__ == "__main__":
    main()
