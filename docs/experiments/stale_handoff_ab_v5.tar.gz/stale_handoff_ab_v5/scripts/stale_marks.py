"""Staleness marks for a handoff, computed before any model call (v5).

Two deterministic checks over the snapshot a handoff was written against (P)
and the current code (Q):

- ``file``: each file the handoff cites, changed or unchanged.
- ``graph``: each definition the handoff cites, from CodeNib's symbol graph
  (pyrefly provider): unchanged, moved, changed or gone, with its current
  location, plus every changed or new function within two call hops of it
  (callees of callees, callers of callers).

Usage: python stale_marks.py P Q handoff.md out.json
Run with CodeNib importable (the v4 candidate tree) and CODENIB_HOME set.
"""

import json
import re
import subprocess
import sys
from pathlib import Path

DEFS = {"function", "method"}
CITE = re.compile(
    r"(?P<path>[A-Za-z0-9_][A-Za-z0-9_./\-]*\.py)"
    r"(?::(?P<a>\d+)(?:\s*[-–]\s*(?P<b>\d+))?)?"
    r"|(?<![\w/.\-]):(?P<ra>\d+)(?:\s*[-–]\s*(?P<rb>\d+))?"
)


def python_files(root):
    return sorted(
        p.relative_to(root).as_posix()
        for p in root.rglob("*.py")
        if ".git" not in p.parts
    )


def resolve(path, files):
    if path in files:
        return path
    matches = [f for f in files if f.endswith("/" + path)]
    return matches[0] if len(matches) == 1 else None


def citations(text, root):
    """(file, first line, last line or None) in order; bare ``:n`` follows the
    last cited file."""
    files = set(python_files(root))
    out, last = [], None
    for match in CITE.finditer(text):
        if match["path"]:
            path = resolve(match["path"], files)
            if path is None:
                continue
            last = path
            if match["a"]:
                a = int(match["a"])
                out.append((path, a, int(match["b"]) if match["b"] else a))
            else:
                out.append((path, None, None))
        elif last is not None:
            a = int(match["ra"])
            out.append((last, a, int(match["rb"]) if match["rb"] else a))
    return out


def file_marks(cites, p_root, q_root):
    marks = {}
    for path, _a, _b in cites:
        if path in marks:
            continue
        before, after = p_root / path, q_root / path
        if not after.exists():
            marks[path] = "missing"
        else:
            marks[path] = (
                "unchanged" if before.read_bytes() == after.read_bytes() else "changed"
            )
    return marks


def build_graph(root):
    out = subprocess.run(
        [sys.executable, "-m", "codenib", "index", str(root), "--language",
         "python", "--view", "symbol_graph"],
        capture_output=True, text=True, check=True,
    ).stdout
    manifest = re.search(r"^Manifest:\s+(\S+)", out, re.M)[1]
    from codenib.mcp.context import ServerContext

    graph = ServerContext.load(manifest, views=["symbol_graph"]).symbol_graph
    return graph.get_graph()


class Side:
    def __init__(self, root):
        self.root = root
        self.g = build_graph(root)
        self.lines = {}
        self.defs = {}
        for v in self.g.vs:
            if v["type"] in DEFS and v["has_definition"] and v["file"]:
                self.defs[v["name"]] = v
        self.bodies = {name: self.body(v) for name, v in self.defs.items()}
        self.by_body, self.by_tail = {}, {}
        for name, body in self.bodies.items():
            self.by_body.setdefault(body, []).append(name)
            self.by_tail.setdefault(tail(name), []).append(name)

    def text(self, path):
        if path not in self.lines:
            file = self.root / path
            self.lines[path] = file.read_text().splitlines() if file.exists() else []
        return self.lines[path]

    def body(self, v):
        return "\n".join(self.text(v["file"])[v["start_line"]: v["end_line"] + 1])

    def enclosing(self, path, line):
        """Innermost definition containing 1-based ``line``."""
        best = None
        for v in self.defs.values():
            if v["file"] == path and v["start_line"] + 1 <= line <= v["end_line"] + 1:
                if best is None or v["end_line"] - v["start_line"] < best["end_line"] - best["start_line"]:
                    best = v
        return best

    def neighbors(self, v, mode):
        for e in self.g.es.select(**{("_source" if mode == "out" else "_target"): v.index}):
            if e["type"] != "reference":
                continue
            other = self.g.vs[e.target if mode == "out" else e.source]
            if other["name"] in self.defs:
                yield other, e["anchor_file"], e["anchor_line"]


def tail(name):
    return name.split(":", 1)[-1]


def location(v):
    return f"{v['file']}:{v['start_line'] + 1}-{v['end_line'] + 1}"


def graph_marks(cites, p_root, q_root):
    P, Q = Side(p_root), Side(q_root)

    def counterpart(pv):
        """Q definition for a P definition, and how it relates."""
        name = pv["name"]
        if name in Q.defs:
            same = P.bodies[name] == Q.bodies[name]
            return Q.defs[name], ("unchanged" if same else "changed")
        same_body = [n for n in Q.by_body.get(P.bodies[name], []) if n not in P.defs]
        if len(same_body) == 1:
            return Q.defs[same_body[0]], "moved"
        same_tail = [n for n in Q.by_tail.get(tail(name), []) if n not in P.defs]
        if len(same_tail) == 1:
            return Q.defs[same_tail[0]], "moved and changed"
        return None, "gone"

    q_status = {}
    p_by_q = {}
    for pv in P.defs.values():
        qv, status = counterpart(pv)
        if qv is not None:
            q_status[qv["name"]] = status
            p_by_q[qv["name"]] = pv
    for name in Q.defs:
        q_status.setdefault(name, "new")

    cited, order = {}, []
    module_level = []
    for path, a, b in cites:
        if a is None:
            continue
        pv = P.enclosing(path, a)
        if pv is None:
            module_level.append((path, a, b))
            continue
        key = pv["name"]
        if key not in cited:
            cited[key] = {"p": pv, "lines": []}
            order.append(key)
        cited[key]["lines"].append((path, a, b))

    items = []
    cited_q = set()
    for key in order:
        pv = cited[key]["p"]
        qv, status = counterpart(pv)
        item = {
            "name": tail(pv["name"]),
            "cited": [f"{p}:{a}" + (f"-{b}" if b != a else "") for p, a, b in cited[key]["lines"]],
            "status": status,
            "now": location(qv) if qv is not None else None,
            "related": [],
        }
        items.append((item, qv))
        if qv is not None:
            cited_q.add(qv["name"])

    for item, qv in items:
        if qv is None:
            continue
        seen = {qv["name"]}
        for mode, verb in (("out", "calls"), ("in", "is called by")):
            frontier = [(qv, None)]
            for depth in (1, 2):
                nxt = []
                for node, via in frontier:
                    for other, anchor_file, anchor_line in Q.neighbors(node, mode):
                        if other["name"] in seen:
                            continue
                        seen.add(other["name"])
                        nxt.append((other, other))
                        status = q_status[other["name"]]
                        if other["name"] in cited_q or status in ("unchanged", "moved"):
                            continue
                        site = None
                        if mode == "in" and anchor_file is not None:
                            site = f"{anchor_file}:{anchor_line + 1}"
                        item["related"].append({
                            "relation": verb,
                            "name": tail(other["name"]),
                            "status": status,
                            "at": location(other),
                            "call_site": site,
                            "through": tail(via["name"]) if via is not None else None,
                        })
                frontier = nxt
    return {
        "definitions": [item for item, _ in items],
        "module_level": [f"{p}:{a}" for p, a, _b in module_level],
    }


def main():
    p_root, q_root, handoff, output = map(Path, sys.argv[1:5])
    cites = citations(handoff.read_text(), p_root)
    result = {
        "citations": [list(c) for c in cites],
        "file": file_marks(cites, p_root, q_root),
        "graph": graph_marks(cites, p_root, q_root),
    }
    output.write_text(json.dumps(result, indent=1) + "\n")


if __name__ == "__main__":
    main()
