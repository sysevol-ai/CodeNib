"""Grade v5 fixes by running the hidden test and the listed project tests.

Used twice with the same code path:
- admission: ``--admit CASE`` checks the case's own patches (none, reference,
  stale) against Q;
- grading: ``--runs`` grades every workflow's repair patch.
"""

import argparse
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path("/tmp/codenib-ab-v5")


def run(argv, **kw):
    return subprocess.run(argv, capture_output=True, text=True, **kw)


def targets(case):
    lines = (ROOT / "private-grading" / case / "project_tests.txt").read_text().splitlines()
    return [x.strip() for x in lines if x.strip() and not x.startswith("#")]


def check(case, patch=None):
    """Apply ``patch`` (bytes or None) to a fresh copy of Q and run the tests."""
    info = json.loads((ROOT / "cases-v5.json").read_text())[case]
    result = {"patch_bytes": len(patch or b"")}
    with tempfile.TemporaryDirectory(prefix=f"grade5-{case}-") as tmp:
        tree = Path(tmp) / "w"
        shutil.copytree(ROOT / "sources" / case, tree, symlinks=True)
        if patch:
            (Path(tmp) / "fix.patch").write_bytes(patch)
            applied = run(["git", "apply", "--binary", "--whitespace=nowarn",
                           str(Path(tmp) / "fix.patch")], cwd=tree)
            if applied.returncode:
                fallback = run(["patch", "-p1", "-f", "-i", str(Path(tmp) / "fix.patch")], cwd=tree)
                result["apply"] = "patch" if fallback.returncode == 0 else "failed"
                if fallback.returncode:
                    result["apply_error"] = applied.stderr[-2000:] + fallback.stdout[-2000:]
                    result["hidden_exit"] = result["tests_exit"] = None
                    result["accepted_tests"] = False
                    return result
            else:
                result["apply"] = "git"
        # Restore the listed project test files so a fix cannot pass by editing them.
        files = sorted({t.split("::")[0] for t in targets(case)})
        existing = [f for f in files if (ROOT / "sources" / case / f).exists()]
        if existing:
            restore = run(["git", "checkout", info["source_head"], "--", *existing], cwd=tree)
            assert restore.returncode == 0, restore.stderr
        shutil.copy(ROOT / "private-grading" / case / "hidden_test.py", tree / "hidden_test.py")
        script = (
            f"{info['install']} >/tmp/install.log 2>&1 || {{ cat /tmp/install.log; exit 90; }}\n"
            "python hidden_test.py; echo HIDDEN_EXIT=$?\n"
        )
        if targets(case):
            script += ("python -m pytest -q -p no:cacheprovider -x " + " ".join(targets(case))
                       + " 2>&1 | tail -15; echo TESTS_EXIT=${PIPESTATUS[0]}\n")
        else:
            script += "echo TESTS_EXIT=0\n"
        uid = f"{subprocess.check_output(['id', '-u'], text=True).strip()}"
        out = run(["docker", "run", "--rm", "--network", "none", "-v", f"{tree}:/w", "-w", "/w",
                   info["image"], "bash", "-lc", script], timeout=900)
        run(["docker", "run", "--rm", "-v", f"{tree}:/w", info["image"],
             "chown", "-R", f"{uid}:{uid}", "/w"])
        text = out.stdout + out.stderr
        result["log"] = text[-4000:]
        hidden = [l for l in text.splitlines() if l.startswith("HIDDEN_EXIT=")]
        tests = [l for l in text.splitlines() if l.startswith("TESTS_EXIT=")]
        result["hidden_exit"] = int(hidden[-1].split("=")[1]) if hidden else None
        result["tests_exit"] = int(tests[-1].split("=")[1]) if tests else None
        result["accepted_tests"] = result["hidden_exit"] == 0 and result["tests_exit"] == 0
    return result


def admit(case):
    folder = ROOT / "private-grading" / case
    out = {"case": case}
    out["unfixed"] = check(case)
    out["reference"] = check(case, (folder / "reference-fix.patch").read_bytes())
    out["stale"] = check(case, (folder / "stale-fix.patch").read_bytes())
    out["admitted"] = (out["unfixed"]["hidden_exit"] == 1 and out["reference"]["accepted_tests"]
                       and out["stale"]["hidden_exit"] == 1)
    (ROOT / "admission").mkdir(exist_ok=True)
    (ROOT / "admission" / f"{case}.json").write_text(json.dumps(out, indent=1) + "\n")
    print(case, "admitted" if out["admitted"] else "NOT ADMITTED",
          {k: (v["hidden_exit"], v["tests_exit"]) for k, v in out.items() if isinstance(v, dict)})


def grade_runs():
    policy = json.loads((ROOT / "ab-policy-v5.json").read_text())
    terminal = policy["grading"]["terminal"]
    rows = []
    for folder in sorted((ROOT / "runs").iterdir()):
        receipt = json.loads((folder / "receipt.json").read_text())
        plan = receipt["workflow"]
        phase = receipt["phases"][0] if receipt["phases"] else {}
        result = phase.get("result") or {}
        ok_terminal = bool(result) and all(result.get(k) == terminal[k] for k in
                                           ("subtype", "is_error", "terminal_reason",
                                            "stop_reason", "api_error_status"))
        patch_path = folder / "repair.patch"
        patch = patch_path.read_bytes() if patch_path.exists() else None
        graded = check(plan["instance_id"], patch) if patch else {"hidden_exit": None,
                                                                   "tests_exit": None,
                                                                   "accepted_tests": False}
        row = {**plan, "terminal_ok": ok_terminal, **{k: v for k, v in graded.items() if k != "log"},
               "accepted": ok_terminal and graded["accepted_tests"]}
        (folder / "grade.json").write_text(json.dumps({**row, "log": graded.get("log")}, indent=1) + "\n")
        rows.append(row)
        print(folder.name, row["terminal_ok"], row.get("hidden_exit"), row.get("tests_exit"),
              "ACCEPT" if row["accepted"] else "reject", flush=True)
    (ROOT / "outcomes-v5.json").write_text(json.dumps(rows, indent=1) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--admit")
    parser.add_argument("--runs", action="store_true")
    args = parser.parse_args()
    if args.admit:
        admit(args.admit)
    if args.runs:
        grade_runs()


if __name__ == "__main__":
    main()
