"""Scope this pilot's native SDK tools to one checkout and one container.

Native read/search/edit remain the client's native implementations. Bash and
MCP run in the same owned, credential-free container without a Docker socket. Network remains available for provider installation.
No shared home or other arm is mounted. This is a single-experiment boundary.
"""
import hashlib
import os
import shlex
import subprocess
from pathlib import Path

NATIVE_TOOLS = ['Read', 'Grep', 'Glob', 'Edit', 'Write', 'Bash', 'ToolSearch']

def scoped_hooks(workspace, container_id, emit, mcp_prefix='mcp__study__'):
    workspace = Path(workspace).resolve()
    artifacts = {}

    def target_path(raw):
        path = Path(str(raw)).expanduser()
        return (path if path.is_absolute() else workspace / path).resolve()

    def inside(raw):
        return target_path(raw).is_relative_to(workspace)

    def outside_symlink():
        for path in workspace.rglob('*'):
            if path.is_symlink() and not path.resolve().is_relative_to(workspace):
                return str(path.relative_to(workspace))
        return None

    async def before(data, tool_id, context):
        name, original = data['tool_name'], data['tool_input']
        result = {'hookEventName':'PreToolUse'}
        event = {'event':'pre', 'tool':name, 'tool_use_id':tool_id, 'original_input':original, 'effective_effort':data.get('effort'), 'session_id':data.get('session_id')}
        allowed = False
        reason = 'Tool is outside the frozen pilot inventory.'
        updated = dict(original)
        if name == 'Bash':
            # shlex.join quotes the entire nested command as one argument. Shell
            # expansion happens only inside this exact owned container ID.
            updated['command'] = shlex.join(['docker','exec','-i','-w',str(workspace),container_id,'/bin/bash','-lc','umask 002\n'+original['command']])
            allowed = True
        elif name in {'Read','Edit','Write'}:
            supplied = original.get('file_path','')
            path = target_path(supplied)
            allowed = bool(supplied) and path.is_relative_to(workspace)
            if name == 'Read' and path in artifacts:
                allowed = path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == artifacts[path]['sha256']
            if allowed: updated['file_path'] = str(path)
            reason = 'Native file access is limited to this checkout and registered SDK output files.'
        elif name in {'Grep','Glob'}:
            supplied = original.get('path') or str(workspace)
            pattern = original.get('pattern','') if name == 'Glob' else original.get('glob','')
            # Patterns cannot traverse parents; literal search roots are resolved
            # before the native tool runs. Outbound links are rejected as well.
            path = target_path(supplied)
            own_artifact = name == 'Grep' and path in artifacts and path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == artifacts[path]['sha256']
            allowed = (inside(supplied) or own_artifact) and '..' not in pattern and not Path(pattern).is_absolute()
            link = outside_symlink() if allowed and not own_artifact else None
            if link:
                allowed = False
                event['outbound_symlink'] = link
            if allowed: updated['path'] = str(target_path(supplied))
            reason = 'Native search is limited to this checkout without parent traversal or outbound symlinks.'
        elif name == 'ToolSearch' or name.startswith(mcp_prefix):
            allowed = True
        result['permissionDecision'] = 'allow' if allowed else 'deny'
        event['decision'] = result['permissionDecision']
        if allowed:
            result['updatedInput'] = updated
            event['effective_input'] = updated
        else:
            result['permissionDecisionReason'] = reason
        emit(event)
        return {'hookSpecificOutput':result}

    async def after(data, tool_id, context):
        response = data.get('tool_response')
        emit({'event':'post','tool':data['tool_name'],'tool_use_id':tool_id,'tool_input':data['tool_input'],'response':response,'response_keys':list(response) if isinstance(response,dict) else None,'session_id':data.get('session_id'),'transcript_path':data.get('transcript_path'),'duration_ms':data.get('duration_ms')})
        # This field is native Bash response metadata, not parsed shell text.
        # The observed client puts results in <transcript session>/tool-results.
        # The container cannot write there; native Edit/Write cannot write there.
        if data['tool_name'] == 'Bash' and isinstance(response, dict):
            supplied = response.get('persistedOutputPath')
            transcript = data.get('transcript_path')
            session_id = data.get('session_id')
            if supplied and transcript and session_id:
                path = Path(supplied).resolve()
                transcript = Path(transcript).resolve()
                root = transcript.parent / session_id / 'tool-results'
                expected_transcript = transcript.name == session_id + '.jsonl'
                valid = (
                    expected_transcript and path.parent == root.resolve()
                    and path.is_file() and not Path(supplied).is_symlink()
                    and path.stat().st_uid == os.geteuid()
                    and path.stat().st_size == response.get('persistedOutputSize')
                )
                if valid:
                    artifacts[path] = {
                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'bytes': path.stat().st_size, 'tool_use_id': tool_id,
                        'session_id': session_id,
                    }
                    # Preserve ordinary native Bash access to its own SDK
                    # output path. Copy only this verified result, never a home
                    # directory or another session's files, into the same owned
                    # container. The host original remains immutable here.
                    if not path.is_relative_to(workspace):
                        subprocess.run(['docker','exec',container_id,'mkdir','-p',str(path.parent)],check=True,capture_output=True,timeout=10)
                        subprocess.run(['docker','cp',str(path),container_id+':'+str(path)],check=True,capture_output=True,timeout=20)
                        subprocess.run(['docker','exec',container_id,'chmod','0444',str(path)],check=True,capture_output=True,timeout=10)
                        command=['docker','exec',container_id,'python3','-c','import hashlib,sys; print(hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest())',str(path)]
                        copied=subprocess.check_output(command,text=True,timeout=10).strip()
                        if copied != artifacts[path]['sha256']:
                            del artifacts[path]
                            raise RuntimeError('Owned SDK output copy differs from captured bytes')
                        artifacts[path]['container_copy_sha256'] = copied
                    emit({'event':'sdk_output_registered','path':str(path),**artifacts[path]})
                else:
                    emit({'event':'sdk_output_registration_rejected','path':str(path),'tool_use_id':tool_id})
        return {}

    return before, after
