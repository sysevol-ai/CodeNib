"""Execute the frozen stale-handoff A/B (v5): three handoff arms, one repair session.

Docker creation is the ownership boundary. Keep every returned container ID in
the workflow receipt, inspect its unique owner label before removal, and remove
only those IDs in finally. Containers own recovery of background MCP daemons.
No retained lock, shared home, Docker socket or cross-arm source is mounted.
"""
import argparse
import ast
import asyncio
import dataclasses
import datetime
import hashlib
import importlib.metadata
import io
import json
import math
import os
import shlex
import shutil
import stat
import subprocess
import tarfile
import time
import traceback
import uuid
from pathlib import Path

import docker
from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient, HookMatcher
from mcp import Client, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path("/tmp/codenib-ab-v5")
HELPERS = ROOT / "helpers/benchmark_context_claude.py"
CLI = Path("/home/zhongming/.local/bin/claude")
POLICY = ROOT / "ab-policy-v5.json"
TASKS = ROOT / "ab-tasks-v5.json"
SCOPE = ROOT / "native-scope-ab5.py"
BINDING = ROOT / "execution-binding-ab5.json"
STATE_DIRS = {".git", ".codegraph", ".serena", "__pycache__", ".pytest_cache",
              ".mypy_cache", ".venv", "node_modules", "build", "dist"}
API_ENV = ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_BASE_URL",
           "CLAUDE_CODE_OAUTH_TOKEN", "CLAUDE_CODE_USE_BEDROCK",
           "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, default=str) + "\n")


def error(exc):
    return {"type": type(exc).__name__, "message": str(exc),
            "traceback": traceback.format_exc()}


def source_snapshot(work, output):
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=work).decode().split("\0")
    files = {x for x in tracked if x}
    for folder, dirs, names in os.walk(work, followlinks=False):
        dirs[:] = [d for d in dirs if d not in STATE_DIRS and not d.endswith(".egg-info")]
        for name in names:
            path = Path(folder) / name
            files.add(str(path.relative_to(work)))
    versions = {}
    for relative in sorted(files):
        path = work / relative
        if path.is_symlink():
            versions[relative] = {"symlink": os.readlink(path)}
        elif path.is_file():
            try:
                versions[relative] = {"sha256": sha(path), "bytes": path.stat().st_size}
            except PermissionError:
                # v2: a tool run inside the container can leave root-only
                # files (e.g. .hypothesis); record them instead of crashing.
                versions[relative] = {"unreadable": True}
        else:
            versions[relative] = None
    value = {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=work, text=True).strip(),
             "files": versions}
    digest = hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()
    write(output, value)
    return {"path": str(output), "sha256": sha(output), "source_digest": digest,
            "file_count": len(versions), "head": value["head"]}


def helpers():
    path = HELPERS
    tree = ast.parse(path.read_text())
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef)
             and n.name in {"subscription_auth", "included_max_rate"}]
    assert len(nodes) == 2
    ns = {"os": os, "subprocess": subprocess, "json": json}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), "exec"), ns)
    return ns


def context_text(case, policy):
    text = ("Use only this checkout and its available tools. The common target project "
            "and test dependencies are prepared. The shell and optional MCP server "
            "run in this workflow's own credential-free container. Use foreground "
            "commands and repository-relative source citations. Runtime versions are "
            "fixed; work on repository source. Network access is available for tool-provider installation; do not fetch external repository code, answers or grading material.")
    hint = policy["cases"][case].get("context_hint")
    if hint:
        text += " " + hint
    return text


class Workflow:
    def __init__(self, index, prepare_only):
        self.policy = json.loads(POLICY.read_text())
        self.tasks = json.loads(TASKS.read_text())
        self.plan = self.policy["execution_order"]["workflows"][index]
        self.index, self.arm, self.case = index, self.plan["arm"], self.plan["instance_id"]
        self.rep = self.plan["rep"]
        self.owner = uuid.uuid4().hex[:12]
        base = ROOT / ("admission" if prepare_only else "runs")
        base.mkdir(exist_ok=True)
        self.folder = base / f"{index:03d}-{self.case}-{self.arm}-r{self.rep}"
        self.folder.mkdir(exist_ok=False)
        self.work = self.folder / "workspace"
        self.engine = docker.from_env(timeout=120)
        self.ids = []
        self.current = None
        self.prepare_only = prepare_only
        self.record = {"workflow": self.plan, "owner": self.owner, "created_utc": utc(),
                       "prepare_only": prepare_only, "commands": [], "phases": [],
                       "sessions": [], "api_invoice_cost_usd": None,
                       "http_request_count": None, "owned_containers": [],
                       "cohort_stop_reason": None,
                       "driver_sha256": sha(__file__), "scope_sha256": sha(SCOPE),
                       "policy_sha256": sha(POLICY), "tasks_sha256": sha(TASKS)}
        self.scope_ns = {}
        exec(compile(SCOPE.read_text(), str(SCOPE), "exec"), self.scope_ns)
        self.auth_helpers = helpers()
        self.tasks_for_case = sorted(
            # v5: the handoff text differs by arm, so tasks are per case and arm.
            [x for x in self.tasks["tasks"]
             if x["instance_id"] == self.case and x["arm"] == self.arm],
            key=lambda t: t["sequence"])
        self.clock_start = None

    def save(self):
        write(self.folder / "receipt.json", self.record)

    def emit(self, event):
        event["phase"] = getattr(self, "phase_kind", None)
        if event.get("event") == "pre" and event.get("effective_effort") is not None:
            effort = event["effective_effort"]
            level = effort.get("level") if isinstance(effort, dict) else effort
            self.record.setdefault("observed_effort_levels", []).append(level)
            if level != "medium":
                self.record["cohort_stop_reason"] = "Observed main-assistant effort differs from medium"
        with (self.folder / "hooks.jsonl").open("a") as stream:
            stream.write(json.dumps(event, default=str) + "\n")

    def command(self, label, argv, timeout=600, required=True):
        start = time.monotonic()
        args = ["docker", "exec", "-w", str(self.work), self.current, *argv]
        try:
            result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
            output = result.stdout + result.stderr
            code = result.returncode
        except subprocess.TimeoutExpired as exc:
            output = str(exc.stdout or "") + str(exc.stderr or "")
            code = 124
        path = self.folder / (label + ".log")
        path.write_text(output)
        entry = {"label": label, "argv": args, "returncode": code,
                 "seconds": time.monotonic() - start,
                 "log": path.name, "log_sha256": sha(path)}
        self.record["commands"].append(entry)
        self.save()
        print(self.index, self.arm, label, code, flush=True)
        if required and code:
            raise RuntimeError(label + " failed; see " + str(path))
        return code, output

    def create(self, image, network, env=None):
        attrs = self.engine.images.get(image).attrs
        environment = dict(env or {})
        if network == "none":
            environment["UV_OFFLINE"] = "1"
        # v5 attempt 2: 256 pids hung black's suite under `-n auto` (20 xdist
        # workers, each with a process pool), so attempt 1's black sessions timed out.
        container = self.engine.containers.create(
            image, ["3600"], entrypoint="/bin/sleep",
            name=f"codenib-matched-{self.owner}-{len(self.ids)}",
            labels={"codenib.pilot.owner": self.owner}, environment=environment,
            network_mode=network, network_disabled=(network == "none"),
            mem_limit=4 * 1024**3, nano_cpus=2_000_000_000, pids_limit=4096,
            volumes={str(self.work): {"bind": str(self.work), "mode": "rw"}},
            tmpfs={p: "rw,noexec,nosuid,size=1m"
                   for p in attrs["Config"].get("Volumes", {}) if p != str(self.work)},
            working_dir=str(self.work), platform="linux/arm64/v8")
        self.ids.append(container.id)
        self.record["owned_containers"].append(container.id)
        self.current = container.id
        self.save()
        container.start()
        return container

    def clean_container(self, identity):
        try:
            container = self.engine.containers.get(identity)
        except docker.errors.NotFound:
            return True
        assert container.attrs["Config"]["Labels"]["codenib.pilot.owner"] == self.owner
        container.remove(force=True, v=True)
        try:
            self.engine.containers.get(identity)
            return False
        except docker.errors.NotFound:
            return True

    def base_image(self):
        return self.policy["cases"][self.case]["image"]

    def common_prepare(self):
        source = ROOT / "sources" / self.case
        shutil.copytree(source, self.work, symlinks=True)
        expected = self.tasks_for_case[0]["source_commit"]
        assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=self.work,
                                       text=True).strip() == expected
        assert subprocess.check_output(["git", "rev-list", "--all", "--count"],
                                       cwd=self.work, text=True).strip() == "1"
        for folder, dirs, names in os.walk(self.work):
            os.chmod(folder, os.stat(folder).st_mode | stat.S_ISGID)
        env = {"UV_TOOL_DIR": "/opt/pilot-tools/uv",
               "UV_TOOL_BIN_DIR": "/opt/pilot-tools/bin",
               "UV_CACHE_DIR": "/opt/pilot-state/uv-cache",
               "UV_PYTHON_INSTALL_DIR": "/opt/pilot-runtimes/managed-python",
               "PATH": "/opt/testbed/bin:/opt/pilot-tools/bin:/opt/pilot-runtimes/node/bin:/usr/local/bin:/opt/miniconda3/bin:/usr/sbin:/usr/bin:/sbin:/bin",
               "SERENA_HOME": "/opt/pilot-tools/serena-state",
               "CODENIB_HOME": "/opt/pilot-state/.codenib",
               "CODENIB_TOOLCHAIN_DIR": "/opt/pilot-tools/.codenib/toolchains",
               "CODENIB_SCIP_TOOLS_DIR": "/opt/pilot-tools/.codenib/toolchains",
               "CODEGRAPH_INSTALL_DIR": "/opt/pilot-tools/codegraph-runtime",
               "CODEGRAPH_TELEMETRY": "0", "DO_NOT_TRACK": "1"}
        base = self.base_image()
        attrs = self.engine.images.get(base).attrs
        assert attrs["Os"] == "linux" and attrs["Architecture"] == "arm64"
        self.record["neutral_image"] = base
        self.create(base, "bridge", env)
        self.command("common-directories", ["mkdir", "-p", "/opt/pilot-tools/bin",
                                           "/opt/pilot-inputs", "/opt/pilot-state"])
        self.command("common-git", ["git", "config", "--global", "--add",
                                   "safe.directory", str(self.work)])
        self.command("common-project", ["/bin/bash", "-lc", self.policy["cases"][self.case]["install"]])
        self.command("common-workspace-owner", ["chown", "-R", f"{os.getuid()}:{os.getgid()}", str(self.work)])
        self.record["common_source"] = source_snapshot(self.work, self.folder / "common-source.json")
        self.save()

    def upload(self, source, destination, name):
        payload = io.BytesIO()
        with tarfile.open(fileobj=payload, mode="w") as archive:
            archive.add(source, arcname=name)
        assert self.engine.containers.get(self.current).put_archive(destination, payload.getvalue())

    def install_product(self):
        # v5: every arm uses native tools only; arms differ in the handoff text.
        self.clock_start = time.monotonic()
        self.record["clock_started_utc"] = utc()
        self.record["setup"] = {"started_utc": utc(), "ready": True, "seconds": 0.0}
        self.save()

    def isolate(self):
        container = self.engine.containers.get(self.current)
        image = container.commit(repository="codenib/matched-prepared-arm64",
                                 tag=self.owner)
        old = self.current
        assert self.clean_container(old)
        self.create(image.id, "bridge")
        current = self.engine.containers.get(self.current).attrs
        config, host = current["Config"], current["HostConfig"]
        assert not config.get("NetworkDisabled") and host["NetworkMode"] == "bridge"
        assert host["Memory"] == 4*1024**3 and host["NanoCpus"] == 2_000_000_000 and host["PidsLimit"] == 4096
        binds = [m for m in current["Mounts"] if m["Type"] == "bind"]
        assert len(binds) == 1 and binds[0]["Source"] == str(self.work)
        self.record["prepared_image"] = image.id
        self.record["observed_container"] = {
            "id": self.current, "network_disabled": bool(config.get("NetworkDisabled")),
            "network_mode": host["NetworkMode"], "memory_bytes": host["Memory"],
            "nano_cpus": host["NanoCpus"], "pids_limit": host["PidsLimit"],
            "mounts": current["Mounts"]}
        self.record["pre_model_source"] = source_snapshot(self.work, self.folder / "pre-model-source.json")
        self.save()

    def verify_runtime_identity(self):
        code = 'import importlib.metadata as m,json,sys;print(json.dumps({"python":sys.version,"packages":sorted({(d.metadata["Name"],d.version) for d in m.distributions()})}))'
        target = json.loads(self.command("verify-target-identity", ["/opt/testbed/bin/python", "-c", code], 60)[1])
        self.record["target_identity"] = target
        # Admission records identities; only a sealed run compares them.
        wanted_targets = {} if self.prepare_only else json.loads((ROOT / "expected-target-identities.json").read_text())
        if not self.prepare_only and target != wanted_targets[self.case]:
            self.record["cohort_stop_reason"] = "Target project/runtime identity differs from frozen admission"
            self.save()
            raise RuntimeError(self.record["cohort_stop_reason"])
        return
        expected = None if self.prepare_only else json.loads((ROOT / "expected-product-identities.json").read_text())[self.arm]
        if self.arm == "codegraph":
            code = 'const fs=require("fs"),path=require("path"),crypto=require("crypto");let base="/opt/pilot-tools/npm/lib/node_modules/@colbymchenry/codegraph",files={};function walk(p){for(const e of fs.readdirSync(p,{withFileTypes:true})){let q=path.join(p,e.name);if(e.isDirectory())walk(q);else if(e.isFile())files[q]=crypto.createHash("sha256").update(fs.readFileSync(q)).digest("hex")}}walk(base);console.log(JSON.stringify({node:process.version,package:require(base+"/package.json").version,package_files:files}))'
            args = ["node", "-e", code]
        else:
            py = "/opt/pilot-tools/uv/serena-agent/bin/python" if self.arm == "serena" else "/opt/pilot-tools/codenib/bin/python"
            code = 'import os;os.chdir("/opt");import importlib.metadata as m,json,sys;from pathlib import Path;result={"python":sys.version,"packages":dict(sorted((d.metadata["Name"],d.version) for d in m.distributions()))};'
            if self.arm == "codenib":
                code += 'from codenib import _workspace_owner as o;result["workspace_owner_protocol"]=o._protocol_version;result["providers"]={n:(json.loads((Path("/opt/pilot-tools/.codenib/toolchains/node-tools/node_modules")/n/"package.json").read_text())["version"] if (Path("/opt/pilot-tools/.codenib/toolchains/node-tools/node_modules")/n/"package.json").exists() else None) for n in ("@sourcegraph/scip-python","basedpyright")};'
            code += 'print(json.dumps(result))'
            args = [py, "-c", code]
        actual = json.loads(self.command("verify-product-identity", args, 60)[1])
        self.record["product_identity_matches_admission"] = None if self.prepare_only else actual == expected
        self.save()
        if not self.prepare_only and actual != expected:
            self.record["cohort_stop_reason"] = "Selected product/provider identity differs from frozen admission"
            self.save()
            raise RuntimeError(self.record["cohort_stop_reason"])

    def servers(self):
        return {}
        argv = [x.replace("{workspace}", str(self.work))
                for x in self.policy["arms"][self.arm]["mcp"]]
        return {"study": {"command": "docker",
                         "args": ["exec", "-i", "-w", str(self.work), self.current,
                                  "/bin/bash", "-lc", "umask 002\nexec " + shlex.join(argv)]}}

    def snapshot(self, label):
        return source_snapshot(self.work, self.folder / (label + "-source.json"))

    def patch(self, label):
        # v4: naming an ignored path, even to exclude it, makes `git add` fail
        # (v3 lost two reviews this way); exclude only unignored state dirs.
        excludes = []
        for name in (".codegraph", ".serena", ".codegraph-wsl", ".hypothesis"):
            ignored = subprocess.run(["git", "check-ignore", "-q", name],
                                     cwd=self.work).returncode == 0
            if (self.work / name).exists() and not ignored:
                excludes.append(":(exclude)" + name)
        result = subprocess.run(["git", "add", "-A", "--", ".", *excludes],
                                cwd=self.work, capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        patch = subprocess.check_output(["git", "diff", "--cached", "--binary", self.tasks_for_case[0]["source_commit"]],
                                        cwd=self.work)
        path = self.folder / (label + ".patch")
        path.write_bytes(patch)
        return {"path": path.name, "sha256": sha(path), "bytes": len(patch),
                "attribution": "whole workspace diff; includes any separately recorded setup metadata"}

    def normalized(self, result):
        counters = result.get("model_usage")
        if not isinstance(counters, dict):
            raise RuntimeError("Missing final cumulative model usage")
        total = 0
        for value in counters.values():
            for key in ("inputTokens", "cacheCreationInputTokens",
                        "cacheReadInputTokens", "outputTokens"):
                amount = value.get(key)
                if type(amount) is not int or amount < 0:
                    raise RuntimeError("Invalid cumulative usage counter")
                total += amount
        fee = result.get("total_cost_usd")
        if type(fee) not in (int, float) or not math.isfinite(fee) or fee < 0:
            raise RuntimeError("Missing final SDK estimate")
        return total, fee

    def successful_terminal(self, result):
        expected = self.policy["grading"]["terminal"]
        return all(result.get(k) == expected[k] for k in
                   ("subtype", "is_error", "terminal_reason", "stop_reason", "api_error_status")) and (
                       result.get("origin") is None or result["origin"].get("kind") == "human")

    def remaining(self, limit):
        left = 3000 - (time.monotonic() - self.clock_start)
        if left <= 0:
            raise TimeoutError("Whole workflow deadline reached")
        return min(limit, left)

    async def session(self, name, tasks, cap):
        entry = {"name": name, "started_utc": utc(), "budget_requested_usd": cap,
                 "rate_events": [], "results": [], "init": None}
        self.record["sessions"].append(entry)
        self.save()
        before, after = self.scope_ns["scoped_hooks"](self.work, self.current, self.emit)
        options = ClaudeAgentOptions(
            cwd=str(self.work), cli_path=str(CLI),
            tools=self.scope_ns["NATIVE_TOOLS"],
            allowed_tools=self.scope_ns["NATIVE_TOOLS"],
            setting_sources=[], skills=[], plugins=[], strict_mcp_config=True,
            mcp_servers=self.servers(), model="claude-opus-5-5",
            effort="medium", thinking={"type": "adaptive", "display": "omitted"},
            max_turns=self.policy["agent"]["max_turns_per_query"], max_budget_usd=cap,
            env={"CLAUDE_CODE_MAX_OUTPUT_TOKENS": "16384", "ENABLE_TOOL_SEARCH": "false", "MCP_CONNECTION_NONBLOCKING": "0", "MCP_TIMEOUT": "120000"},
            hooks={"PreToolUse": [HookMatcher(hooks=[before])],
                   "PostToolUse": [HookMatcher(hooks=[after])]},
            system_prompt={"type": "preset", "preset": "claude_code",
                           "append": context_text(self.case, self.policy)},
            include_partial_messages=True, max_buffer_size=16*1024*1024)
        client = ClaudeSDKClient(options=options)
        started = time.monotonic()
        try:
            await asyncio.wait_for(client.connect(), timeout=self.remaining(120))
            entry["connect_seconds"] = time.monotonic() - started
            for task in tasks:
                if task["kind"] == "post_edit":
                    edit = self.tasks["controlled_edits"][self.case]
                    target = self.work / edit["path"]
                    assert not target.exists()
                    assert hashlib.sha256(edit["source"].encode()).hexdigest() == edit["sha256"]
                    target.write_text(edit["source"])
                    self.record["controlled_edit"] = {**edit, "applied_utc": utc()}
                self.phase_kind = task["kind"]
                phase = {"task_id": task["task_id"], "kind": task["kind"],
                         "started_utc": utc(), "prompt_sha256": hashlib.sha256(task["prompt"].encode()).hexdigest(),
                         "source_before": self.snapshot(task["kind"] + "-before"),
                         "stream_output_tokens": 0, "session": name}
                entry["latest_query_result_complete"] = False
                self.record["phases"].append(phase)
                self.save()
                phase_start = time.monotonic()
                trace = self.folder / (task["kind"] + "-sdk.jsonl")
                async def consume():
                    await client.query(task["prompt"])
                    async for message in client.receive_response():
                        kind = type(message).__name__
                        payload = None
                        if kind == "SystemMessage" and message.subtype == "init":
                            entry["init"] = {k: message.data.get(k) for k in
                                             ("model", "apiKeySource", "tools", "mcp_servers", "claude_code_version")}
                            assert entry["init"]["model"] == "claude-opus-5-5"
                            assert entry["init"]["apiKeySource"] == "none"
                            assert set(self.policy["agent"]["required_available_native_tools"]) <= set(entry["init"]["tools"])
                            payload = {"type": kind, "subtype": "init", "data": entry["init"]}
                        elif kind == "RateLimitEvent":
                            data = dataclasses.asdict(message)
                            try:
                                self.auth_helpers["included_max_rate"](data)
                            except Exception:
                                self.record["cohort_stop_reason"] = "included-only billing/rate check failed"
                                raise
                            entry["rate_events"].append(data)
                            payload = {"type": kind, "data": data}
                        elif kind == "StreamEvent":
                            event = message.event
                            if event.get("type") in ("message_start", "message_delta"):
                                if event["type"] == "message_delta":
                                    count = event.get("usage", {}).get("output_tokens", 0)
                                    if count > 16384:
                                        self.record["cohort_stop_reason"] = "Observed output response exceeds requested cap"
                                        raise RuntimeError(self.record["cohort_stop_reason"])
                                    phase["stream_output_tokens"] += count
                                payload = {"type": kind, "event": event}
                        elif kind == "AssistantMessage":
                            payload = {"type": kind, "model": message.model,
                                       "message_id": getattr(message, "message_id", None),
                                       "usage": getattr(message, "usage", None),
                                       "content": [dataclasses.asdict(b) for b in message.content
                                                   if type(b).__name__ in {"TextBlock", "ToolUseBlock"}]}
                        elif kind == "UserMessage" and not isinstance(message.content, str):
                            payload = {"type": kind, "content": [dataclasses.asdict(b) for b in message.content
                                                               if type(b).__name__ == "ToolResultBlock"]}
                        elif kind == "ResultMessage":
                            result = dataclasses.asdict(message)
                            phase["result"] = result
                            entry["latest_query_result_complete"] = True
                            entry["results"].append(result)
                            payload = {"type": kind, "data": result}
                            self.save()
                        if payload is not None:
                            with trace.open("a") as stream:
                                stream.write(json.dumps(payload, default=str) + "\n")
                try:
                    await asyncio.wait_for(consume(), timeout=self.remaining(task["timeout_seconds"]))
                    assert entry["init"] is not None, "Missing effective SDK initialization"
                    assert "result" in phase
                    if not self.successful_terminal(phase["result"]):
                        if phase["result"].get("api_error_status") in (401, 403, 429):
                            self.record["cohort_stop_reason"] = "SDK authentication/quota status"
                        raise RuntimeError("Unsuccessful SDK terminal: " + phase["result"]["subtype"])
                    if self.record.get("cohort_stop_reason"):
                        raise RuntimeError(self.record["cohort_stop_reason"])
                    phase["status"] = "sdk_completed_pending_acceptance"
                except Exception as exc:
                    phase["status"] = "error"
                    phase["error"] = error(exc)
                    data = getattr(exc, "data", {})
                    if isinstance(data, dict) and data.get("api_error_status") in (401, 403, 429):
                        self.record["cohort_stop_reason"] = "SDK authentication/quota status"
                    raise
                finally:
                    phase["seconds"] = time.monotonic() - phase_start
                    # v2: hand files the agent's commands created back to the
                    # host owner so the snapshot and patch can read them.
                    self.command("workspace-owner-after-" + task["kind"],
                                 ["chown", "-R", "1001:1001", str(self.work)], 120, required=False)
                    phase["source_after"] = self.snapshot(task["kind"] + "-after")
                    phase["read_only_source_preserved"] = (
                        phase["source_before"]["source_digest"] == phase["source_after"]["source_digest"])
                    if task["kind"] == "repair":
                        phase["submission"] = self.patch("repair")
                    if trace.exists():
                        phase["trace"] = {"path": trace.name, "sha256": sha(trace)}
                    self.save()
                print("PHASE", self.index, self.arm, task["kind"], phase["status"],
                      round(phase["seconds"], 2), flush=True)
            if not entry["rate_events"]:
                self.record["cohort_stop_reason"] = "No included-only session rate receipt"
                raise RuntimeError("No included-only session rate receipt")
        finally:
            try:
                await asyncio.wait_for(client.disconnect(), timeout=30)
                entry["closed"] = True
            except Exception as exc:
                entry["close_error"] = error(exc)
            entry["seconds"] = time.monotonic() - started
            usage_complete = entry.get("latest_query_result_complete", False)
            entry["usage_complete"] = usage_complete
            if not usage_complete:
                # A timed-out query has no final usage. Keep the workflow
                # going and let the controller charge the session cap.
                entry["usage_incomplete"] = "Missing final usage for the latest SDK query"
            if entry["results"]:
                entry["final_result"] = entry["results"][-1]
                try:
                    entry["normalized_tokens"], entry["sdk_estimate_usd"] = self.normalized(entry["final_result"])
                except Exception:
                    self.record["cohort_stop_reason"] = "Invalid final SDK usage counters"
                    self.save()
                    raise
            self.save()

    async def execute(self):
        common_start = time.monotonic()
        try:
            for key in API_ENV:
                os.environ.pop(key, None)
            auth = self.auth_helpers["subscription_auth"](str(CLI))
            self.record["auth"] = {k:v for k,v in auth.items() if k in {"loggedIn","authMethod","apiKeySource","subscriptionType"}}
            self.record["sdk"] = importlib.metadata.version("claude-agent-sdk")
            assert self.record["sdk"] == "0.2.174"
            self.common_prepare()
            self.record["common_prepare_seconds"] = time.monotonic() - common_start
            self.install_product()
            self.verify_runtime_identity()
            self.isolate()
            self.record["setup_patch"] = self.patch("pre-model")
            subprocess.run(["git", "reset", "-q", "HEAD"], cwd=self.work, check=True)
            if self.prepare_only:
                # Real own-CLI and shared-filesystem probe; no SDK/task prompt.
                code = "from pathlib import Path; Path('ownership-probe.py').write_text('value = 1\\n')"
                self.command("ownership-probe", ["/bin/bash", "-lc", "umask 002\n" +
                             shlex.join(["python", "-c", code])])
                target = self.work / "ownership-probe.py"
                target.write_text("value = 2\n")
                target.unlink()
                self.record["shared_native_edit_verified"] = True
                self.record["status"] = "prepared_no_inference"
                return
            # v5: the workflow is one cold repair session.
            await self.session("cold", self.tasks_for_case[:1], 3.0)
            self.record["status"] = "model_execution_complete_pending_grading"
        except Exception as exc:
            self.record["status"] = "error"
            self.record["error"] = error(exc)
            if self.clock_start is None:
                self.record["cohort_stop_reason"] = "Common environment/controller preparation failed"
        finally:
            if self.clock_start is not None:
                self.record["observed_workflow_seconds"] = time.monotonic() - self.clock_start
            if self.arm == "codenib" and self.current is not None:
                try:
                    self.record["final_graph_preparation"] = self.graph_preparation_status()
                except Exception as exc:
                    self.record["final_graph_audit_error"] = error(exc)
            attempted = {x["task_id"] for x in self.record["phases"]}
            self.record["unattempted_tasks"] = [
                t["task_id"] for t in self.tasks_for_case if t["task_id"] not in attempted]
            self.record["cleanup"] = [{"id": identity, "removed": self.clean_container(identity)}
                                      for identity in reversed(self.ids)]
            self.record["finished_utc"] = utc()
            self.save()
            self.engine.close()
            print("WORKFLOW", self.index, self.arm, self.record["status"],
                  self.record.get("cohort_stop_reason"), flush=True)

    def command_manifest_path(self):
        code = "from codenib.paths import repo_index_dir;print(repo_index_dir(" + repr(str(self.work)) + ") / 'repo_manifest.json')"
        return self.command("manifest-path", ["/opt/pilot-tools/codenib/bin/python", "-c", code], 60)[1].strip()

    def graph_preparation_status(self):
        code = "import hashlib,json;from pathlib import Path;from codenib.paths import repo_index_dir;from codenib.toolchains import resolve_command;root=repo_index_dir("+repr(str(self.work))+");m=json.loads((root/'repo_manifest.json').read_text());result={'views':{k:v['status'] for k,v in m['indexes'].items()},'providers':{n:resolve_command(n) for n in ('scip-python','basedpyright-langserver')}};print(json.dumps(result))"
        code = code.replace("print(json.dumps(result))", "") + "\n"
        code += "result['provider_artifacts'] = {}\n"
        code += "for name,path in result['providers'].items():\n"
        code += " if path is None: continue\n"
        code += " launcher=Path(path).resolve(); package=launcher.parent; digest=hashlib.sha256(); count=0\n"
        code += " for file in sorted(package.rglob('*')):\n"
        code += "  if file.is_file() and '__pycache__' not in file.parts:\n"
        code += "   digest.update(file.relative_to(package).as_posix().encode()+b'\\0'); digest.update(hashlib.sha256(file.read_bytes()).hexdigest().encode()); count+=1\n"
        code += " result['provider_artifacts'][name]={'launcher':str(launcher),'launcher_sha256':hashlib.sha256(launcher.read_bytes()).hexdigest(),'package_root':str(package),'tree_sha256':digest.hexdigest(),'files':count}\n"
        code += "print(json.dumps(result))"
        return json.loads(self.command("final-graph-status", ["/opt/pilot-tools/codenib/bin/python", "-c", code], 60)[1])

    def export_index_artifacts(self):
        manifest = Path(self.command_manifest_path())
        container = self.engine.containers.get(self.current)
        assert container.attrs["Config"]["Labels"]["codenib.pilot.owner"] == self.owner
        stream, _stat = container.get_archive(str(manifest.parent))
        path = self.folder / "index-artifacts.tar"
        with path.open("xb") as output:
            for chunk in stream:
                output.write(chunk)
        self.record["index_artifacts"] = {"path":str(path),"sha256":sha(path),"bytes":path.stat().st_size,"manifest":str(manifest)}
        self.save()

    async def preflight_lookup(self):
        """Model-free admission: each tool must deliver the probe definition."""
        probe = self.policy["cases"][self.case]["probe"]
        file, symbol = probe["file"], probe["name_path"]
        start, end = probe["start_line"], probe["end_line"]
        expected = (self.work / file).read_text().splitlines()[start - 1:end]
        if self.arm == "native":
            self.record["source_lookup_probe"] = {"mode": "native", "file": file,
                "sha256": sha(self.work / file), "source": "\n".join(expected)}
            return
        assert self.record["setup"]["ready"], "Optional tool setup failed before readiness query"
        server = self.servers()["study"]
        leaf = symbol.split("/")[-1]
        with (self.folder / "preflight-mcp.stderr").open("w") as errors:
            transport = stdio_client(StdioServerParameters(command=server["command"], args=server["args"], cwd=self.work), errlog=errors)
            async with Client(transport, mode="auto", cache=None) as client:
                listed = await client.list_tools()
                self.record["advertised_tools"] = [t.model_dump(mode="json", by_alias=True) for t in (listed.tools if hasattr(listed, "tools") else listed)]
                if self.arm == "serena":
                    name, args = "find_symbol", {"name_path_pattern": symbol, "relative_path": file, "include_body": True}
                elif self.arm == "codegraph":
                    name, args = "codegraph_explore", {"query": leaf + " " + file}
                else:
                    manifest = json.loads(self.command("initial-manifest", ["cat", self.command_manifest_path()], 60)[1])
                    # v2: init builds the graph during setup.
                    assert {"bm25", "symbol_graph"} <= set(manifest["indexes"])
                    assert manifest["indexes"]["symbol_graph"]["status"] == "fresh", manifest["indexes"]["symbol_graph"]["status"]
                    light = (await client.call_tool("explore_context", arguments={"query": leaf, "include_dependencies": False})).model_dump(mode="json")
                    assert not light["is_error"]
                    assert light.get("structured_content") is None, "explore must return text only"
                    self.record["preflight_light_reply"] = light
                    name, args = "explore_context", {"query": leaf, "symbols": [leaf], "include_dependencies": True}
                reply = (await client.call_tool(name, arguments=args)).model_dump(mode="json")
                self.record["source_lookup_probe"] = {"name": name, "arguments": args, "reply": reply, "file_sha256": sha(self.work / file)}
                self.save()
                assert not reply["is_error"]
                text = "".join(b.get("text", "") for b in reply["content"])
                if self.arm == "codenib":
                    text += "".join(b.get("text", "") for b in light["content"])
                if self.arm == "serena":
                    try:
                        rows = json.loads(text)
                        text = "\n".join(str(row.get("body", "")) for row in rows) if isinstance(rows, list) else text
                    except ValueError:
                        pass
                delivered = {__import__("re").sub(r"^\s*\d+\t", "", line).strip() for line in text.splitlines()}
                missing = [line for line in expected if line.strip() and line.strip() not in delivered]
                self.record["source_lookup_probe"]["missing_lines"] = missing
                self.save()
                assert not missing, f"{name} did not deliver the probe definition: {missing[:3]}"
                if self.arm == "codenib":
                    groups = __import__("re").search(r"(\d+) relationship groups", text)
                    assert groups and int(groups[1]) > 0, "first graph query delivered no relationships"
                    assert "graph_preparing" not in text, "graph was not ready at the first query"
                    # v4: chains are recorded, not required, so admission cannot
                    # select cases by whether CodeNib finds their path.
                    chains = __import__("re").search(r"(\d+) call chains", text)
                    self.record["preflight_call_chains"] = int(chains[1]) if chains else 0
                    self.record["preflight_graph_preparation"] = self.graph_preparation_status()
                    self.export_index_artifacts()


def verify_binding():
    value = json.loads(BINDING.read_text())
    assert value["status"] == "admitted_before_inference"
    for filename, expected in value["files"].items():
        assert sha(filename) == expected, filename
    freeze = json.loads((ROOT / "execution-binding-ab5-freeze.json").read_text())
    assert sha(BINDING) == freeze["sha256"]
    return value


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=int, required=True)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    assert 0 <= args.index < len(json.loads(POLICY.read_text())["execution_order"]["workflows"])
    if not args.prepare_only:
        verify_binding()
        # v5: the controller starts workflows in order, three at a time.
    runner = Workflow(args.index, args.prepare_only)
    await asyncio.wait_for(runner.execute(), timeout=3600)


if __name__ == "__main__":
    asyncio.run(main())
