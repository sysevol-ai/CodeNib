"""Apply PROTOCOL-ctor.md's decision rule to the v1 and constructor-edge results."""

import json
import statistics
from pathlib import Path

from summarize import pct

G = Path(__file__).resolve().parent
DEPTHS = ["1", "2", "3", "4", "None"]
RUNS = {"v1": G / "guardian-results.json", "call sites": G / "ctor" / "results-call.json",
        "any reference": G / "ctor" / "results-any.json"}


def hit(r, k):
    return any(d is not None and (k == "None" or d <= int(k)) for d in r["broken_depth"])


def measures(rows, k):
    cases = [r for r in rows if r["kind"] == "regression"]
    controls = [r for r in rows if r["kind"] == "clean"]
    size = [r["flag_size"][k] for r in controls]
    return {
        "cases_hit": sum(hit(r, k) for r in cases),
        "case_recall": sum(hit(r, k) for r in cases) / len(cases),
        "test_recall": (sum(sum(d is not None and (k == "None" or d <= int(k)) for d in r["broken_depth"])
                            for r in cases) / sum(r["broken"] for r in cases)),
        "control_cost_median": statistics.median(size),
        "control_cost_p90": pct(size, 0.9),
        "control_share_median": statistics.median(r["flag_size"][k] / r["repo_tests"] for r in controls),
        "case_cost_median": statistics.median(r["flag_size"][k] for r in cases),
    }


def main():
    runs = {name: json.loads(path.read_text()) for name, path in RUNS.items()}
    keys = [[(r["tool"], r["instance_id"], r["kind"]) for r in rows] for rows in runs.values()]
    assert all(k == keys[0] for k in keys), "runs cover different patches"
    assert sum(k[2] == "regression" for k in keys[0]) == 68
    out = {"methods": {name: {k: measures(rows, k) for k in DEPTHS} for name, rows in runs.items()}}
    old, new = out["methods"]["v1"]["3"], out["methods"]["call sites"]["3"]
    gain = new["cases_hit"] - old["cases_hit"]
    cost_ok = (new["control_share_median"] <= 0.01
               and new["control_cost_p90"] <= 1.5 * old["control_cost_p90"])
    if gain >= 2 and cost_ok:
        outcome = "add constructor edges to the graph"
    elif gain >= 2:
        outcome = "constructor edges are too noisy"
    else:
        outcome = "no material gain"
    best = max(m["case_recall"] for run in out["methods"].values() for m in run.values())
    out.update({"gain_k3": gain, "cost_ok": cost_ok, "outcome": outcome,
                "static_reaches_70": best >= 0.70})
    for name in ("call sites", "any reference"):
        for k in ("3", "None"):
            pairs = list(zip(runs["v1"], runs[name]))
            out[f"newly caught, {name}, k={k}"] = [
                f"{a['tool']} {a['instance_id']}" for a, b in pairs
                if a["kind"] == "regression" and hit(b, k) and not hit(a, k)]
            out[f"lost, {name}, k={k}"] = [
                f"{a['tool']} {a['instance_id']}" for a, b in pairs
                if a["kind"] == "regression" and hit(a, k) and not hit(b, k)]
    (G / "ctor" / "summary-ctor.json").write_text(json.dumps(out, indent=1) + "\n")
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
