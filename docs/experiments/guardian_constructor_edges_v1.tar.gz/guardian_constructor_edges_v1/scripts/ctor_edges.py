"""Guardian check with constructor edges (see PROTOCOL-ctor.md).

A call ``C(...)`` runs C's ``__init__`` and ``__new__``, but the symbol graph
links the call to the class only. This adds a reference edge from each
definition that calls C, by name or through a module-level alias, to the
constructor methods C resolves to, its own or inherited. Then it runs the
unchanged check in guardian.py.

Usage: python ctor_edges.py ITEMS OUT [--any-reference]
"""

import ast
import json
import sys
from collections import defaultdict

import guardian
from guardian import DEFS, Graph, short

CTORS = ("__init__", "__new__")
OWNERS = DEFS | {"class"}
ANY_REFERENCE = "--any-reference" in sys.argv
STATS = {}


def last_name(expr):
    if isinstance(expr, ast.Name):
        return expr.id
    if isinstance(expr, ast.Attribute):
        return expr.attr
    return None


class SourceFile:
    """Import aliases, class statements and call sites of one file."""

    def __init__(self, graph, path):
        self.aliases, self.classes, self.assigns = {}, [], {}
        self.calls = defaultdict(set)
        try:
            tree = ast.parse((graph.root / path).read_bytes())
        except (SyntaxError, ValueError, OSError):
            return
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    if alias.asname:
                        self.aliases[alias.asname] = alias.name
            elif isinstance(node, ast.ClassDef):
                self.classes.append(node)
        for node in tree.body:
            if (isinstance(node, ast.Assign) and len(node.targets) == 1
                    and isinstance(node.targets[0], ast.Name) and last_name(node.value)):
                self.assigns[node.lineno] = (node.targets[0].id, self.real(last_name(node.value)))
        # A def's own lines, minus its decorators and defaults, belong to it.
        defs = defaultdict(list)
        for i in graph.by_file.get(path, []):
            if graph.nodes[i][1] in OWNERS:
                defs[short(graph.nodes[i][0])].append(i)

        def owner_of(node):
            hits = [i for i in defs.get(node.name, [])
                    if graph.nodes[i][3] + 1 <= node.lineno <= graph.nodes[i][4] + 1]
            return min(hits, key=lambda i: graph.nodes[i][4] - graph.nodes[i][3]) if hits else None

        def visit(node, owner):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                if isinstance(node, ast.ClassDef):
                    outer = node.decorator_list
                    inner_nodes = node.bases + node.keywords + node.body
                else:
                    outer = (node.decorator_list + node.args.defaults
                             + [d for d in node.args.kw_defaults if d])
                    inner_nodes = node.body
                for child in outer:
                    visit(child, owner)
                inner = owner_of(node)
                inner = owner if inner is None else inner
                for child in inner_nodes:
                    visit(child, inner)
                return
            if isinstance(node, ast.Call) and last_name(node.func):
                self.calls[owner].add(self.real(last_name(node.func)))
            for child in ast.iter_child_nodes(node):
                visit(child, owner)

        visit(tree, path)

    def real(self, name):
        return self.aliases.get(name, name)


class CtorGraph(Graph):
    def __init__(self, iid):
        super().__init__(iid)
        self.refs = defaultdict(set)
        for target, sources in self.callers.items():
            for source in sources:
                self.refs[source].add(target)
        self.files = {}
        self.memo = {}
        self.add_constructor_edges(iid)

    def source(self, path):
        if path not in self.files:
            self.files[path] = SourceFile(self, path)
        return self.files[path]

    def classes_named(self, referrers, name):
        return [t for r in referrers if r is not None for t in self.refs[r]
                if self.nodes[t][1] == "class" and short(self.nodes[t][0]) == name]

    def bases(self, cls):
        name, _, path, start, end, _ = self.nodes[cls]
        statements = [c for c in self.source(path).classes
                      if c.name == short(name) and start + 1 <= c.lineno <= end + 1]
        if not statements:
            return []
        out = []
        for base in min(statements, key=lambda c: c.lineno).bases:
            base_name = self.source(path).real(last_name(base) or "")
            found = (self.classes_named([cls], base_name)
                     or self.classes_named([self.by_name.get(path)], base_name))
            out.extend(b for b in found if b != cls and b not in out)
        return out

    def constructors(self, cls, stack=()):
        """{"__init__": node, "__new__": node} that ``cls(...)`` runs."""
        if cls in self.memo:
            return self.memo[cls]
        if cls in stack:
            return {}
        found = {short(self.nodes[c][0]): c for c in self.children[cls]
                 if self.nodes[c][1] == "method" and short(self.nodes[c][0]) in CTORS}
        for base in self.bases(cls):
            if all(m in found for m in CTORS):
                break
            for method, node in self.constructors(base, stack + (cls,)).items():
                found.setdefault(method, node)
        self.memo[cls] = found
        return found

    def aliases(self):
        """{class: [field]} for module-level ``V = C`` or ``V = mod.C``."""
        out = defaultdict(list)
        for i, (name, kind, path, start, _, has_def) in enumerate(self.nodes):
            if kind != "field" or not has_def or path is None or "." in name.split(":", 1)[-1]:
                continue
            assign = self.source(path).assigns.get(start + 1)
            if assign and assign[0] == short(name):
                for cls in self.classes_named([self.by_name.get(path)], assign[1]):
                    out[cls].append(i)
        return out

    def calls(self, referrer, name):
        rname, kind, path = self.nodes[referrer][:3]
        if kind == "file":
            return name in self.source(rname).calls[rname]
        if kind not in OWNERS or path is None:
            return False
        return name in self.source(path).calls[referrer]

    def add_constructor_edges(self, iid):
        aliases = self.aliases()
        added, classes = set(), 0
        for cls, (name, kind, path, *_rest, has_def) in enumerate(self.nodes):
            if kind != "class" or not has_def:
                continue
            methods = self.constructors(cls)
            if not methods:
                continue
            classes += 1
            for target in [cls] + aliases.get(cls, []):
                target_name = short(self.nodes[target][0])
                for referrer in list(self.callers[target]):
                    if ANY_REFERENCE or self.calls(referrer, target_name):
                        for method in methods.values():
                            if method != referrer and referrer not in self.callers[method]:
                                added.add((referrer, method))
        for referrer, method in added:
            self.callers[method].add(referrer)
        STATS[iid] = {"classes_with_constructor": classes,
                      "aliases": sum(map(len, aliases.values())), "edges_added": len(added)}
        print(iid, STATS[iid], flush=True)


def main():
    guardian.Graph = CtorGraph
    sys.argv = [a for a in sys.argv if a != "--any-reference"]
    guardian.main()
    with open(sys.argv[2] + ".edges.json", "w") as f:
        json.dump(STATS, f, indent=1)


if __name__ == "__main__":
    main()
