# Guardian check with constructor edges: protocol

Written 2026-11-04, after the v1 check (`PROTOCOL.md`) and before any flag set
with constructor edges was computed for a case or a control.

## Question

v1 found that CodeNib's symbol graph links a call `C(...)` to the class C, not
to the `__init__` or `__new__` that the call runs. A change inside a
constructor is therefore unreachable from the tests that construct the class.
If the graph had constructor edges, how many more of the 68 regressions would
the guardian have caught, and at what cost on the 35 controls?

## What changes

Only the graph. Before the unchanged v1 check runs, edges are added to each
instance's stored symbol graph:

- **Constructor methods.** For each class C defined in the repository, `__init__`
  and `__new__` are resolved separately: C's own method, otherwise the first one
  found in its base classes, searched depth first from left to right. Base names
  come from the `class` statement and are matched to classes that C, or else C's
  file, references under the same name. Classes outside the repository, such as
  `object` or `Exception`, have no constructor node, so they end the search.
- **Call sites.** A definition R calls C when R references C in the graph and
  the code R owns contains a call whose callee name is C's name, after
  resolving `from … import … as …` aliases in R's file. R owns a line when R is
  the innermost function, method or class around it, or the file when none is.
  Decorators and default values belong to the enclosing definition.
- **Aliases.** A module-level `V = C` or `V = mod.C`, where V's file references
  C, makes V an alias of C. A call to V by name, from a definition that
  references V, counts as a call to C.
- **Edges.** Each such R gets a reference edge to C's resolved `__init__` and to
  its resolved `__new__`, unless the edge already exists.

Not covered: `cls(...)`, `type(self)(...)` and other calls through variables;
dataclass and metaclass constructors; operators such as `==` and indexing.

**Sensitivity variant, "any reference".** The same edges, added from every R
that references C or an alias of C, without the call check. It bounds what
constructor edges could do and is not used in the decision.

## Unchanged from v1

The 68 cases, the 35 controls, the broken tests, the changed-code mapping, the
depths, the import baseline and the measures. The v1 scripts run as they are;
the new edges are added when each graph is loaded.

## Decision rule

At k = 3, comparing the call-site variant with v1's graph (32 of 68 cases
caught; on controls, a median of 3 flagged tests and a 90th percentile of 365):

| Outcome | Condition |
|---|---|
| Add constructor edges to the graph. | At least 2 more cases caught, a median control cost of at most 1% of the repository's test functions, and a 90th-percentile control cost of at most 1.5 times v1's. |
| Constructor edges are too noisy. | At least 2 more cases caught, but a cost condition fails. |
| No material gain. | Fewer than 2 more cases caught. |

Separately, v1's question is asked again. If no variant at any depth reaches
70% case recall, static impact still misses these regressions, and recall
still needs a coverage map.

## Disclosures

- The change was chosen after v1. v1's misses included five that go through
  constructors and operators; this round addresses constructors only.
- The resolution rules were checked on django__django-10097, the v1 plumbing
  instance, which is not a case. No case or control was run with the new edges
  before this protocol and the scripts were hashed.
