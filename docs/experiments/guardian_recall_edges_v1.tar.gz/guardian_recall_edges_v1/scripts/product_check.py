"""Run the product guard (codenib.guard.impact) on the 103 regression-check patches.

Seeds and line mapping are the guard's own; broken tests are matched with the
archived matcher, as in the earlier reproduce.py. Prints caught cases and the
median and 90th percentile of tests listed on clean patches, within 3 calls.
"""

import json
import pickle
import statistics
import sys
import warnings
from pathlib import Path

warnings.simplefilter("ignore")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import guardian2  # noqa: E402
from codenib.guard.impact import ImpactGraph, symbol_id  # noqa: E402

v1 = guardian2.v1
items = sorted(json.loads((guardian2.ARCHIVE / "items.json").read_text()),
               key=lambda i: (i["instance_id"], i["tool"]))
rows, current = [], None
for item in items:
    iid = item["instance_id"]
    if iid != current:
        with open(HERE / "graphs" / f"{iid}.pkl", "rb") as f:
            graph = pickle.load(f)
        ig = ImpactGraph(graph, guardian2.OLD / "wt" / iid)
        compact = guardian2.Graph(iid, [])
        current = iid
    lines, _ = v1.changed_lines(item["patch"])
    impact = ig.impact(lines, depth=3)
    order = [t.symbol for t in impact.tests]  # the order the guard shows
    flagged = set(order)
    broken = [v1.test_node(compact, t)[0] for t in item["broken"]]
    wanted = {symbol_id(ig.ids[b]) for b in broken if b is not None}  # same vertex indices
    hit = bool(wanted & flagged)
    position = next((i + 1 for i, s in enumerate(order) if s in wanted), None)
    rows.append({"tool": item["tool"], "iid": iid, "kind": item["kind"], "hit": hit, "position": position,
                 "size": len(impact.tests), "total": impact.total_tests})
    print(iid, item["tool"], item["kind"], hit, len(impact.tests), flush=True)
out = sys.argv[1] if len(sys.argv) > 1 else str(HERE / "product.json")
Path(out).write_text(json.dumps(rows, indent=1))
cases = [r for r in rows if r["kind"] != "clean"]
ctrl = sorted(r["size"] for r in rows if r["kind"] == "clean")
p90 = ctrl[min(len(ctrl) - 1, int(round(0.9 * (len(ctrl) - 1))))]
print(json.dumps({"caught": sum(r["hit"] for r in cases), "of": len(cases),
                  "first10": sum(1 for r in cases if r["position"] and r["position"] <= 10),
                  "first20": sum(1 for r in cases if r["position"] and r["position"] <= 20),
                  "median": statistics.median(ctrl), "p90": p90}))
