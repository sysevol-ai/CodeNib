"""Recall within the N nearest tests under a few fixed tie-breakers.

For each patch: walk callers from the changed code without a depth limit (up
to MAX_DEPTH), then order the reached tests by each ranker. Ties are broken
at random; a case contributes the probability that a broken test is among the
first N. Rankers were fixed before running:

  depth        call distance only (the guard today)
  depth+imp    distance, then "the test file imports a changed module"
  depth+path   distance, then path similarity of test file and changed file
  path+depth   path similarity first, then distance

Usage: python rank.py --layers ref,ctor,alias,override --out rank-X.json
"""

import argparse
import json
import re
import sys
from collections import defaultdict, deque
from math import comb
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import guardian2  # noqa: E402

v1 = guardian2.v1
MAX_DEPTH = 8
BUDGETS = [5, 10, 20, 50, 100]
GENERIC = {"tests", "test", "testing", "py", "lib", "src", "init", "core", "utils", ""}


def tokens(path, package):
    parts = re.split(r"[/_.]+", path.lower())
    return {p for p in parts if p not in GENERIC and p != package}


def similarity(test_file, changed, package):
    t = tokens(test_file, package)
    best = 0.0
    for c in changed:
        ct = tokens(c, package)
        if t and ct:
            best = max(best, len(t & ct) / len(t | ct))
    return round(best, 3)


def p_top(keys, broken, n):
    """P(some broken vertex is among the first n) with random tie-breaking."""
    groups = defaultdict(list)
    for v, k in keys.items():
        groups[k].append(v)
    ahead = 0
    for k in sorted(groups):
        members = groups[k]
        m = sum(1 for v in members if v in broken)
        if m:
            if n <= ahead:
                return 0.0
            s = min(n - ahead, len(members))
            return 1.0 - comb(len(members) - m, s) / comb(len(members), s)
        ahead += len(members)
        if ahead >= n:
            return 0.0
    return 0.0


def reach(graph, seeds):
    depth = {s: 0 for s in seeds}
    queue = deque(seeds)
    while queue:
        node = queue.popleft()
        if depth[node] >= MAX_DEPTH:
            continue
        for caller in graph.callers[node]:
            if caller not in depth:
                depth[caller] = depth[node] + 1
                queue.append(caller)
    return depth


def run(layers, out):
    items = json.loads((guardian2.ARCHIVE / "items.json").read_text())
    items.sort(key=lambda i: (i["instance_id"], i["tool"]))
    graph, caches, rows = None, defaultdict(dict), []
    for item in items:
        iid = item["instance_id"]
        if graph is None or graph.iid != iid:
            graph = guardian2.Graph(iid, layers)
            graph.iid = iid
        package = iid.split("__")[1].split("-")[0].replace("scikit", "sklearn")
        lines, _ = v1.changed_lines(item["patch"])
        seeds = set()
        for path, numbers in lines.items():
            for line in numbers:
                seeds |= graph.seeds(path, line)[0]
        depth = reach(graph, seeds)
        reached = [t for t in graph.tests if t in depth]
        imports = v1.import_baseline(graph, lines, caches[iid])
        sim = {t: similarity(graph.nodes[t][2], list(lines), package) for t in reached}
        broken = {i for i, _ in (v1.test_node(graph, t) for t in item["broken"]) if i is not None}
        rankers = {
            "depth": {t: (depth[t],) for t in reached},
            "depth+imp": {t: (depth[t], t not in imports) for t in reached},
            "depth+path": {t: (depth[t], -sim[t]) for t in reached},
            "path+depth": {t: (-sim[t], depth[t]) for t in reached},
        }
        row = {k: item[k] for k in ("tool", "instance_id", "kind")}
        row["reached"] = len(reached)
        row["p"] = {name: [p_top(keys, broken, n) for n in BUDGETS]
                    for name, keys in rankers.items()}
        rows.append(row)
    Path(out).write_text(json.dumps(rows) + "\n")
    cases = [r for r in rows if r["kind"] != "clean"]
    print("layers", ",".join(layers))
    print("ranker".ljust(12), *[f"N={n}".rjust(7) for n in BUDGETS])
    for name in rankers:
        vals = [sum(r["p"][name][i] for r in cases) for i in range(len(BUDGETS))]
        print(name.ljust(12), *[f"{v:7.1f}" for v in vals])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", default="ref,ctor,alias,override")
    ap.add_argument("--out", default=str(HERE / "rank.json"))
    a = ap.parse_args()
    run([x for x in a.layers.split(",") if x], a.out)
