"""List regressions not caught within k=3, with seeds and broken tests."""

import json
import sys

rows = json.load(open(sys.argv[1]))
k = int(sys.argv[2]) if len(sys.argv) > 2 else 3
n = 0
for r in rows:
    if r["kind"] == "clean":
        continue
    depths = [d for d in r["broken_depth"] if d is not None]
    if any(d <= k for d in depths):
        continue
    n += 1
    print(f"### {r['instance_id']} {r['tool']}  seeds={r['n_seeds']} units={r['units']} "
          f"min_depth={min(depths) if depths else None}")
    for s in r["seeds"][:6]:
        print("   seed:", s)
    for t, m, d in list(zip(r["broken_ids"], r["broken_match"], r["broken_depth"]))[:4]:
        print(f"   broken[{m}, d={d}]: {t}")
print("misses", n)
