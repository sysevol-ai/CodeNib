"""Regression check on current graphs, with the guard's edge layers switchable.

Patch-to-line mapping, seeds, test identification, test matching and the
import baseline are the archived guardian's (guardian_regression_check_v1).
The caller relation is built like ``codenib.guard.impact.ImpactGraph``:
graph references, then constructor, alias and override layers, plus any new
layer named in --layers.

Usage: python guardian2.py --layers ref,ctor,alias,override[,new...] --out out.json
"""

import argparse
import json
import pickle
import sys
from collections import defaultdict, deque
from pathlib import Path

HERE = Path(__file__).resolve().parent
ARCHIVE = HERE / "guardian_regression_check_v1"
OLD = Path(
    "/tmp/claude-1001/-home-zhongming-CodeNib/"
    "5f1cd921-6685-43cd-ae42-9a375f521d60/scratchpad/guardian"
)
sys.path.insert(0, str(ARCHIVE / "scripts"))
import guardian as v1  # noqa: E402

DEPTHS = [1, 2, 3, 4, None]
AVAILABLE = False


def extra_layers():
    """name -> function(graph, root) -> iterable of (caller, callee)."""
    layers = {}
    try:
        import new_edges  # noqa: F401

        layers.update(new_edges.LAYERS)
    except ImportError:
        pass
    return layers


class Graph(v1.Graph):
    def __init__(self, iid, layers):  # noqa: D401 - replaces the v1 loader
        with open(HERE / "graphs" / f"{iid}.pkl", "rb") as f:
            g = pickle.load(f)
        self.g = g
        self.root = OLD / "wt" / iid
        vs = g.vs
        self.nodes = [
            [n, t, fl, s, e, bool(d)]
            for n, t, fl, s, e, d in zip(
                vs["name"], vs["type"], vs["file"], vs["start_line"],
                vs["end_line"], vs["has_definition"],
            )
        ]
        self.tests = {
            i for i, n in enumerate(self.nodes)
            if n[1] in v1.DEFS and n[5] and n[2] and v1.is_test_file(n[2])
            and v1.short(n[0]).startswith("test")
        }
        self.callers = defaultdict(set)
        self.children = defaultdict(set)
        self.layer_edges = defaultdict(int)
        for (s, t), kind in zip(g.get_edgelist(), g.es["type"]):
            if kind == "reference" and "ref" in layers:
                self.callers[t].add(s)
                self.layer_edges["ref"] += 1
            elif kind == "contain":
                self.children[s].add(t)
        if "ctor" in layers:
            from codenib.graph.constructor_edges import constructor_edges

            for e in constructor_edges(g, self.root):
                self.callers[e.constructor].add(e.caller)
                self.layer_edges["ctor"] += 1
        if "alias" in layers:
            from codenib.graph.alias_edges import alias_edges

            for a in alias_edges(g, self.root):
                self.callers[a.target].add(a.user)
                self.layer_edges["alias"] += 1
        extras = extra_layers()
        # New layers that add plain caller edges go before overrides, so an
        # override inherits callers found through them too.
        for name in layers:
            if name in extras and not name.startswith("post_"):
                for caller, callee in extras[name](g, self.root, self):
                    if caller != callee:
                        self.callers[callee].add(caller)
                        self.layer_edges[name] += 1
        if "override" in layers:
            from codenib.graph.override_edges import override_pairs

            pairs = override_pairs(g, self.root)
            declared = {o: set(self.callers.get(o, ())) for _, o in pairs}
            for override, overridden in pairs:
                for caller in declared[overridden]:
                    if caller != override:
                        self.callers[override].add(caller)
                        self.layer_edges["override"] += 1
        for name in layers:
            if name in extras and name.startswith("post_"):
                for caller, callee in extras[name](g, self.root, self):
                    if caller != callee:
                        self.callers[callee].add(caller)
                        self.layer_edges[name] += 1
        self.by_file = defaultdict(list)
        self.by_name = {}
        for i, (name, kind, file, start, end, has_def) in enumerate(self.nodes):
            self.by_name.setdefault(name, i)
            if has_def and file is not None and start is not None:
                self.by_file[file].append(i)


def run(layers, out_path):
    items = json.loads((ARCHIVE / "items.json").read_text())
    items.sort(key=lambda item: (item["instance_id"], item["tool"]))
    if AVAILABLE:
        items = [i for i in items if (HERE / "graphs" / f"{i['instance_id']}.pkl").exists()]
    graph, caches, rows = None, defaultdict(dict), []
    for item in items:
        iid = item["instance_id"]
        if graph is None or graph.iid != iid:
            graph = Graph(iid, layers)
            graph.iid = iid
        lines, skipped = v1.changed_lines(item["patch"])
        seeds, units = set(), defaultdict(int)
        for path, numbers in lines.items():
            for line in numbers:
                found, unit = graph.seeds(path, line)
                seeds |= found
                units[unit] += 1
        depth = graph.reach(seeds)
        flagged = {
            str(k): [i for i in graph.tests if i in depth and (k is None or depth[i] <= k)]
            for k in DEPTHS
        }
        baseline = v1.import_baseline(graph, lines, caches[iid])
        broken = [v1.test_node(graph, t) for t in item["broken"]]
        row = {k: item[k] for k in ("tool", "instance_id", "kind")}
        row.update({
            "changed_files": sorted(lines), "units": dict(units),
            "seeds": sorted(graph.nodes[s][0] for s in seeds)[:40],
            "n_seeds": len(seeds), "repo_tests": len(graph.tests),
            "flag_size": {k: len(v) for k, v in flagged.items()},
            "baseline_size": len(baseline),
            "broken_ids": item["broken"],
            "broken_match": [m for _, m in broken],
            "broken_depth": [depth.get(i) if i is not None else None for i, _ in broken],
            "broken_in_baseline": [i in baseline if i is not None else False for i, _ in broken],
            "layer_edges": dict(graph.layer_edges),
        })
        rows.append(row)
    Path(out_path).write_text(json.dumps(rows, indent=1) + "\n")
    return rows


def summarize(rows, label=""):
    import statistics

    reg = [r for r in rows if r["kind"] != "clean"]
    clean = [r for r in rows if r["kind"] == "clean"]

    def caught(r, k):
        return any(d is not None and (k is None or d <= k) for d in r["broken_depth"])

    def q90(v):
        v = sorted(v)
        return v[min(len(v) - 1, int(round(0.9 * (len(v) - 1))))]

    out = {"label": label, "regressions": len(reg), "controls": len(clean)}
    for k in (3, None):
        key = str(k)
        sizes = [r["flag_size"][key] for r in clean]
        out[f"k{key}"] = {
            "caught": sum(caught(r, k) for r in reg),
            "median": statistics.median(sizes),
            "p90": q90(sizes),
        }
    out["import"] = {
        "caught": sum(any(r["broken_in_baseline"]) for r in reg),
        "median": statistics.median(r["baseline_size"] for r in clean),
    }
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", default="ref,ctor,alias,override")
    ap.add_argument("--out", default=str(HERE / "results.json"))
    ap.add_argument("--available", action="store_true")
    a = ap.parse_args()
    AVAILABLE = a.available
    layers = [x for x in a.layers.split(",") if x]
    rows = run(layers, a.out)
    print(json.dumps(summarize(rows, a.layers)))
