"""Recall when the guard lists only the N nearest tests.

Tests are ordered by call distance; ties at one distance are broken at
random, so a case contributes the probability that a broken test is among
the first N. Distances above 4 are pooled into one tier (the results keep
cumulative counts for k = 1..4 and unlimited only).
"""

import json
import sys
from math import comb


def tiers(r):
    f = r["flag_size"]
    cum = [0, f["1"], f["2"], f["3"], f["4"], f["None"]]
    return [cum[i + 1] - cum[i] for i in range(5)]  # d=1,2,3,4,>4


def tier_of(d):
    return min(d, 5) - 1


def p_caught(r, n):
    depths = [d for d in r["broken_depth"] if d is not None]
    if not depths:
        return 0.0
    if 0 in depths:
        return 1.0  # a broken test is itself changed code
    t = tiers(r)
    best = min(tier_of(d) for d in depths)
    ahead = sum(t[:best])
    tied = t[best]
    m = len({d for d in r["broken_depth"]} and [d for d in depths if tier_of(d) == best])
    m = min(m, tied) if tied else 0
    if n <= ahead or tied == 0 or m == 0:
        return 0.0
    slots = min(n - ahead, tied)
    return 1.0 - comb(tied - m, slots) / comb(tied, slots)


def main():
    budgets = [5, 10, 20, 50, 100]
    print("config".ljust(48), *[f"N={n}".rjust(7) for n in budgets])
    for path in sys.argv[1:]:
        rows = [r for r in json.load(open(path)) if r["kind"] != "clean"]
        vals = [sum(p_caught(r, n) for r in rows) for n in budgets]
        print(path.ljust(48), *[f"{v:7.1f}" for v in vals])


if __name__ == "__main__":
    main()
