"""Candidate caller-edge layers for the regression check.

Each layer is ``f(graph, root, guardian_graph) -> [(caller, callee)]``.

dispatch  getattr/hasattr with a name built from a string prefix reaches the
          methods whose names start with that prefix (the class family of
          ``self``/``cls`` receivers, otherwise every method).
dunder    a call of class C reaches C's special methods and the ones it
          inherits.
duck      a method call on a receiver the type checker did not resolve reaches
          every method with that name, if at most DUCK_CAP define it.
"""

import ast
import os
import warnings
import re
from collections import defaultdict
from pathlib import Path

from codenib.graph.identity import short_name
from codenib.graph.override_edges import class_bases
from codenib.utils import is_test_file

DEFS = {"function", "method"}
IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
DUCK_CAP = int(os.environ.get("DUCK_CAP", "20"))
DUNDER_SKIP = {"__init__", "__new__", "__init_subclass__", "__class_getitem__",
               "__set_name__", "__subclasshook__", "__getattr__", "__getattribute__",
               "__setattr__", "__delattr__", "__dir__", "__reduce__", "__reduce_ex__",
               "__getstate__", "__setstate__", "__copy__", "__deepcopy__", "__del__"}


class View:
    def __init__(self, graph, root):
        self.root = Path(root)
        vs = graph.vs
        self.names = vs["name"]
        self.types = vs["type"]
        self.files = vs["file"]
        self.starts = vs["start_line"]
        self.ends = vs["end_line"]
        self.has_def = [bool(x) for x in vs["has_definition"]]
        self.children = defaultdict(set)
        self.parent = {}
        self.refs = defaultdict(set)
        self.callers = defaultdict(set)
        self.ref_lines = defaultdict(set)  # source -> {(1-based line, target short)}
        lines = graph.es["anchor_line"] if "anchor_line" in graph.es.attributes() else None
        for i, ((s, t), kind) in enumerate(zip(graph.get_edgelist(), graph.es["type"])):
            if kind == "contain":
                self.children[s].add(t)
                self.parent[t] = s
            elif kind == "reference":
                self.refs[s].add(t)
                self.callers[t].add(s)
        self.by_file = defaultdict(list)
        self.file_vertex = {}
        for v, name in enumerate(self.names):
            if self.types[v] == "file":
                self.file_vertex[name] = v
            if self.has_def[v] and self.files[v] and self.starts[v] is not None:
                self.by_file[self.files[v]].append(v)
        self.methods_by_name = defaultdict(list)
        for v, kind in enumerate(self.types):
            if kind == "method" and self.has_def[v] and self.files[v] \
                    and str(self.files[v]).endswith(".py") and not is_test_file(self.files[v]):
                self.methods_by_name[short_name(self.names[v])].append(v)
        self._trees = {}
        self._owner = {}

    def tree(self, path):
        if path not in self._trees:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    self._trees[path] = ast.parse((self.root / path).read_bytes())
            except (SyntaxError, ValueError, OSError):
                self._trees[path] = None
        return self._trees[path]

    def owner(self, path, line):
        """Innermost def (else class, else file) vertex containing 1-based line."""
        key = (path, line)
        if key not in self._owner:
            self._owner[key] = self._owner_uncached(path, line)
        return self._owner[key]

    def _owner_uncached(self, path, line):
        best, best_span = None, None
        for kinds in (DEFS, {"class"}):
            for v in self.by_file.get(path, ()):
                if self.types[v] in kinds and self.starts[v] + 1 <= line <= self.ends[v] + 1:
                    span = self.ends[v] - self.starts[v]
                    if best is None or span < best_span:
                        best, best_span = v, span
            if best is not None:
                return best
        return self.file_vertex.get(path)

    def py_files(self):
        return [p for p in self.by_file if str(p).endswith(".py")]


def _views(guardian_graph, graph, root):
    view = getattr(guardian_graph, "_new_edges_view", None)
    if view is None:
        view = View(graph, root)
        guardian_graph._new_edges_view = view
    return view


# ---------------------------------------------------------------- dispatch


def _prefix(expr, assigned):
    if isinstance(expr, ast.BinOp) and isinstance(expr.op, ast.Add):
        left = expr.left
        while isinstance(left, ast.BinOp) and isinstance(left.op, ast.Add):
            left = left.left
        if isinstance(left, ast.Constant) and isinstance(left.value, str):
            return left.value
    if isinstance(expr, ast.BinOp) and isinstance(expr.op, ast.Mod):
        if isinstance(expr.left, ast.Constant) and isinstance(expr.left.value, str):
            return expr.left.value.split("%", 1)[0]
    if isinstance(expr, ast.JoinedStr) and expr.values:
        first = expr.values[0]
        if isinstance(first, ast.Constant) and isinstance(first.value, str):
            return first.value
    if (isinstance(expr, ast.Call) and isinstance(expr.func, ast.Attribute)
            and expr.func.attr == "format" and isinstance(expr.func.value, ast.Constant)
            and isinstance(expr.func.value.value, str)):
        return expr.func.value.value.split("{", 1)[0]
    if isinstance(expr, ast.Name) and expr.id in assigned:
        return assigned[expr.id]
    return None


def _dispatch_sites(tree):
    """[(line, prefix, receiver_is_self)] for getattr/hasattr with a built name."""
    out = []
    scopes = [n for n in ast.walk(tree)
              if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    for fn in scopes:
        assigned = {}
        for node in ast.walk(fn):
            if isinstance(node, ast.Assign) and len(node.targets) == 1 \
                    and isinstance(node.targets[0], ast.Name):
                p = _prefix(node.value, {})
                if p:
                    assigned[node.targets[0].id] = p
        for node in ast.walk(fn):
            if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
                    and node.func.id == "getattr" and len(node.args) >= 2):
                p = _prefix(node.args[1], assigned)
                if not p or len(p) < 3 or not IDENT.match(p):
                    continue
                recv = node.args[0]
                is_self = isinstance(recv, ast.Name) and recv.id in ("self", "cls")
                out.append((node.lineno, p, is_self))
    return out


def dispatch(graph, root, gg):
    view = _views(gg, graph, root)
    bases = class_bases(graph, root)
    subs = defaultdict(set)
    for c, bs in bases.items():
        for b in bs:
            subs[b].add(c)

    def closure(start, rel):
        seen, stack = set(), [start]
        while stack:
            for nxt in rel.get(stack.pop(), ()):
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        return seen

    names = sorted(view.methods_by_name)
    out = []
    for path in view.py_files():
        if is_test_file(path):
            continue
        tree = view.tree(path)
        if tree is None:
            continue
        for line, prefix, is_self in _dispatch_sites(tree):
            owner = view.owner(path, line)
            if owner is None:
                continue
            targets = [v for n in names if n.startswith(prefix) and n != prefix
                       for v in view.methods_by_name[n]]
            cls = view.parent.get(owner)
            if is_self and cls is not None and view.types[cls] == "class":
                family = {cls} | closure(cls, bases) | closure(cls, subs)
                targets = [v for v in targets if view.parent.get(v) in family]
            out.extend((owner, t) for t in targets)
    return out


# ---------------------------------------------------------------- dunder


def dunder(graph, root, gg):
    view = _views(gg, graph, root)
    bases = class_bases(graph, root)
    special = {}  # class -> {name: method}

    def own(cls):
        if cls not in special:
            special[cls] = {
                short_name(view.names[m]): m for m in view.children.get(cls, ())
                if view.types[m] == "method"
                and short_name(view.names[m]).startswith("__")
                and short_name(view.names[m]).endswith("__")
                and short_name(view.names[m]) not in DUNDER_SKIP
            }
        return special[cls]

    resolved = {}

    def methods(cls, stack=()):
        if cls in resolved:
            return resolved[cls]
        if cls in stack:
            return {}
        found = dict(own(cls))
        for b in sorted(bases.get(cls, ())):
            for name, m in methods(b, stack + (cls,)).items():
                found.setdefault(name, m)
        resolved[cls] = found
        return found

    out = []
    for cls, kind in enumerate(view.types):
        if kind != "class" or not view.has_def[cls]:
            continue
        ms = methods(cls)
        if not ms:
            continue
        callers = [c for c in view.callers.get(cls, ()) if view.types[c] in DEFS]
        for c in callers:
            out.extend((c, m) for m in ms.values())
    return out


# ---------------------------------------------------------------- duck


def duck(graph, root, gg):
    view = _views(gg, graph, root)
    out = []
    for path in view.py_files():
        tree = view.tree(path)
        if tree is None:
            continue
        for node in ast.walk(tree):
            if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)):
                continue
            name = node.func.attr
            if name.startswith("__") and name.endswith("__"):
                continue
            targets = view.methods_by_name.get(name)
            if not targets or len(targets) > DUCK_CAP:
                continue
            owner = view.owner(path, node.lineno)
            if owner is None or view.types[owner] not in DEFS:
                continue
            if any(short_name(view.names[t]) == name for t in view.refs.get(owner, ())):
                continue  # resolved somewhere in this caller
            out.extend((owner, t) for t in targets)
    return out


LAYERS = {"dispatch": dispatch, "dunder": dunder, "duck": duck}


# ---------------------------------------------------------------- fixture

def _is_fixture(dec):
    target = dec.func if isinstance(dec, ast.Call) else dec
    name = target.attr if isinstance(target, ast.Attribute) else getattr(target, "id", None)
    if name != "fixture":
        return None, False
    alias, autouse = None, False
    if isinstance(dec, ast.Call):
        for kw in dec.keywords:
            if kw.arg == "name" and isinstance(kw.value, ast.Constant):
                alias = kw.value.value
            if kw.arg == "autouse" and isinstance(kw.value, ast.Constant):
                autouse = bool(kw.value.value)
    return alias or "", autouse


def fixture(graph, root, gg):
    """A pytest test or fixture runs the fixtures its parameters name.

    Scope: the same file first, then conftest.py files in enclosing
    directories (nearest first), then fixtures defined outside test files
    (plugins such as sphinx.testing.fixtures).
    """
    view = _views(gg, graph, root)
    defs = defaultdict(list)  # name -> [(path, vertex)]
    params = {}  # vertex -> [param names]
    for path in view.py_files():
        tree = view.tree(path)
        if tree is None:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            vertex = view.owner(path, node.body[0].lineno if node.body else node.lineno)
            if vertex is None or view.types[vertex] not in DEFS:
                continue
            is_fix = False
            for dec in node.decorator_list:
                alias, _ = _is_fixture(dec)
                if alias is not None:
                    is_fix = True
                    defs[alias or node.name].append((path, vertex))
            if not (is_fix or is_test_file(path) or Path(path).name == "conftest.py"):
                continue
            names = [a.arg for a in node.args.args + node.args.kwonlyargs
                     if a.arg not in ("self", "cls", "request")]
            if names:
                params[vertex] = names
    out = []
    for vertex, names in params.items():
        path = view.files[vertex]
        if not path:
            continue
        for name in names:
            cands = defs.get(name)
            if not cands:
                continue
            same = [v for p, v in cands if p == path]
            if not same:
                parent = str(Path(path).parent)
                best = None
                for p, v in cands:
                    if Path(p).name == "conftest.py" and (
                        parent == str(Path(p).parent)
                        or parent.startswith(str(Path(p).parent) + "/")
                        or str(Path(p).parent) == "."
                    ):
                        depth = len(Path(p).parent.parts)
                        if best is None or depth > best[0]:
                            best = (depth, [v])
                        elif depth == best[0]:
                            best[1].append(v)
                same = best[1] if best else [v for p, v in cands if not is_test_file(p)]
            out.extend((vertex, v) for v in same if v != vertex)
    return out


# ---------------------------------------------------------------- setup

SETUP = ("setUp", "setUpClass", "setUpTestData", "asyncSetUp", "setup_method",
         "setup_class", "tearDown", "tearDownClass")


def setup(graph, root, gg):
    """A unittest/pytest-class test method runs its class's set-up methods."""
    view = _views(gg, graph, root)
    bases = class_bases(graph, root)
    cache = {}

    def hooks(cls, stack=()):
        if cls in cache:
            return cache[cls]
        if cls in stack:
            return {}
        found = {short_name(view.names[m]): m for m in view.children.get(cls, ())
                 if view.types[m] == "method" and short_name(view.names[m]) in SETUP}
        for b in sorted(bases.get(cls, ())):
            for n, m in hooks(b, stack + (cls,)).items():
                found.setdefault(n, m)
        cache[cls] = found
        return found

    test_files = {view.files[t] for t in getattr(gg, "tests", ())
                  if len(short_name(view.names[t])) > 4}
    out = []
    for v, kind in enumerate(view.types):
        if kind != "method" or not view.has_def[v] or not view.files[v]:
            continue
        if not is_test_file(view.files[v]) or not short_name(view.names[v]).startswith("test"):
            continue
        cls = view.parent.get(v)
        if cls is None or view.types[cls] != "class":
            continue
        out.extend((v, m) for m in hooks(cls).values() if view.files[m] in test_files)
    return out


LAYERS.update({"fixture": fixture, "setup": setup})
