"""Build the symbol graph of one regression-check instance with the current tree.

Usage: python build.py INSTANCE_ID
Env: CODENIB_HOME (private), PYTHONPATH at the feature worktree.
Writes graphs/<id>.pkl (igraph pickle) and prints the build time.
"""

import os
import pickle
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = Path(
    "/tmp/claude-1001/-home-zhongming-CodeNib/"
    "5f1cd921-6685-43cd-ae42-9a375f521d60/scratchpad/guardian"
)


def main():
    iid = sys.argv[1]
    out = HERE / "graphs" / f"{iid}.pkl"
    if out.exists():
        return
    root = OLD / "wt" / iid
    start = time.monotonic()
    proc = subprocess.run(
        [sys.executable, "-m", "codenib", "index", str(root), "--language", "python",
         "--view", "symbol_graph"],
        capture_output=True, text=True, env=os.environ,
    )
    if proc.returncode:
        raise SystemExit(f"{iid}: index failed\n{proc.stdout[-1500:]}\n{proc.stderr[-3000:]}")
    from codenib.compiler.graph_artifact import load_authenticated_graph_artifact
    from codenib.compiler.manifest import MANIFEST_FILENAME, RepoManifest
    from codenib.paths import repo_index_dir

    manifest = RepoManifest.load(repo_index_dir(root) / MANIFEST_FILENAME)
    graph = load_authenticated_graph_artifact(manifest.indexes["symbol_graph"]).graph
    out.parent.mkdir(exist_ok=True)
    tmp = out.with_suffix(".tmp")
    with open(tmp, "wb") as f:
        pickle.dump(graph, f, protocol=pickle.HIGHEST_PROTOCOL)
    tmp.rename(out)
    print(iid, "vertices", graph.vcount(), "edges", graph.ecount(),
          "%.0fs" % (time.monotonic() - start), flush=True)


if __name__ == "__main__":
    main()
