"""Reproduce: Schema.dump() drops fields whose `attribute` is a dotted path
with three or more segments. Run from the repository root: python repro.py"""

import sys

sys.path.insert(0, "src")

from marshmallow import Schema, fields  # noqa: E402


class Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


class PetSchema(Schema):
    name = fields.String()
    owner_name = fields.String(attribute="owner.name")
    owner_city = fields.String(attribute="owner.address.city")
    owner_zip = fields.String(attribute="owner.address.geo.zip")


pet_obj = Obj(
    name="Rex",
    owner=Obj(name="Ana", address=Obj(city="Lyon", geo=Obj(zip="69001"))),
)
pet_dict = {
    "name": "Rex",
    "owner": {"name": "Ana", "address": {"city": "Lyon", "geo": {"zip": "69001"}}},
}
expected = {
    "name": "Rex",
    "owner_name": "Ana",
    "owner_city": "Lyon",
    "owner_zip": "69001",
}

problems = []
schema = PetSchema()

# Control cases that must keep working.
got = schema.dump(pet_obj)
for key in ("name", "owner_name"):
    if got.get(key) != expected[key]:
        problems.append(f"control: dump(object)[{key!r}] = {got.get(key)!r}")
loaded = schema.load(
    {"name": "Rex", "owner_name": "Ana", "owner_city": "Lyon", "owner_zip": "69001"}
)
want_loaded = {
    "name": "Rex",
    "owner": {"name": "Ana", "address": {"city": "Lyon", "geo": {"zip": "69001"}}},
}
if loaded != want_loaded:
    problems.append(f"control: load() = {loaded!r}")

# Affected cases: three- and four-segment attribute paths on dump.
for label, data in (("object", pet_obj), ("dict", pet_dict)):
    got = schema.dump(data)
    if got != expected:
        problems.append(f"dump({label}) = {got!r}, expected {expected!r}")
got = PetSchema(many=True).dump([pet_obj, pet_dict])
if got != [expected, expected]:
    problems.append(f"dump(many=True) = {got!r}")

if problems:
    print("SYMPTOM: Schema.dump() output is wrong:")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print("OK: dotted attribute paths dump correctly at every depth")
sys.exit(0)
