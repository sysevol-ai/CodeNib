# marshmallow case notes

- Upstream: https://github.com/marshmallow-code/marshmallow tag 4.3.1 (c7b559a1fa3aba57ca6dba0ab336841c5038a782); pure Python, 38 .py files / 15,715 lines (just above the 15k floor). Installs on Python 3.13 aarch64 with flit_core (no compiled code anywhere).
- Entry point: public API `Schema.dump()`. Fault: `utils.get_value` (src/marshmallow/utils.py:109) gains `maxsplit=1`, reached as dump -> Schema._serialize -> Field.serialize -> Field.get_value -> (accessor Schema.get_attribute) -> utils.get_value: 4 project calls before the faulty function, one of them through the accessor callback passed in at schema.py:541.
- Symptom is silent (key missing, no exception), so there is no traceback that hands over the path.
- Affected: dotted `attribute` paths with 3+ segments on dump (objects, dicts, many=True). Unaffected: 2-segment paths, plain fields, `Schema.load()` (uses `set_value`, whose `split(".", 1)` is correct because it recurses - the main decoy).
- Upstream tests in the image: `pytest tests` -> 1188 passed on upstream and 1188 passed on source (no test covers 3-segment dump paths), so the suite gives no hint.
- Grader note: a field with `dump_default` would emit the default instead of disappearing; the prompt avoids that case. Accept answers that skip the one-line `Schema.get_attribute` wrapper.
