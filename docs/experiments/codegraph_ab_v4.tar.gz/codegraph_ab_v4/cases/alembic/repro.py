"""Reproduce: `alembic revision` post-write hooks whose `options` omit the
REVISION_SCRIPT_FILENAME token do not process the new revision file.
Run from the repository root: python repro.py"""

import os
import shutil
import subprocess
import sys
import tempfile

REPO = os.path.abspath(os.path.dirname(__file__) or ".")
ENV = dict(os.environ, PYTHONPATH=REPO + os.pathsep + os.environ.get("PYTHONPATH", ""))


def alembic(project, *args):
    proc = subprocess.run(
        [sys.executable, "-m", "alembic", *args],
        cwd=project,
        env=ENV,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        print(f"alembic {' '.join(args)} failed:\n{proc.stdout}{proc.stderr}")
        sys.exit(2)
    return proc.stdout + proc.stderr


# (label, hook lines for [post_write_hooks], affected?)
CASES = [
    (
        "console_scripts, options without token",
        ["hooks = black", "black.type = console_scripts",
         "black.entrypoint = black", "black.options = -l 79"],
        True,
    ),
    (
        "module, options without token",
        ["hooks = black", "black.type = module", "black.module = black",
         "black.options = --quiet"],
        True,
    ),
    (
        "console_scripts, options with REVISION_SCRIPT_FILENAME",
        ["hooks = black", "black.type = console_scripts",
         "black.entrypoint = black",
         "black.options = -l 79 REVISION_SCRIPT_FILENAME"],
        False,
    ),
    (
        "console_scripts, no options",
        ["hooks = black", "black.type = console_scripts",
         "black.entrypoint = black"],
        False,
    ),
]

project = tempfile.mkdtemp()
problems = []
try:
    alembic(project, "init", "migrations")
    ini_path = os.path.join(project, "alembic.ini")
    with open(ini_path) as f:
        original_ini = f.read()
    assert "\n[post_write_hooks]\n" in original_ini

    for n, (label, hook_lines, affected) in enumerate(CASES, start=1):
        with open(ini_path, "w") as f:
            f.write(original_ini.replace(
                "\n[post_write_hooks]\n",
                "\n[post_write_hooks]\n" + "\n".join(hook_lines) + "\n",
            ))
        rev_id = f"abc{n:09d}"
        output = alembic(project, "revision", "-m", f"step {n}", "--rev-id", rev_id)
        versions = os.path.join(project, "migrations", "versions")
        (path,) = [
            os.path.join(versions, p)
            for p in os.listdir(versions)
            if p.startswith(rev_id) and p.endswith(".py")
        ]
        with open(path) as f:
            text = f.read()
        # black rewrites the template's single-quoted repr() into double quotes
        formatted = f'revision: str = "{rev_id}"' in text
        if not formatted:
            problems.append(
                f"{label}: revision file was not processed by the hook"
                f" ({'affected' if affected else 'control'} case)"
            )
            for line in output.splitlines():
                if line.strip():
                    problems.append("    | " + line.strip())
finally:
    shutil.rmtree(project, ignore_errors=True)

if problems:
    print("SYMPTOM: post-write hook did not format the new revision file:")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print("OK: post-write hooks ran on the new revision file in every configuration")
sys.exit(0)
