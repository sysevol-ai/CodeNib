"""Run the `cookiecutter` CLI with a user config file that defines repository abbreviations.

Run from the repository root inside the case image: `python repro.py`.
Exit 1 when the symptom appears, 0 when every invocation behaves correctly.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path


def make_template(root: Path) -> None:
    (root / "{{cookiecutter.project_slug}}").mkdir(parents=True)
    (root / "cookiecutter.json").write_text(
        json.dumps({"project_slug": "widget", "owner": "nobody"}), encoding="utf-8"
    )
    (root / "{{cookiecutter.project_slug}}" / "README.txt").write_text(
        "owner={{ cookiecutter.owner }}\n", encoding="utf-8"
    )


def run(args: list[str], out: Path, env: dict[str, str]) -> tuple[int, str, str]:
    out.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        [sys.executable, "-m", "cookiecutter", "--no-input", "-o", str(out), *args],
        capture_output=True,
        text=True,
        env=env,
        timeout=120,
    )
    readme = out / "widget" / "README.txt"
    content = readme.read_text(encoding="utf-8").strip() if readme.exists() else "<no project generated>"
    return proc.returncode, content, (proc.stdout + proc.stderr).strip()


def main() -> int:
    failures: list[str] = []
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        mirror = base / "mirror"
        make_template(mirror / "acme" / "widget")
        config = base / "cookiecutterrc.yaml"
        config.write_text(
            "cookiecutters_dir: {0}/cache\n"
            "replay_dir: {0}/replay\n"
            "default_context:\n"
            "  owner: from-config\n"
            "abbreviations:\n"
            "  gh: {1}/{{0}}\n"
            "  corp: {1}/{{0}}\n".format(base, mirror),
            encoding="utf-8",
        )
        env = dict(os.environ)
        env.update(
            HOME=str(base / "home"),
            GIT_TERMINAL_PROMPT="0",
            # never reach the real github.com: any https://github.com/ clone fails locally and fast
            GIT_CONFIG_COUNT="1",
            GIT_CONFIG_KEY_0="url.file:///nonexistent-github-mirror/.insteadOf",
            GIT_CONFIG_VALUE_0="https://github.com/",
        )
        (base / "home").mkdir()

        cases = [
            # (label, CLI arguments, expected README content); the first one is the affected case
            ("user-config override of built-in 'gh:'", ["--config-file", str(config), "gh:acme/widget"], "owner=from-config"),
            ("user-config custom 'corp:' abbreviation", ["--config-file", str(config), "corp:acme/widget"], "owner=from-config"),
            ("plain local template path with the same config", ["--config-file", str(config), str(mirror / "acme" / "widget")], "owner=from-config"),
            ("plain local template path, --default-config", ["--default-config", str(mirror / "acme" / "widget")], "owner=nobody"),
        ]
        for index, (label, args, expected) in enumerate(cases):
            code, content, output = run(args, base / f"out{index}", env)
            if code != 0 or content != expected:
                tail = output.splitlines()[-1] if output else ""
                failures.append(f"{label}: exit {code}, README {content!r} (expected {expected!r}); last output line: {tail}")

    if failures:
        print("SYMPTOM: abbreviation/config handling is wrong:")
        for line in failures:
            print("  - " + line)
        return 1
    print("OK: user-config abbreviations (including overrides of built-ins) and default_context are honoured")
    return 0


if __name__ == "__main__":
    sys.exit(main())
