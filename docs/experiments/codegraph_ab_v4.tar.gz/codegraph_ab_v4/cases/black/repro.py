"""Run from the repository root: python repro.py

Black keeps consecutive one-line dummy implementations ("def f(): ...") together
when the user wrote them without blank lines (e.g. @overload groups, Protocol
methods). Checks the `black` CLI on .py files and on unaffected inputs.
"""
import os
import subprocess
import sys
import tempfile

OVERLOADS = '''\
from typing import overload


@overload
def parse(value: int) -> int: ...
@overload
def parse(value: str) -> str: ...
def parse(value):
    return value
'''

PROTOCOL = '''\
from typing import Protocol


class Reader(Protocol):
    def read(self, size: int) -> bytes: ...
    def close(self) -> None: ...
'''

# Unaffected inputs, with the output black is expected to produce.
REGULAR_IN = '''\
def first():
    return 1
def second():
    return 2
'''
REGULAR_OUT = '''\
def first():
    return 1


def second():
    return 2
'''

SEPARATED = '''\
def first(): ...


def second(): ...
'''

PYI_IN = '''\
from typing import overload
@overload
def parse(value: int) -> int: ...
@overload
def parse(value: str) -> str: ...
class Reader:
    def read(self, size: int) -> bytes: ...
    def close(self) -> None: ...
'''
PYI_OUT = '''\
from typing import overload

@overload
def parse(value: int) -> int: ...
@overload
def parse(value: str) -> str: ...

class Reader:
    def read(self, size: int) -> bytes: ...
    def close(self) -> None: ...
'''

repo_root = os.getcwd()
workdir = tempfile.mkdtemp()
env = dict(os.environ, BLACK_CACHE_DIR=os.path.join(workdir, '.cache'))
src_dir = os.path.join(repo_root, 'src')
env['PYTHONPATH'] = src_dir + os.pathsep + env.get('PYTHONPATH', '')


def run_black(filename, content):
    path = os.path.join(workdir, filename)
    with open(path, 'w') as f:
        f.write(content)
    proc = subprocess.run(
        [sys.executable, '-m', 'black', '-q', path],
        cwd=workdir, env=env, capture_output=True, text=True,
    )
    if proc.returncode != 0:
        print(proc.stdout, proc.stderr)
        sys.exit(f'black failed on {filename} (exit {proc.returncode})')
    with open(path) as f:
        return f.read()


symptoms, unexpected = [], []

for name, content in [('overloads.py', OVERLOADS), ('protocol.py', PROTOCOL)]:
    out = run_black(name, content)
    if out != content:
        symptoms.append(f'{name}: black inserted blank lines between dummy '
                        f'implementations:\n{out}')

for name, content, expected in [
    ('regular.py', REGULAR_IN, REGULAR_OUT),
    ('separated.py', SEPARATED, SEPARATED),
    ('stubs.pyi', PYI_IN, PYI_OUT),
]:
    out = run_black(name, content)
    if out != expected:
        unexpected.append(f'{name}: unexpected output:\n{out}')

if unexpected:
    print('UNEXPECTED:', *unexpected, sep='\n')
    sys.exit(2)
if symptoms:
    print('SYMPTOM:', *symptoms, sep='\n')
    sys.exit(1)
print('OK: dummy implementations stay grouped in .py files; unaffected inputs format as expected.')
sys.exit(0)
