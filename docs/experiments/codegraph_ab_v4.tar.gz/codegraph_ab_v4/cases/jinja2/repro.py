"""Reproduce: with a FileSystemBytecodeCache, edited template files keep
rendering their old content. Run from the repository root: python repro.py"""

import os
import shutil
import sys
import tempfile

sys.path.insert(0, "src")

from jinja2 import DictLoader  # noqa: E402
from jinja2 import Environment  # noqa: E402
from jinja2 import FileSystemBytecodeCache  # noqa: E402
from jinja2 import FileSystemLoader  # noqa: E402

root = tempfile.mkdtemp()
templates = os.path.join(root, "templates")
cache_dir = os.path.join(root, "cache")
os.makedirs(templates)
os.makedirs(cache_dir)
page = os.path.join(templates, "page.html")
other = os.path.join(templates, "other.html")


def write(path, text, mtime):
    with open(path, "w") as f:
        f.write(text)
    os.utime(path, (mtime, mtime))


def env(cache=True, **kw):
    bcc = FileSystemBytecodeCache(cache_dir) if cache else None
    return Environment(loader=FileSystemLoader(templates), bytecode_cache=bcc, **kw)


problems = []


def check(label, got, want):
    if got != want:
        problems.append(f"{label}: rendered {got!r}, expected {want!r}")


try:
    write(page, "Hello {{ name }} (v1)", 1_700_000_000)
    write(other, "Bye {{ name }}", 1_700_000_000)

    # First load compiles and fills the cache.
    check("first load", env().get_template("page.html").render(name="Ana"),
          "Hello Ana (v1)")
    check("first load other", env().get_template("other.html").render(name="Ana"),
          "Bye Ana")
    # Unchanged template served from the cache (control).
    check("unchanged, new env", env().get_template("other.html").render(name="Ana"),
          "Bye Ana")

    # Long-lived environment with auto_reload (the default).
    live = env()
    check("live env before edit", live.get_template("page.html").render(name="Ana"),
          "Hello Ana (v1)")

    # Edit the template on disk.
    write(page, "Hi {{ name }} (v2)", 1_700_000_100)

    # Without a bytecode cache, the edit is picked up (control).
    check("edited, no bytecode cache",
          env(cache=False).get_template("page.html").render(name="Ana"),
          "Hi Ana (v2)")
    # from_string never touches the cache (control).
    check("from_string", env().from_string("Hi {{ name }} (v2)").render(name="Ana"),
          "Hi Ana (v2)")
    # DictLoader with the same cache directory, fresh content (control).
    dict_env = Environment(loader=DictLoader({"d.html": "D {{ name }}"}),
                           bytecode_cache=FileSystemBytecodeCache(cache_dir))
    check("dict loader", dict_env.get_template("d.html").render(name="Ana"), "D Ana")

    # Affected: a fresh environment (e.g. after a restart) sharing the cache.
    check("edited, new env with bytecode cache",
          env().get_template("page.html").render(name="Ana"), "Hi Ana (v2)")
    # Affected: the long-lived environment notices the mtime change and reloads.
    check("edited, live env auto_reload",
          live.get_template("page.html").render(name="Ana"), "Hi Ana (v2)")
finally:
    shutil.rmtree(root, ignore_errors=True)

if problems:
    print("SYMPTOM: stale template output with FileSystemBytecodeCache:")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print("OK: edited templates are recompiled when a bytecode cache is configured")
sys.exit(0)
