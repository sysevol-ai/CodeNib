"""Reproduce: positional CLI arguments bound to the wrong parameters.

Writes a few small Typer apps (one command each, ``app = typer.Typer()`` +
``@app.command()`` + ``app()``) into a temp dir, runs them as CLIs and checks
which values each parameter receives.

Exit 1 when values are bound to the wrong parameters, 0 when all are correct.
"""

import json
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

APPS = {
    # A list argument followed by two single arguments (affected).
    "cli_copy_mode": """
        def main(sources: list[str], dest: str, mode: str):
            print(json.dumps({"sources": sources, "dest": dest, "mode": mode}))
    """,
    # Same shape with a typed trailing argument (affected).
    "cli_copy_count": """
        def main(sources: list[str], dest: str, retries: int):
            print(json.dumps({"sources": sources, "dest": dest, "retries": retries}))
    """,
    # A list argument followed by exactly one argument (unaffected).
    "cli_copy": """
        def main(sources: list[str], dest: str):
            print(json.dumps({"sources": sources, "dest": dest}))
    """,
    # A list argument in the last position (unaffected).
    "cli_tag": """
        def main(tag: str, mode: str, files: list[str]):
            print(json.dumps({"tag": tag, "mode": mode, "files": files}))
    """,
    # No list argument at all (unaffected).
    "cli_plain": """
        def main(first: str, second: str, third: str):
            print(json.dumps({"first": first, "second": second, "third": third}))
    """,
    # A list argument followed by one argument plus an option (unaffected).
    "cli_copy_opt": """
        def main(sources: list[str], dest: str, mode: str = typer.Option("safe")):
            print(json.dumps({"sources": sources, "dest": dest, "mode": mode}))
    """,
}

HEADER = """
import json
import typer

app = typer.Typer()

@app.command()
"""

FOOTER = """
if __name__ == "__main__":
    app()
"""

CASES = [
    # (app, argv, expected parsed values)
    ("cli_copy_mode", ["a.txt", "b.txt", "c.txt", "out", "fast"],
     {"sources": ["a.txt", "b.txt", "c.txt"], "dest": "out", "mode": "fast"}),
    ("cli_copy_count", ["a.txt", "b.txt", "out", "3"],
     {"sources": ["a.txt", "b.txt"], "dest": "out", "retries": 3}),
    ("cli_copy", ["a.txt", "b.txt", "out"],
     {"sources": ["a.txt", "b.txt"], "dest": "out"}),
    ("cli_tag", ["v1", "fast", "a.txt", "b.txt"],
     {"tag": "v1", "mode": "fast", "files": ["a.txt", "b.txt"]}),
    ("cli_plain", ["one", "two", "three"],
     {"first": "one", "second": "two", "third": "three"}),
    ("cli_copy_opt", ["a.txt", "b.txt", "out", "--mode", "fast"],
     {"sources": ["a.txt", "b.txt"], "dest": "out", "mode": "fast"}),
]


def main() -> int:
    failures = []
    with tempfile.TemporaryDirectory() as tmp:
        for name, body in APPS.items():
            src = HEADER + textwrap.dedent(body) + FOOTER
            Path(tmp, f"{name}.py").write_text(src)
        for name, argv, expected in CASES:
            proc = subprocess.run(
                [sys.executable, f"{name}.py", *argv],
                cwd=tmp, capture_output=True, text=True,
            )
            cmd = f"python {name}.py {' '.join(argv)}"
            if "Traceback" in proc.stderr:
                print(proc.stderr)
                raise SystemExit(f"setup error while running {cmd}")
            if proc.returncode != 0:
                err = proc.stderr.strip().splitlines()
                print(f"[WRONG] {cmd}: exit {proc.returncode}: "
                      f"{' / '.join(line.strip(' │╭╰─') for line in err if line.strip(' │╭╰─'))}")
                failures.append(cmd)
                continue
            got = json.loads(proc.stdout)
            ok = got == expected
            print(f"[{'ok' if ok else 'WRONG'}] {cmd}: {got}")
            if not ok:
                print(f"         expected: {expected}")
                failures.append(cmd)
    if failures:
        print(f"SYMPTOM: positional values bound to the wrong parameters: {failures}")
        return 1
    print("all positional arguments bound correctly")
    return 0


if __name__ == "__main__":
    sys.exit(main())
