"""Run `tox list` in small projects that keep their tox configuration in different files.

Run from the repository root inside the case image: `python repro.py`.
Exit 1 when the symptom appears, 0 when every project lists its configured environments.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

INI_BODY = """\
[tox]
env_list = lint, unit
skipsdist = true

[testenv:lint]
description = run linters
skip_install = true
commands = python -c 'print("lint")'

[testenv:unit]
description = run unit tests
skip_install = true
commands = python -c 'print("unit")'
"""

TOML_TABLES = """\
env_list = ["lint", "unit"]
skipsdist = true

[{prefix}env.lint]
description = "run linters"
skip_install = true
commands = [["python", "-c", "print('lint')"]]

[{prefix}env.unit]
description = "run unit tests"
skip_install = true
commands = [["python", "-c", "print('unit')"]]
"""

PROJECT = '[project]\nname = "demo"\nversion = "0.1"\n'

PROJECTS: dict[str, dict[str, str]] = {
    # affected: pyproject.toml holding the INI text under [tool.tox] legacy_tox_ini
    "pyproject.toml legacy_tox_ini": {
        "pyproject.toml": PROJECT + '\n[tool.tox]\nlegacy_tox_ini = """\n' + INI_BODY + '"""\n',
    },
    "tox.ini": {"tox.ini": INI_BODY},
    "setup.cfg [tox:tox]": {
        "setup.cfg": INI_BODY.replace("[tox]", "[tox:tox]").replace("[testenv:", "[testenv:"),
    },
    "pyproject.toml native [tool.tox]": {
        "pyproject.toml": PROJECT + "\n[tool.tox]\n" + TOML_TABLES.format(prefix="tool.tox."),
    },
    "tox.toml next to pyproject.toml with an empty [tool.tox]": {
        "pyproject.toml": PROJECT + "\n[tool.tox]\n",
        "tox.toml": TOML_TABLES.format(prefix=""),
    },
}

EXPECTED = {"lint": "run linters", "unit": "run unit tests"}


def tox_list(project: Path, home: Path) -> tuple[int, dict[str, str], str]:
    env = dict(os.environ, HOME=str(home), XDG_CONFIG_HOME=str(home / ".config"), NO_COLOR="1")
    env.pop("TOX_USER_CONFIG_FILE", None)
    proc = subprocess.run(
        [sys.executable, "-m", "tox", "list"], cwd=project, capture_output=True, text=True, env=env, timeout=300
    )
    listed: dict[str, str] = {}
    for line in proc.stdout.splitlines():
        if " -> " in line:
            name, _, desc = line.partition(" -> ")
            listed[name.strip()] = desc.strip()
    return proc.returncode, listed, (proc.stdout + proc.stderr).strip()


def main() -> int:
    failures: list[str] = []
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        home = base / "home"
        home.mkdir()
        for index, (label, files) in enumerate(PROJECTS.items()):
            project = base / f"project{index}"
            project.mkdir()
            for name, text in files.items():
                (project / name).write_text(text, encoding="utf-8")
            code, listed, output = tox_list(project, home)
            if code != 0 or listed != EXPECTED:
                failures.append(f"{label}: `tox list` exit {code}, listed {listed} (expected {EXPECTED})")

    if failures:
        print("SYMPTOM: tox does not pick up the project's configuration:")
        for line in failures:
            print("  - " + line)
        return 1
    print("OK: every configuration location lists lint and unit")
    return 0


if __name__ == "__main__":
    sys.exit(main())
