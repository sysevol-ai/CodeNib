"""Reproduce: folding of long unbroken runs of text in Console.print.

Prints text through ``rich.console.Console.print`` at fixed widths and measures
the width (in terminal cells) of each output line.

Exit 1 when a folded line comes out shorter than the console width although
the next character would still have fitted, 0 when all output is correct.
"""

import io
import sys

from rich.cells import cell_len
from rich.console import Console

CJK = "高速アプリケーション開発フレームワーク" * 5  # 95 double-width chars
EURO = "€" * 100  # one cell each, but outside the ASCII/Latin ranges
ASCII = "x" * 100


def render(text, width, **kwargs):
    console = Console(
        width=width,
        file=io.StringIO(),
        color_system=None,
        force_terminal=False,
        legacy_windows=False,
        emoji=False,
        highlight=False,
        markup=False,
    )
    console.print(text, **kwargs)
    return console.file.getvalue().rstrip("\n").split("\n")


def widths(lines):
    return [cell_len(line) for line in lines]


CASES = [
    # (description, text, width, print kwargs, expected cell widths per line)
    ("CJK run, width 80", CJK, 80, {}, [80, 80, 30]),
    ("CJK run, width 40", CJK, 40, {}, [40, 40, 40, 40, 30]),
    ("euro-sign run, width 40", EURO, 40, {}, [40, 40, 20]),
    ("mixed ASCII/CJK run, width 21",
     "TextualはPythonの高速アプリケーション開発フレームワークです", 21, {},
     [21, 20, 18]),
    # Unaffected inputs
    ("CJK run, width 79", CJK, 79, {}, [78, 78, 34]),
    ("ASCII run, width 40", ASCII, 40, {}, [40, 40, 20]),
    ("CJK words separated by spaces, width 30",
     " ".join(["高速アプリ"] * 6), 30, {}, [22, 22, 21]),
    ("CJK run, width 80, overflow='ellipsis'", CJK, 80,
     {"overflow": "ellipsis"}, [80]),
]


def main() -> int:
    failures = []
    for desc, text, width, kwargs, expected in CASES:
        got = widths(render(text, width, **kwargs))
        ok = got == expected
        print(f"[{'ok' if ok else 'WRONG'}] {desc}: line widths {got}")
        if not ok:
            print(f"         expected: {expected}")
            failures.append(desc)
    if failures:
        print(f"SYMPTOM: folded lines shorter than the console width: {failures}")
        return 1
    print("all text folded to the full console width")
    return 0


if __name__ == "__main__":
    sys.exit(main())
