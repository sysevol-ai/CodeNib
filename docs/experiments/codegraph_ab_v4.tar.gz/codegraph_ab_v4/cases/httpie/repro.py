"""Run from the repository root: python repro.py

Named sessions must not persist request-specific headers (Content-*, If-*),
whatever capitalization the user typed them in. Ordinary headers must persist.
"""
import json
import os
import subprocess
import sys
import tempfile


def http(config_dir, *args):
    env = dict(os.environ, HTTPIE_CONFIG_DIR=config_dir)
    proc = subprocess.run(
        [sys.executable, '-m', 'httpie', '--ignore-stdin', '--offline', *args],
        capture_output=True, text=True, env=env, cwd=os.getcwd(),
    )
    if proc.returncode != 0:
        print(proc.stdout, proc.stderr)
        sys.exit(f'http {" ".join(args)} exited {proc.returncode}')
    return proc.stdout


def request_header_names(output):
    head = output.split('\n\n', 1)[0].splitlines()[1:]
    return [line.split(':', 1)[0] for line in head if ':' in line]


def stored_header_names(config_dir, session):
    path = os.path.join(config_dir, 'sessions', 'example.org', f'{session}.json')
    with open(path) as f:
        return [h['name'] for h in json.load(f)['headers']]


def run_session(first_request_items, method='POST', extra=()):
    config_dir = tempfile.mkdtemp()
    http(config_dir, *extra, '--session=s', method, 'example.org', *first_request_items)
    stored = stored_header_names(config_dir, 's')
    replayed = request_header_names(http(config_dir, '--session=s', 'GET', 'example.org'))
    return stored, replayed


def lower(names):
    return {n.lower() for n in names}


problems = []
unexpected = []

# Affected: request-specific headers typed in lowercase / non-canonical case.
stored, replayed = run_session(
    ['content-type:application/xml', 'if-none-match:"v1"', 'CONTENT-LANGUAGE:de',
     'X-Api-Key:k1', 'foo=bar'])
leaked = sorted(lower(stored) & {'content-type', 'if-none-match', 'content-language'})
if leaked:
    problems.append(f'non-canonical spelling: session stored {leaked}; '
                    f'next GET sent {sorted(lower(replayed) & set(leaked))}')
if 'x-api-key' not in lower(stored) or 'x-api-key' not in lower(replayed):
    unexpected.append(f'X-Api-Key not kept (stored={stored})')

# Unaffected: the same headers typed in canonical capitalization.
stored, replayed = run_session(
    ['Content-Type:application/xml', 'If-None-Match:"v1"', 'Content-Language:de',
     'X-Api-Key:k1', 'foo=bar'])
if lower(stored) & {'content-type', 'if-none-match', 'content-language'}:
    unexpected.append(f'canonical spelling stored: {stored}')
if 'x-api-key' not in lower(replayed):
    unexpected.append(f'canonical case: X-Api-Key not replayed ({replayed})')

# Unaffected: Content-Type that HTTPie adds itself for --form data.
stored, replayed = run_session(['X-Api-Key:k1', 'foo=bar'], extra=('--form',))
if 'content-type' in lower(stored) or 'content-type' in lower(replayed):
    unexpected.append(f'--form Content-Type stored: {stored}')

if unexpected:
    print('UNEXPECTED:', *unexpected, sep='\n  ')
    sys.exit(2)
if problems:
    print('SYMPTOM: request-specific headers leak into the session:', *problems, sep='\n  ')
    sys.exit(1)
print('OK: Content-*/If-* headers are never stored; other headers are kept.')
sys.exit(0)
