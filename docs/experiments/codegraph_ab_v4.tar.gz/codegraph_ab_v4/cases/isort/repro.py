"""Run from the repository root: python repro.py

With combine_as_imports, isort must not add a plain import for a name that the
file only imports under an alias. Checks the `isort` CLI on temp files.
"""
import os
import subprocess
import sys
import tempfile

SOURCE = '''\
import sys
from typing import List as L, Dict
from os import path as osp
from collections import OrderedDict, OrderedDict as OD
import numpy as np

print(sys, L, Dict, osp, OrderedDict, OD, np)
'''

COMBINED = '''\
import sys
from collections import OrderedDict, OrderedDict as OD
from os import path as osp
from typing import Dict, List as L

import numpy as np

print(sys, L, Dict, osp, OrderedDict, OD, np)
'''

DEFAULT = '''\
import sys
from collections import OrderedDict
from collections import OrderedDict as OD
from os import path as osp
from typing import Dict
from typing import List as L

import numpy as np

print(sys, L, Dict, osp, OrderedDict, OD, np)
'''

# Unaffected even with --combine-as: names imported both plainly and aliased,
# and straight `import x as y`.
BOTH = '''\
from collections import OrderedDict, OrderedDict as OD
import numpy as np

print(OrderedDict, OD, np)
'''
BOTH_OUT = '''\
from collections import OrderedDict, OrderedDict as OD

import numpy as np

print(OrderedDict, OD, np)
'''

repo_root = os.getcwd()
workdir = tempfile.mkdtemp()
env = dict(os.environ)
env['PYTHONPATH'] = repo_root + os.pathsep + env.get('PYTHONPATH', '')


def run_isort(filename, content, *options):
    path = os.path.join(workdir, filename)
    with open(path, 'w') as f:
        f.write(content)
    proc = subprocess.run(
        [sys.executable, '-m', 'isort', *options, path],
        cwd=workdir, env=env, capture_output=True, text=True,
    )
    if proc.returncode != 0:
        print(proc.stdout, proc.stderr)
        sys.exit(f'isort {" ".join(options)} {filename} exited {proc.returncode}')
    with open(path) as f:
        return f.read()


symptoms, unexpected = [], []

for name, options in [('combine_as.py', ('--combine-as',)),
                      ('django.py', ('--profile', 'django'))]:
    out = run_isort(name, SOURCE, *options)
    if out != COMBINED:
        added = [line for line in out.splitlines() if line not in COMBINED.splitlines()]
        symptoms.append(f'isort {" ".join(options)}: unexpected import lines {added}')

out = run_isort('default.py', SOURCE)
if out != DEFAULT:
    unexpected.append(f'default options changed output:\n{out}')

out = run_isort('both.py', BOTH, '--combine-as')
if out != BOTH_OUT:
    unexpected.append(f'--combine-as with plain+aliased name changed output:\n{out}')

if unexpected:
    print('UNEXPECTED:', *unexpected, sep='\n  ')
    sys.exit(2)
if symptoms:
    print('SYMPTOM: isort adds imports that are not in the file:', *symptoms, sep='\n  ')
    sys.exit(1)
print('OK: --combine-as keeps alias-only imports as aliases; unaffected inputs are unchanged.')
sys.exit(0)
