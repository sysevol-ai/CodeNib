"""Layer parameter declarations must stay scoped to the registration path that declares them.

Public-behaviour tests: they only build applications and send requests (plus one OpenAPI
lookup). Run them from outside the repository with the repository's virtualenv.
"""

from __future__ import annotations

from litestar import Controller, Litestar, Router, get
from litestar.handlers import HTTPRouteHandler
from litestar.params import FromQuery, HeaderParameter, QueryParameter
from litestar.status_codes import HTTP_200_OK, HTTP_400_BAD_REQUEST
from litestar.testing import create_test_client


def _make_items_handler() -> HTTPRouteHandler:
    @get("/items", sync_to_thread=False)
    def list_items() -> dict[str, bool]:
        return {"ok": True}

    return list_items


def _openapi_parameter_names(app: Litestar, path: str) -> set[str]:
    operation = app.openapi_schema.paths[path].get  # type: ignore[index, union-attr]
    return {p.name for p in (operation.parameters or [])}  # type: ignore[union-attr]


def test_shared_handler_routers_keep_their_own_parameters() -> None:
    """Symptom 1: one handler object under two routers with different declarations."""
    handler = _make_items_handler()
    router_a = Router("/a", route_handlers=[handler], parameters={"pa": QueryParameter(annotation=str)})
    router_b = Router("/b", route_handlers=[handler], parameters={"pb": QueryParameter(annotation=str)})

    with create_test_client([router_a, router_b]) as client:
        assert client.get("/a/items", params={"pa": "1"}).status_code == HTTP_200_OK
        assert client.get("/b/items", params={"pb": "1"}).status_code == HTTP_200_OK

        # each router still enforces its own declaration
        missing_a = client.get("/a/items")
        assert missing_a.status_code == HTTP_400_BAD_REQUEST
        assert "'pa'" in missing_a.json()["detail"]
        missing_b = client.get("/b/items")
        assert missing_b.status_code == HTTP_400_BAD_REQUEST
        assert "'pb'" in missing_b.json()["detail"]


def test_sibling_router_without_parameters_is_unaffected() -> None:
    """Symptom 1: a router that declares nothing must not inherit a sibling's header."""
    handler = _make_items_handler()
    tenant_router = Router(
        "/v1",
        route_handlers=[handler],
        parameters={"tenant": HeaderParameter(annotation=str, name="X-Tenant")},
    )
    public_router = Router("/v2", route_handlers=[handler])

    with create_test_client([tenant_router, public_router]) as client:
        assert client.get("/v2/items").status_code == HTTP_200_OK
        assert "X-Tenant" not in _openapi_parameter_names(client.app, "/v2/items")

        assert client.get("/v1/items").status_code == HTTP_400_BAD_REQUEST
        assert client.get("/v1/items", headers={"X-Tenant": "acme"}).status_code == HTTP_200_OK


def test_reused_handler_second_app_reads_its_own_alias() -> None:
    """Symptom 2: a bare marker in a reused handler must not keep the first app's alias."""

    @get("/", sync_to_thread=False)
    def page(limit: FromQuery[int] = 10) -> dict[str, int]:
        return {"limit": limit}

    with create_test_client(page, parameters={"limit": QueryParameter(annotation=int, name="page_size")}) as client:
        assert client.get("/", params={"page_size": 3}).json() == {"limit": 3}

    with create_test_client(page) as client:
        assert client.get("/", params={"limit": 4}).json() == {"limit": 4}
        assert client.get("/", params={"page_size": 4}).json() == {"limit": 10}


def test_reused_handler_second_app_does_not_require_first_app_header() -> None:
    """Symptom 2: a required app-level header of one app must not follow the handler."""
    handler = _make_items_handler()
    Litestar([handler], parameters={"tenant": HeaderParameter(annotation=str, name="X-Tenant")})

    with create_test_client(handler) as client:
        assert client.get("/items").status_code == HTTP_200_OK
        assert "X-Tenant" not in _openapi_parameter_names(client.app, "/items")


def test_controller_handler_parameters_combine_per_router() -> None:
    """A controller whose handler declares its own parameters, mounted under two routers."""

    class ReportController(Controller):
        path = "/reports"

        @get("/", sync_to_thread=False, parameters={"trace": HeaderParameter(annotation=str, name="X-Trace")})
        def list_reports(self) -> dict[str, bool]:
            return {"ok": True}

    internal = Router(
        "/internal",
        route_handlers=[ReportController],
        parameters={"team": QueryParameter(annotation=str)},
    )
    partner = Router(
        "/partner",
        route_handlers=[ReportController],
        parameters={"partner_id": QueryParameter(annotation=str, name="partner-id")},
    )

    with create_test_client([internal, partner]) as client:
        trace = {"X-Trace": "t-1"}
        assert client.get("/internal/reports", params={"team": "core"}, headers=trace).status_code == HTTP_200_OK
        assert client.get("/partner/reports", params={"partner-id": "p9"}, headers=trace).status_code == HTTP_200_OK
        # the handler's own declaration still applies on both routes
        assert client.get("/internal/reports", params={"team": "core"}).status_code == HTTP_400_BAD_REQUEST
        assert client.get("/partner/reports", params={"partner-id": "p9"}).status_code == HTTP_400_BAD_REQUEST


def test_layer_binding_and_precedence_within_one_registration() -> None:
    """Invariant: bare markers bind to layer declarations, the existing precedence holds,
    and unbound required layer parameters are still enforced."""

    class ItemController(Controller):
        path = "/items"
        parameters = {"page": QueryParameter(annotation=int, name="controller-page")}

        @get("/", sync_to_thread=False)
        def list_items(self, page: FromQuery[int], size: FromQuery[int]) -> dict[str, int]:
            return {"page": page, "size": size}

    router = Router(
        "/api",
        route_handlers=[ItemController],
        parameters={"size": QueryParameter(annotation=int, name="per-page")},
    )

    with create_test_client(
        router,
        parameters={
            "page": QueryParameter(annotation=int, name="p"),
            "api_key": HeaderParameter(annotation=str, name="X-Api-Key"),
        },
    ) as client:
        ok = client.get("/api/items", params={"p": 2, "per-page": 5}, headers={"X-Api-Key": "k"})
        assert ok.status_code == HTTP_200_OK
        assert ok.json() == {"page": 2, "size": 5}

        missing_header = client.get("/api/items", params={"p": 2, "per-page": 5})
        assert missing_header.status_code == HTTP_400_BAD_REQUEST
        assert "X-Api-Key" in missing_header.json()["detail"]

        names = _openapi_parameter_names(client.app, "/api/items")
        assert {"p", "per-page", "X-Api-Key"} <= names
