"""Private grader tests: ``disable_noqa_except`` must limit which noqa comments apply.

Only public behaviour is exercised: the ``Linter``/``FluffConfig`` API and the
``sqlfluff lint`` / ``sqlfluff parse`` CLI commands. Run from outside the repo
tree with the repo's interpreter, e.g.::

    PYTHONPATH=<tree>/src python -m pytest -p no:cacheprovider private_tests
"""

from click.testing import CliRunner

from sqlfluff.cli.commands import lint, parse
from sqlfluff.core import FluffConfig, Linter

# Two LT01 violations on line 1 (no spaces around "+"), no CP01 violation.
LT01_SQL = "SELECT a+b FROM t -- noqa: {ref}\n"
# Line 1 opens a range that disables LT01; line 3 has two LT01 violations and
# two CP01 violations (lower-case "select" in line 1 against upper-case below).
RANGE_SQL = "select 1 -- noqa: disable=LT01\n;\nSELECT a+b FROM t\n"
# Parses, but with an unparsable section on line 1.
PRS_SQL = "SELECT 1 FROM t WHERE ) ( -- noqa: PRS\n"
# Fails to template (fatal Jinja error), so there is no parse tree at all.
TMP_SQL = "{% if 1 > '2' %} -- noqa: TMP\n"


def _lint(sql, **overrides):
    overrides.setdefault("dialect", "ansi")
    overrides.setdefault("rules", "LT01,CP01")
    linter = Linter(config=FluffConfig(overrides=overrides))
    return linter.lint_string(sql)


def _codes(linted_file, **kwargs):
    return [(v.rule_code(), v.line_no) for v in linted_file.get_violations(**kwargs)]


def test_rule_code_noqa_ignored_for_rule_outside_exceptions():
    """`-- noqa: LT01` must not apply when only CP01 noqa is allowed."""
    sql = LT01_SQL.format(ref="LT01")
    # Baseline: with no exception list the comment is honoured.
    assert _codes(_lint(sql)) == []
    # With an exception list that doesn't cover LT01 the comment is ignored.
    assert _codes(_lint(sql, disable_noqa_except="CP01")) == [
        ("LT01", 1),
        ("LT01", 1),
    ]
    # The same applies when disable_noqa is also set explicitly.
    assert _codes(_lint(sql, disable_noqa=True, disable_noqa_except="CP01")) == [
        ("LT01", 1),
        ("LT01", 1),
    ]


def test_range_noqa_ignored_for_rule_outside_exceptions():
    """`-- noqa: disable=LT01` must not open a range unless LT01 is excepted."""
    assert _codes(_lint(RANGE_SQL, disable_noqa_except="CP01")) == [
        ("CP01", 3),
        ("LT01", 3),
        ("LT01", 3),
        ("CP01", 3),
    ]
    # When LT01 is in the exception list the range is honoured.
    assert _codes(_lint(RANGE_SQL, disable_noqa_except="LT01")) == [
        ("CP01", 3),
        ("CP01", 3),
    ]


def test_name_alias_and_glob_noqa_ignored_for_rule_outside_exceptions():
    """Name, legacy alias, group and glob references follow the same rule."""
    for ref in ("layout.spacing", "L006", "layout", "LT0*"):
        sql = LT01_SQL.format(ref=ref)
        assert _codes(_lint(sql)) == [], ref
        assert _codes(_lint(sql, disable_noqa_except="CP01")) == [
            ("LT01", 1),
            ("LT01", 1),
        ], ref


def test_noqa_for_excepted_rule_still_applies():
    """Comments for a rule that is in the exception list keep working."""
    for allowed in ("LT01", "layout.spacing", "layout", "LT0*", "CP01,LT01"):
        sql = LT01_SQL.format(ref="LT01")
        assert _codes(_lint(sql, disable_noqa_except=allowed)) == [], allowed
    for ref in ("LT01", "layout.spacing", "LT0*"):
        sql = LT01_SQL.format(ref=ref)
        assert _codes(_lint(sql, disable_noqa_except="LT01")) == [], ref


def test_parse_and_template_error_noqa_ignored_outside_exceptions():
    """`-- noqa: PRS` / `-- noqa: TMP` only apply if those codes are excepted."""
    assert _codes(_lint(PRS_SQL, disable_noqa_except="CP01")) == [("PRS", 1)]
    assert _codes(_lint(PRS_SQL, disable_noqa_except="PRS")) == []
    assert _codes(_lint(PRS_SQL)) == []

    assert _codes(_lint(TMP_SQL, templater="jinja", disable_noqa_except="CP01")) == [
        ("TMP", 1)
    ]
    assert _codes(_lint(TMP_SQL, templater="jinja", disable_noqa_except="TMP")) == []
    assert _codes(_lint(TMP_SQL, templater="jinja")) == []


def test_unused_noqa_warning_for_rule_outside_exceptions():
    """A disallowed noqa comment suppresses nothing, so it is reported unused."""
    linted = _lint(LT01_SQL.format(ref="LT01"), disable_noqa_except="CP01")
    found = [
        (v.rule_code(), v.line_no, v.desc())
        for v in linted.get_violations(filter_warning=False, warn_unused_ignores=True)
    ]
    assert [code for code, _, _ in found] == ["LT01", "LT01", "NOQA"]
    assert found[-1][2] == "Unused noqa: 'noqa: LT01'"


def test_cli_lint_reports_rule_outside_exceptions(tmp_path, monkeypatch):
    """`sqlfluff lint --disable-noqa-except CP01` reports the LT01 violations."""
    monkeypatch.chdir(tmp_path)
    (tmp_path / "query.sql").write_text(LT01_SQL.format(ref="LT01"))
    base_args = [
        "query.sql",
        "--dialect",
        "ansi",
        "--rules",
        "LT01,CP01",
        "--ignore-local-config",
        "--nocolor",
    ]
    runner = CliRunner()

    honoured = runner.invoke(lint, base_args)
    assert honoured.exit_code == 0, honoured.output

    restricted = runner.invoke(lint, base_args + ["--disable-noqa-except", "CP01"])
    assert restricted.exit_code == 1, restricted.output
    assert "LT01" in restricted.output


def test_cli_parse_reports_prs_outside_exceptions():
    """`sqlfluff parse --disable-noqa-except CP01` still shows the PRS error."""
    runner = CliRunner()
    args = ["-", "--dialect", "ansi", "--ignore-local-config", "--nocolor"]

    restricted = runner.invoke(
        parse, args + ["--disable-noqa-except", "CP01"], input=PRS_SQL
    )
    assert "==== parsing violations ====" in restricted.output
    assert "PRS" in restricted.output

    allowed = runner.invoke(
        parse, args + ["--disable-noqa-except", "PRS"], input=PRS_SQL
    )
    assert "==== parsing violations ====" not in allowed.output
