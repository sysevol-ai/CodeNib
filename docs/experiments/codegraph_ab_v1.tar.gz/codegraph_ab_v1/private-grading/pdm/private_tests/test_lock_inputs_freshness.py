"""Private grader tests: canonical lock-input freshness across lock formats.

Run from outside the repository with the repository's virtualenv, e.g.

    PYTHONPATH=<tree>/src <venv>/bin/python -m pytest -p no:cacheprovider \
        private_tests/test_lock_inputs_freshness.py

The fixture index is taken from ``<tree>/tests/fixtures`` next to the imported
``pdm`` package, so the tests never touch the network.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

import pdm as _pdm_package
from pdm.cli import actions

os.environ.update(CI="1", COLUMNS="120", NO_COLOR="1", PDM_CHECK_UPDATE="0")
os.environ.pop("FORCE_COLOR", None)

pytest_plugins = ["pdm.pytest"]

FIXTURES = Path(_pdm_package.__file__).resolve().parents[2] / "tests" / "fixtures"


@pytest.fixture(scope="session", autouse=True)
def _disable_keyring():
    from pdm.models.auth import keyring

    keyring.enabled = False


@pytest.fixture
def pypi_indexes():
    return {
        "http://fixtures.test/": {"/": FIXTURES},
        "https://my.pypi.org/": ({"/simple": FIXTURES / "index", "/json": FIXTURES / "json"}, {}, True),
    }


@pytest.fixture
def repository_pypi_json():
    return FIXTURES / "pypi.json"


@pytest.fixture
def local_finder_artifacts():
    return FIXTURES / "artifacts"


def _enable_lock_inputs(project):
    project.pyproject.open_for_write()
    project.pyproject.settings.setdefault("resolution", {})["lock_inputs"] = True
    project.pyproject.write(show_message=False)


def _grouped_project(project, lock_format):
    """A project with a default dependency, an optional extra and a dev group."""
    project.project_config["lock.format"] = lock_format
    project.add_dependencies(["requests"], show_message=False)
    project.add_dependencies(["pysocks"], to_group="socks", show_message=False)
    project.add_dependencies(["django"], to_group="web", dev=True, show_message=False)
    _enable_lock_inputs(project)
    return project


def test_pylock_lock_check_passes_right_after_lock(pdm, project, repository):
    _grouped_project(project, "pylock")

    pdm(["lock", "-G", ":all"], obj=project, strict=True)
    project.lockfile.reload()

    assert project.lockfile._path.name == "pylock.toml"
    assert project.lockfile.lock_inputs is not None
    result = pdm(["lock", "--check"], obj=project)
    assert result.exit_code == 0, result.stderr
    assert project.is_lockfile_fresh()


def test_pdm_lock_without_inherit_metadata_passes_check(pdm, project, repository):
    _grouped_project(project, "pdm")

    pdm(["lock", "-G", ":all", "--strategy", "no_inherit_metadata"], obj=project, strict=True)
    project.lockfile.reload()

    assert project.lockfile._path.name == "pdm.lock"
    assert all("groups" not in package for package in project.lockfile._data["package"])
    result = pdm(["lock", "--check"], obj=project)
    assert result.exit_code == 0, result.stderr


def test_pylock_install_does_not_relock_after_compatible_change(pdm, project, repository, mocker):
    _grouped_project(project, "pylock")
    pdm(["lock", "-G", ":all"], obj=project, strict=True)

    project.add_dependencies(["django>=2"], to_group="web", dev=True, show_message=False)
    project.lockfile.reload()
    do_lock = mocker.patch.object(actions, "do_lock")
    do_sync = mocker.patch.object(actions, "do_sync")

    result = pdm(["install", "-G", ":all"], obj=project)

    assert result.exit_code == 0, result.stderr
    assert "Lockfile doesn't satisfy" not in result.stderr
    do_lock.assert_not_called()
    do_sync.assert_called_once()


@pytest.mark.parametrize("lock_format", ["pdm", "pylock"])
def test_incompatible_group_specifier_is_still_reported(pdm, project, repository, lock_format):
    _grouped_project(project, lock_format)
    pdm(["lock", "-G", ":all"], obj=project, strict=True)

    project.add_dependencies(["django<1"], to_group="web", dev=True, show_message=False)
    project.lockfile.reload()

    assert not project.is_lockfile_fresh()
    result = pdm(["lock", "--check"], obj=project)
    assert result.exit_code == 1


def test_pylock_validates_per_target_specifiers(pdm, project, repository):
    project.project_config["lock.format"] = "pylock"
    repository.add_candidate("forked", "1.0", "<3.11")
    repository.add_candidate("forked", "2.0", ">=3.11")
    project.pyproject.metadata["dependencies"] = [
        'forked<2; python_version < "3.11"',
        'forked>=2; python_version >= "3.11"',
    ]
    project.pyproject.settings.setdefault("resolution", {})["lock_inputs"] = True
    project.pyproject.write(show_message=False)

    pdm(["lock", "--python", ">=3.10,<3.11"], obj=project, strict=True)
    pdm(["lock", "--python", ">=3.12,<3.13", "--append"], obj=project, strict=True)
    project.lockfile.reload()

    assert len([p for p in project.lockfile._data["packages"] if p["name"] == "forked"]) == 2
    assert project.is_lockfile_fresh()

    project.pyproject.metadata["dependencies"][1] = 'forked>=3; python_version >= "3.11"'
    project.pyproject.write(show_message=False)
    project.lockfile.reload()
    assert not project.is_lockfile_fresh()


def test_pdm_lock_without_inherit_metadata_still_detects_incompatible_change(pdm, project, repository):
    _grouped_project(project, "pdm")
    pdm(["lock", "-G", ":all", "--strategy", "no_inherit_metadata"], obj=project, strict=True)

    project.add_dependencies(["requests<2"], show_message=False)
    project.lockfile.reload()

    result = pdm(["lock", "--check"], obj=project)
    assert result.exit_code == 1
