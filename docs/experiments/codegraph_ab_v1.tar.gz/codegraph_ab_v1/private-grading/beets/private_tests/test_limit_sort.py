"""Private grader tests: result limits combined with multi-key sorts.

These tests exercise public behaviour only (``Library.items`` and the
``beet list`` command). Run them from outside the repository with the
repository root on ``PYTHONPATH``.
"""

from __future__ import annotations

import logging as std_logging
import sys

import pytest

import beets
from beets import logging
from beets.test.helper import TestHelper
from beets.util import cached_classproperty

# title, play_count (flexible attribute), year
TRACKS = [
    ("Alpha", "1", 2001),
    ("Bravo", "5", 2002),
    ("Charlie", "3", 2003),
    ("Delta", "9", 2004),
    ("Echo", "7", 2005),
    ("Foxtrot", "7", 2006),
]

# album, rating (flexible attribute)
ALBUMS = [
    ("Album A", "2"),
    ("Album B", "8"),
    ("Album C", "5"),
    ("Album D", "8"),
]


class _CurrentStderrHandler(std_logging.StreamHandler):
    """Write CLI logs to whatever stderr is active (pytest swaps it)."""

    @property
    def stream(self):
        return sys.stderr

    @stream.setter
    def stream(self, stream):
        pass


@pytest.fixture(autouse=True)
def _isolate_cli_state(monkeypatch):
    cached_classproperty.cache.clear()
    monkeypatch.setattr(
        "beets.ui._get_logging_handler", lambda: _CurrentStderrHandler()
    )
    monkeypatch.setattr("beets.config.log_sources", lambda _: None)
    log = logging.getLogger("beets")
    default_level, level = log.default_level, log.level
    yield
    log.default_level = default_level
    log.setLevel(level)
    beets.plugins.BeetsPlugin.listeners.clear()
    beets.plugins.BeetsPlugin._raw_listeners.clear()
    beets.plugins._instances.clear()


@pytest.fixture
def helper():
    with TestHelper() as h:
        for title, play_count, year in TRACKS:
            item = h.add_item(
                title=title,
                artist="The Artist",
                album="Singles",
                year=year,
                path=h.lib_path / f"{title}.mp3",
            )
            item["play_count"] = play_count
            item.store()
        for album_name, rating in ALBUMS:
            album = h.add_album(
                title=f"{album_name} track",
                album=album_name,
                albumartist="The Album Artist",
                path=h.lib_path / album_name / "01.mp3",
            )
            album["rating"] = rating
            album.store()
        yield h


def _titles(objs):
    return [o.title for o in objs]


def _ls(helper, capsys, *args):
    capsys.readouterr()
    helper.run_command("list", *args)
    return capsys.readouterr().out.splitlines()


def test_items_limit_flex_then_fixed_sort_returns_top_results(helper):
    results = helper.lib.items("year:2001..2006 play_count- title+", limit=2)

    assert _titles(results) == ["Delta", "Echo"]


def test_list_limit_flex_then_fixed_sort(helper, capsys):
    lines = _ls(
        helper,
        capsys,
        "-l",
        "3",
        "-f",
        "$title",
        "year:2001..2006",
        "play_count-",
        "title+",
    )

    assert lines == ["Delta", "Echo", "Foxtrot"]


def test_list_albums_limit_with_configured_flex_sort(helper, capsys):
    helper.config["sort_album"] = "rating- album+"

    top = _ls(helper, capsys, "-a", "-l", "1", "-f", "$album")
    top_two = _ls(helper, capsys, "-a", "-l", "2", "-f", "$album")

    assert top == ["Album B"]
    assert top_two == ["Album B", "Album D"]


def test_albums_limit_with_configured_flex_sort(helper):
    helper.config["sort_album"] = "rating- album+"

    results = helper.lib.albums(limit=3)

    assert [a.album for a in results] == ["Album B", "Album D", "Album C"]


def test_unlimited_multi_sort_order_and_tie_breaks_unchanged(helper, capsys):
    lines = _ls(
        helper,
        capsys,
        "-f",
        "$title",
        "year:2001..2006",
        "play_count-",
        "title-",
    )

    assert lines == ["Delta", "Foxtrot", "Echo", "Bravo", "Charlie", "Alpha"]


def test_limit_keeps_fixed_field_tie_break(helper):
    results = helper.lib.items("year:2001..2006 play_count- title-", limit=3)

    assert _titles(results) == ["Delta", "Foxtrot", "Echo"]


def test_limit_with_single_flex_or_fixed_sort(helper, capsys):
    by_flex = _ls(
        helper, capsys, "-l", "1", "-f", "$title", "year:2001..", "play_count-"
    )
    by_year = _ls(helper, capsys, "-l", "2", "-f", "$title", "year-")
    flex_last = helper.lib.items("year:2001..2006 title+ play_count-", limit=2)

    assert by_flex == ["Delta"]
    assert by_year == ["Foxtrot", "Echo"]
    assert _titles(flex_last) == ["Alpha", "Bravo"]
