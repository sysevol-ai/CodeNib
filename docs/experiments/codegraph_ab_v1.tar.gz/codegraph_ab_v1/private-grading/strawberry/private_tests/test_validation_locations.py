"""Private tests: locations of pydantic validation errors.

Validation errors of `strawberry.pydantic` inputs carry the location of the
invalid value, as the GraphQL names and list positions a client used. These
tests exercise that location for inputs reached through lists, both in
`ValidationError` union results and in top-level GraphQL errors.
"""

from __future__ import annotations

import pydantic

import strawberry
from strawberry.pydantic import PydanticValidationErrorHandler, ValidationError


@strawberry.pydantic.input
class UserInput(pydantic.BaseModel):
    name: str = pydantic.Field(min_length=1)
    email: str = pydantic.Field(pattern=r"^[^@\s]+@[^@\s]+$")


@strawberry.pydantic.input
class LineInput(pydantic.BaseModel):
    quantity: int = pydantic.Field(gt=0)


@strawberry.input
class OrderInput:
    reference: str
    order_lines: list[LineInput]


@strawberry.pydantic.input
class CartInput(pydantic.BaseModel):
    cart_lines: list[LineInput]


@strawberry.type
class Created:
    count: int


@strawberry.type
class Query:
    hello: str = "world"


@strawberry.type
class Mutation:
    @strawberry.mutation
    def create_users(self, users: list[UserInput]) -> Created | ValidationError:
        return Created(count=len(users))

    @strawberry.mutation
    def import_user_batches(
        self, batches: list[list[UserInput]]
    ) -> Created | ValidationError:
        return Created(count=sum(len(batch) for batch in batches))

    @strawberry.mutation
    def place_orders(self, orders: list[OrderInput]) -> Created | ValidationError:
        return Created(count=len(orders))

    @strawberry.mutation
    def save_cart(self, cart: CartInput) -> Created | ValidationError:
        return Created(count=len(cart.cart_lines))

    @strawberry.mutation
    def invite_users(self, users: list[UserInput]) -> Created:
        return Created(count=len(users))

    @strawberry.mutation
    def emails(self, users: list[UserInput]) -> list[str]:
        return [user.email for user in users]


schema = strawberry.Schema(
    query=Query,
    mutation=Mutation,
    exception_handlers=[PydanticValidationErrorHandler()],
)


def _locations(result, field: str) -> list[list[str]]:
    assert result.errors is None, result.errors
    payload = result.data[field]
    return [error["location"] for error in payload["errors"]]


def test_list_argument_error_is_located_at_the_item():
    result = schema.execute_sync(
        """
        mutation {
            createUsers(users: [
                {name: "Ada", email: "ada@example.com"},
                {name: "Bob", email: "bob@example.com"},
                {name: "Cy", email: "not-an-email"}
            ]) {
                ... on Created { count }
                ... on ValidationError { errors { location type } }
            }
        }
        """
    )

    assert result.errors is None, result.errors
    assert result.data == {
        "createUsers": {
            "errors": [
                {
                    "location": ["users", "2", "email"],
                    "type": "string_pattern_mismatch",
                }
            ]
        }
    }


def test_nested_lists_contribute_one_position_each():
    result = schema.execute_sync(
        """
        mutation {
            importUserBatches(batches: [
                [{name: "Ada", email: "ada@example.com"}],
                [{name: "Bob", email: "bob@example.com"}, {name: "", email: "c@example.com"}]
            ]) {
                ... on ValidationError { errors { location } }
            }
        }
        """
    )

    assert _locations(result, "importUserBatches") == [["batches", "1", "1", "name"]]


def test_list_of_plain_inputs_holding_pydantic_inputs():
    result = schema.execute_sync(
        """
        mutation {
            placeOrders(orders: [
                {reference: "A", orderLines: [{quantity: 1}]},
                {reference: "B", orderLines: [{quantity: 2}, {quantity: 0}]}
            ]) {
                ... on ValidationError { errors { location } }
            }
        }
        """
    )

    assert _locations(result, "placeOrders") == [
        ["orders", "1", "orderLines", "1", "quantity"]
    ]


def test_top_level_error_reports_the_same_location():
    result = schema.execute_sync(
        """
        mutation {
            inviteUsers(users: [
                {name: "Ada", email: "ada@example.com"},
                {name: "Bob", email: "bob-at-example"}
            ]) { count }
        }
        """
    )

    assert result.data is None
    assert result.errors is not None and len(result.errors) == 1
    error = result.errors[0]
    assert error.message.startswith("Invalid input: users.1.email: ")
    assert error.extensions is not None
    assert [entry["location"] for entry in error.extensions["validationErrors"]] == [
        ["users", "1", "email"]
    ]


def test_lists_inside_a_pydantic_model_keep_their_positions():
    result = schema.execute_sync(
        """
        mutation {
            saveCart(cart: {cartLines: [{quantity: 3}, {quantity: 0}]}) {
                ... on ValidationError { errors { location } }
            }
        }
        """
    )

    assert _locations(result, "saveCart") == [["cart", "cartLines", "1", "quantity"]]


def test_valid_list_items_are_built_in_order():
    result = schema.execute_sync(
        """
        mutation {
            emails(users: [
                {name: "Ada", email: "ada@example.com"},
                {name: "Bob", email: "bob@example.com"}
            ])
        }
        """
    )

    assert result.errors is None, result.errors
    assert result.data == {"emails": ["ada@example.com", "bob@example.com"]}


def test_argument_and_field_names_use_graphql_names():
    result = schema.execute_sync(
        """
        mutation {
            placeOrders(orders: [{reference: "A", orderLines: [{quantity: -1}]}]) {
                ... on ValidationError { errors { location type } }
            }
        }
        """
    )

    # control: only GraphQL names are checked, not list positions
    assert result.errors is None, result.errors
    payload = result.data["placeOrders"]["errors"]
    assert len(payload) == 1
    assert payload[0]["type"] == "greater_than"
    assert payload[0]["location"][0] == "orders"
    assert "orderLines" in payload[0]["location"]
    assert "order_lines" not in payload[0]["location"]
    assert payload[0]["location"][-1] == "quantity"
